package com.smartdocs.gpt.gemini.mongo.vector.collection;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "GeminiVectorDocuments")
public class GeminiVectorDocuments {

    public static final String TRAIN_TYPE_DOCUMENT = "document";
    public static final String TRAIN_TYPE_URLS = "urls";

    @Id
    private String id;
    private String documentId;
    private String sourceType;
    private String botId;
    private String documentName;
    private String siteId;
    private int page;
    private String documentContent;

    @Indexed(name = "vector_index", direction = IndexDirection.ASCENDING)
    private List<Double> embeddings;

}