package com.smartdocs.gpt.model;

import lombok.Data;

@Data
public class SourceObject {
	
	private String page_no;
	
	private String source;
	
	private String documentId;

	private String documentType;
	
	private String documentName;

	
}
