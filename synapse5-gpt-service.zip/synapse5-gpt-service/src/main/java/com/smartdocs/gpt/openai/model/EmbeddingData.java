package com.smartdocs.gpt.openai.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class EmbeddingData {
    private List<Double> embedding;
    private int tokens;
}
