package com.smartdocs.gpt.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.smartdocs.gpt.config.BasicSecurityConfig;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.smartdocs.gpt.document.model.TrainDocumentRequest;
import com.smartdocs.gpt.helper.PhraseResponse;
import com.smartdocs.gpt.model.GPTChatRequest;
import com.smartdocs.gpt.model.GPTChatResponse;
import com.smartdocs.gpt.mongo.vector.service.AltasDocumentService;
import com.smartdocs.gpt.openai.model.ChatRequestForSuggestion;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/atlas-vector")
public class AtlasVectorController {

	private final AltasDocumentService altasDocumentService;

	@PostMapping("/train")
	public boolean trainDocument(HttpServletRequest request, @RequestBody TrainDocumentRequest trainDocumentRequest) {
		String authHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			return altasDocumentService.train(trainDocumentRequest);
		} else {
			return false;
		}
	}

	@PostMapping("/chat")
	public GPTChatResponse chat(HttpServletRequest request, @RequestBody GPTChatRequest gptChatRequest) throws IOException, InterruptedException {
		String authHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			return altasDocumentService.chat(gptChatRequest);
		} else {
			GPTChatResponse response = new GPTChatResponse();
			response.setResponse("Unauthorized access");
			return response;
		}

	}

	@DeleteMapping("/deleteDocument")
	public void deleteDocument(HttpServletRequest request , @RequestParam String documentId) {
		String authHeader = request.getHeader("Authorization");
		if(BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			try {
				altasDocumentService.deleteDocument(documentId);
			} catch (Exception e) {
				e.getMessage();
			}
		}else{
			throw new SecurityException("Unauthorized access");
		}
	}

	@DeleteMapping("/deleteBot/{botId}")
	public void deleteBot(HttpServletRequest request, @PathVariable(value = "botId") String siteId) {
		String authHeader = request.getHeader("Authorization");
		if(BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			altasDocumentService.deleteBot(siteId);
		}else{
			throw new SecurityException("Unauthorized access");
		}
	}

	@PostMapping("/trainUrl/{siteId}")
	public ResponseEntity<Boolean> trainOnUrl(HttpServletRequest request , @RequestBody List<String> urls, @PathVariable(value = "siteId") String siteId) {
		String authHeader = request.getHeader("Authorization");
		if(BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			altasDocumentService.trainOnUrl(urls, siteId);
			return ResponseEntity.ok(true);
		}else{
			return ResponseEntity.status(401).body(false);
		}
	}


	@PostMapping("/train/bot")
	public String trainBot(HttpServletRequest request, @RequestBody TrainDocumentRequest trainDocumentRequest) {
		String authHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			altasDocumentService.trainBotDocuments(trainDocumentRequest);
			return "Training started successfully";
		} else {
			return "Unauthorized access";
		}
	}

	@PostMapping("/generate/utterances")
	public PhraseResponse generateUtterance(HttpServletRequest request,
											@RequestBody List<String> utterance,
											@RequestParam int numberOfUtterance) throws JsonProcessingException {

		String authzHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authzHeader)) {
			return altasDocumentService.generateUtterance(utterance, numberOfUtterance);
		} else {
			PhraseResponse response = new PhraseResponse();
			response.setParaphrases(List.of("Unauthorized access"));
			return response;
		}
	}

	@DeleteMapping("/deleteUrl")
	public void deleteUrl(HttpServletRequest request, @RequestParam String url) {
		String authHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			altasDocumentService.deleteURL(url);
		} else {
			throw new SecurityException("Unauthorized access");
		}
	}

	@DeleteMapping("/deleteFile")
	public void deleteFile(HttpServletRequest request,
						   @RequestParam(value = "siteId") String siteId,
						   @RequestParam(value = "docId") String docId) {
		String authHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			altasDocumentService.deleteFile(siteId, docId);
		} else {
			throw new SecurityException("Unauthorized access");
		}
	}

	@DeleteMapping("/deleteDoc")
	public void deleteDoc(HttpServletRequest request, @RequestParam String docId) {
		String authHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			altasDocumentService.deleteURL(docId);
		} else {
			throw new SecurityException("Unauthorized access");
		}
	}

	@PostMapping("/migrateTaxanomy")
	public String trainTaxanomy(HttpServletRequest request) {
		String authHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			altasDocumentService.migrateTaxanomy();
			return "Taxanomy migration started";
		} else {
			return "Unauthorized access";
		}
	}

	@PostMapping("/forviaBotChat")
	public String chatForviaBot(HttpServletRequest request,
								@RequestBody GPTChatRequest chatRequest,
								@RequestParam String languageCode) throws IOException, InterruptedException {
		String authHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			return altasDocumentService.chatForviaBot(chatRequest, languageCode);
		} else {
			return "Unauthorized access";
		}
	}

	@PostMapping("/suggestions")
	public GPTChatResponse getSuggestion(HttpServletRequest request, @RequestBody ChatRequestForSuggestion chatRequestForSuggestion) throws IOException, InterruptedException {
		String authHeader = request.getHeader("Authorization");
		if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
			GPTChatResponse gptChatResponse = new GPTChatResponse();
			String customPrompt = chatRequestForSuggestion.getSuggestedQuestionsPrompt();
			Map<String, Object> result = altasDocumentService.generateSuggestedQuestions(
					chatRequestForSuggestion.getText(),
					chatRequestForSuggestion.getHeaderLine(),
					4000,
					0.2,
					customPrompt,
					chatRequestForSuggestion.getUserLanguage(),
					chatRequestForSuggestion.getPreviousMessages(),
					chatRequestForSuggestion.getSources()
			);

			gptChatResponse.setSuggestedQuestions((List<String>) result.get("response"));
			gptChatResponse.setHeaderLine((String) result.get("translatedHeader"));
			gptChatResponse.setPromptTokens((int) result.get("promptTokens"));
			gptChatResponse.setCompletionTokens((int) result.get("completionTokens"));
			gptChatResponse.setTotalTokens((int) result.get("totalTokens"));
			return gptChatResponse;
		} else {
			GPTChatResponse response = new GPTChatResponse();
			response.setResponse("Unauthorized access");
			return response;
		}
	}
}

