package com.smartdocs.gpt.utils;

import java.util.Locale;

public final class LanguageUtils {
    private LanguageUtils() { /* no instances */ }

    public static String getEnglishLanguageName(String languageCode) {
        if (languageCode == null || languageCode.isBlank()) {
            return "English";
        }
        var locale = new Locale(languageCode);
        var name = locale.getDisplayLanguage(Locale.ENGLISH);
        return (name == null || name.isBlank()) ? languageCode : name;
    }
}
