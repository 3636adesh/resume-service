package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.AribaCatalogEmbedding;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AribaCatalogEmbeddingRepository extends MongoRepository<AribaCatalogEmbedding , String> {

    @Query("{ 'classificationCode': { $regex: ?0, $options: 'i' } }")
    List<AribaCatalogEmbedding> findByClassificationCodeRegex(String regex);
}
