package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.SystemPrompt;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SystemPromptRepository extends MongoRepository<SystemPrompt, String> {}
