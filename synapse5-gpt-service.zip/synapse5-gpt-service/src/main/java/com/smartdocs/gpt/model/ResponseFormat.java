package com.smartdocs.gpt.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseFormat {
	private String type;
}
