
package com.smartdocs.gpt.gemini.config;
import com.smartdocs.gpt.model.AiEngineConfig;
import com.smartdocs.gpt.mongo.repository.GptConfigRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Data
@Component
public class GeminiConfigProperties {
    private String apiKey;
    private String baseUrl;
    private String modelName;
    private String embeddingModel;
    private String engineName;
    private String engineType;

    private final GptConfigRepository gptConfigRepo;

    public GeminiConfigProperties(GptConfigRepository gptConfigRepo) {
        this.gptConfigRepo = gptConfigRepo;
        buildGeminiConfig();
    }

    private void buildGeminiConfig() {
        Optional<AiEngineConfig> existCfgOpt = gptConfigRepo.findByEngineType(AiEngineConfig.ENGINE_TYPE_GEMINI);
        if (existCfgOpt.isPresent()) {
            AiEngineConfig existCfg = existCfgOpt.get();
            if(existCfg.isEnable()){
                setBaseUrl(existCfg.getEndPointUrl());
                setModelName(existCfg.getModelName());
                setEngineType(existCfg.getEngineType());
                setEmbeddingModel(existCfg.getEmbeddingModel());
                setApiKey(existCfg.getApiKey());
        }
    }
}
}