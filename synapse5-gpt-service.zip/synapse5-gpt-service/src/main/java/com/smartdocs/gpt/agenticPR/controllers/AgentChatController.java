package com.smartdocs.gpt.agenticPR.controllers;

import com.smartdocs.gpt.agenticPR.models.AgentResponse;
import com.smartdocs.gpt.agenticPR.models.ItemSelections;
import com.smartdocs.gpt.agenticPR.models.PrData;
import com.smartdocs.gpt.agenticPR.models.UserMessage;
import com.smartdocs.gpt.agenticPR.services.ChatService;
import com.smartdocs.gpt.agenticPR.services.FunctionExecutor;
import lombok.RequiredArgsConstructor;
import org.bson.Document;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/agent")
@RequiredArgsConstructor
public class AgentChatController {

    private final ChatService chatService;
    private final FunctionExecutor functionExecutor;

    @PostMapping("/chat")
    public ResponseEntity<?> chat(@RequestBody UserMessage userMessage) {
        try {
            AgentResponse response = chatService.handleUserQuery(userMessage.getChannelId() , userMessage.getQuery() , userMessage.getTransactionId() , userMessage.getLineItems() , userMessage.getUserDefaults() , userMessage.getAction() , userMessage.getProductName() , userMessage.getCommodityCode() , userMessage.getCommodityCodeName(),  userMessage.getNonCatalogSummary() , userMessage.getDescription());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("An error occurred while processing your request.");
        }
    }

    @PostMapping("/save")
    public AgentResponse chat(@RequestBody PrData prData) {
                PrData savedPr = chatService.savePrData(prData);

            Map<String, String> response = new HashMap<>();
            response.put("prNumber", savedPr.getPrId());
            return chatService.buildAgentResponse("SHOW_PR_NUMBER" , "finalPr" , response , null);
    }

    @GetMapping("/getOne")
    public Document searchCommodities(@RequestParam String query) {
        return functionExecutor.searchTopMatches(query);
    }

    @PostMapping("/sync")
    public List<ItemSelections> syncItemSelections() {
        return chatService.syncItemSelections();
    }

}

