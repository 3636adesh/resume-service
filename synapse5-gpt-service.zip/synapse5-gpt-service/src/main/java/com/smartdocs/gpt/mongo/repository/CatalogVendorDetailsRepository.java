package com.smartdocs.gpt.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.smartdocs.gpt.mongo.model.CatalogVendorDetails;

public interface CatalogVendorDetailsRepository extends MongoRepository<CatalogVendorDetails, String>{
	
	List<CatalogVendorDetails> findByMergeMappingNewSegment(String mergeMappingNewSegment);
	
}
