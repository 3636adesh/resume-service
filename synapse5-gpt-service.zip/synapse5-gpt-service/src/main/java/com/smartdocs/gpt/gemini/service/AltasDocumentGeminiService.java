package com.smartdocs.gpt.gemini.service;

import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mongodb.client.model.Filters;
import com.smartdocs.gpt.gemini.config.GeminiConfigProperties;
import com.smartdocs.gpt.gemini.mongo.vector.repository.GeminiVectorDocumentsRepository;
import com.smartdocs.gpt.model.PreviousMessages;
import com.smartdocs.gpt.mongo.model.AiEngineFileDetails;
import com.smartdocs.gpt.mongo.model.AiEngineTrainingStatus;
import com.smartdocs.gpt.mongo.repository.AiEngineFileDetailsRepository;
import com.smartdocs.gpt.mongo.repository.TrainingStatusRepository;
import com.smartdocs.gpt.utils.LanguageUtils;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.commonmark.ext.gfm.tables.TablesExtension;
import org.commonmark.node.Node;
import org.commonmark.parser.Parser;
import org.commonmark.renderer.html.HtmlRenderer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.smartdocs.gpt.document.model.*;
import com.smartdocs.gpt.document.service.DocumentService;
import com.smartdocs.gpt.model.GPTChatRequest;
import com.smartdocs.gpt.model.GPTChatResponse;
import com.smartdocs.gpt.model.SourceObject;
import com.smartdocs.gpt.gemini.mongo.vector.collection.GeminiVectorDocuments;
import com.smartdocs.gpt.openai.model.ChatResponse;
import com.smartdocs.gpt.openai.model.Message;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class AltasDocumentGeminiService {

    final int MAX_TOKENS_PER_BATCH = 20000;
    final int MAX_SEGMENTS_PER_BATCH = 250;

    private final GeminiVectorDocumentsRepository vectorDocumentsRepository;

    private final DocumentService documentService;

    private final TrainingStatusRepository trainingStatusRepository;

    private final AiEngineFileDetailsRepository aiEngineFileDetailsRepository;

    private final MongoClient mongoClient;

    private final GeminiService geminiService;

    private final GeminiDocumentService geminiDocumentService;

    private final GeminiCommonService commonService;

    private final GeminiConfigProperties geminiConfigProperties;

    private final GeminiVectorDocumentsRepository geminiVectorDocumentRepository;

    @Value("${vector.db.name}")
    private String dbName;

    public boolean train(TrainDocumentRequest trainDocumentRequest) {

        AiEngineTrainingStatus aiEngineTrainingStatus = new AiEngineTrainingStatus();
        aiEngineTrainingStatus.setDocumentId(trainDocumentRequest.getDocumentId());
        aiEngineTrainingStatus.setStatus("In-Progress");
        aiEngineTrainingStatus = trainingStatusRepository.save(aiEngineTrainingStatus);

        int totalEmbeddingCount = 0;
        try {
            Map<Integer, com.smartdocs.gpt.document.model.Document> documents = documentService
                    .processDocument(trainDocumentRequest);

            Map<String, String> chunckMap = new HashMap<>();

            for (Map.Entry<Integer, com.smartdocs.gpt.document.model.Document> itr : documents.entrySet()) {

                int page = itr.getKey();
                com.smartdocs.gpt.document.model.Document document = itr.getValue();

                List<TextSegment> segments = documentService.split(document);

                List<String> batchTexts = new ArrayList<>();
                int currentBatchTokenCount = 0;

                for (TextSegment textSegment : segments) {
                    String segmentText = textSegment.text();

                    // Estimate token count for current segment (confirmed < 2048 tokens)
                    int segmentTokenCount = geminiDocumentService.estimateTokenCount(segmentText);

                    // Check if adding this segment would exceed limits
                    boolean wouldExceedTokenLimit = (currentBatchTokenCount + segmentTokenCount) > MAX_TOKENS_PER_BATCH;
                    boolean wouldExceedSegmentLimit = batchTexts.size() >= MAX_SEGMENTS_PER_BATCH;

                    // Process current batch if limits would be exceeded and batch is not empty
                    if ((wouldExceedTokenLimit || wouldExceedSegmentLimit) && !batchTexts.isEmpty()) {
                        totalEmbeddingCount += processBatch(batchTexts);

                        // Clear batch for next iteration
                        batchTexts.clear();
                        currentBatchTokenCount = 0;
                    }

                    // Add current segment to batch
                    batchTexts.add(segmentText);
                    currentBatchTokenCount += segmentTokenCount;

                    // Create vector document entry and get ID for batch processing
                    List<Double> embedding = geminiService.createEmbeddingInDouble(textSegment.text());
                    var vectorDocument = new GeminiVectorDocuments();
                    vectorDocument.setDocumentContent(textSegment.text());
                    vectorDocument.setEmbeddings(embedding);
                    vectorDocument.setPage(page);
                    vectorDocument.setSiteId(trainDocumentRequest.getSiteId());
                    vectorDocument.setDocumentId(trainDocumentRequest.getDocumentId());
                    vectorDocument.setDocumentName(trainDocumentRequest.getFileName());
                    vectorDocument = vectorDocumentsRepository.save(vectorDocument);
                    chunckMap.put(vectorDocument.getId(), textSegment.text());
                }
                // Process any remaining segments in the final batch
                if (!batchTexts.isEmpty()) {
                    totalEmbeddingCount += processBatch(batchTexts);
                }
                log.info("Total embeddings processed: " + totalEmbeddingCount);
            }
//            List<AiEngineFileDetails> fileDetailList = new ArrayList<>();

//            for (Map.Entry<String, String> itr : chunckMap.entrySet()) {
//                AiEngineFileDetails aiEngineFileDetails = new AiEngineFileDetails(trainDocumentRequest.getSiteId(),
//                        trainDocumentRequest.getDocumentCategory(), trainDocumentRequest.getDocumentId(),
//                        itr.getValue(), itr.getKey() , geminiConfigProperties.getEngineType());
//                fileDetailList.add(aiEngineFileDetails);
//            }

//            aiEngineFileDetailsRepository.saveAll(fileDetailList);
            aiEngineTrainingStatus.setEmbeddingTokens(totalEmbeddingCount);
            aiEngineTrainingStatus.setStatus("Completed");

        } catch (Exception e) {

            aiEngineTrainingStatus.setErrorMessage(e.getMessage());
            log.info("Some Error occurred while training");
            aiEngineTrainingStatus.setStatus("Some error occurred");
            e.printStackTrace();
        }

        trainingStatusRepository.save(aiEngineTrainingStatus);

        return true;
    }

    public GPTChatResponse chat(GPTChatRequest chatRequest) throws IOException, InterruptedException {
        String apiKey = geminiConfigProperties.getApiKey();
        if(apiKey == null){
            GPTChatResponse errorResponse = new GPTChatResponse();
            errorResponse.setResponse("Sorry, I am unable to get proper configuration of Gpt");
            return errorResponse;
        }
        List<Double> queryEmbeddings = geminiService.createEmbeddingInDouble(chatRequest.getMessage());
        List<String> batch= new ArrayList<>();
        batch.add(chatRequest.getMessage());
        int totalEmbeddingTokens = processBatch(batch);
        MongoDatabase database = mongoClient.getDatabase(dbName);
        MongoCollection<Document> collection = database.getCollection("GeminiVectorDocuments");
        int numCandidates = 50;
        int limit = 5;

        double similarityThreshold = 0.00;

        List<String> matchingSiteIds = mongoClient.getDatabase(dbName)
                .getCollection("GeminiVectorDocuments")
                .distinct("siteId",
                        Filters.regex("siteId", "^" + Pattern.quote(chatRequest.getSiteId())),
                        String.class)
                .into(new ArrayList<>());

        System.out.println("Matching siteIds for gemini vector search: " + matchingSiteIds);

        if (matchingSiteIds.isEmpty()) {
            GPTChatResponse errorResponse = new GPTChatResponse();
            errorResponse.setResponse("No matching documents found for siteId prefix: " + chatRequest.getSiteId());
            return errorResponse;
        }

        Document filter = new Document("siteId", new Document("$in", matchingSiteIds));

        List<Bson> aggregationPipeline = Arrays.asList(
                new Document("$vectorSearch",
                        new Document()
                                .append("index", "gemini_vector_index")
                                .append("path", "embeddings")
                                .append("filter", filter)
                                .append("queryVector", queryEmbeddings)
                                .append("numCandidates", numCandidates)
                                .append("limit", limit * 2) // Get more candidates for filtering
                ),
                new Document("$addFields",
                        new Document("similarityScore", new Document("$meta", "vectorSearchScore"))
                ),
                new Document("$match",
                        new Document("similarityScore", new Document("$gte", similarityThreshold))
                ),
                new Document("$sort",
                        new Document("similarityScore", -1)
                ),
                new Document("$limit", limit)
        );

        AggregateIterable<Document> result = collection.aggregate(aggregationPipeline);
        List<GeminiVectorDocuments> documents = new ArrayList<>();
        for (var doc : result) {
            JSONObject jsonObject = JSONObject.parseObject(doc.toJson());

            GeminiVectorDocuments vectorDocuments = new GeminiVectorDocuments();
            vectorDocuments.setDocumentId(jsonObject.getString("documentId"));
            vectorDocuments.setDocumentContent(jsonObject.getString("documentContent"));
            vectorDocuments.setPage(jsonObject.getInteger("page"));
            vectorDocuments.setDocumentName(jsonObject.getString("documentName"));

            String oId = jsonObject.getString("_id");
            var id = new org.json.JSONObject(oId).getString("$oid");

            vectorDocuments.setId(id);
            documents.add(vectorDocuments);
            double similarity = jsonObject.getDoubleValue("similarityScore");
        }
        List<SourceObject> sourceobjects = commonService.getSourceListFromDocument(documents);

        List<String> sourceStrings = new ArrayList<>();
        for (SourceObject sourceObject : sourceobjects) {
            sourceStrings.add(sourceObject.getSource());
        }
        GPTChatResponse chatResponse = new GPTChatResponse();
        chatResponse.setSources(sourceobjects);

        String userLangCode = chatRequest.getUserLanguage() != null ? chatRequest.getUserLanguage() : "en";
        String fullLanguage = LanguageUtils.getEnglishLanguageName(userLangCode);

        String persona = chatRequest.getPersona() != null ? chatRequest.getPersona() : "helpful assistant";

        String finalPrompt = String.format("""
            ────────────────────────────────────────
            ROLE
            ────────────────────────────────────────
            You are SpotlineGPT, an advanced multilingual knowledge synthesis assistant developed by Spotline Inc. 
            Your core function is to analyze and synthesize information exclusively from provided source documents. 
            You are designed with zero-hallucination architecture to ensure complete factual accuracy and source attribution.

            ────────────────────────────────────────
            JSON OUTPUT REQUIREMENT
            ────────────────────────────────────────
            CRITICAL: Your response will be automatically structured as JSON with two fields:
            - "response": Your main answer content
            - "sources": Array of document IDs you actually used
            
            Do NOT include any text outside the JSON structure. Do NOT add markdown code blocks or explanatory text.

            ────────────────────────────────────────
            CRITICAL LANGUAGE PROTOCOL
            ────────────────────────────────────────
            • The user's query language is [FULL_LANGUAGE_NAME] (ISO code [USER_LANGUAGE_CODE]).
            • Produce your entire answer strictly in [FULL_LANGUAGE_NAME].
            • Never switch languages or mention detection/translation.
            • Internally verify that every token of your reply is in [FULL_LANGUAGE_NAME].

            ────────────────────────────────────────
            MANDATORY URL/LINK HANDLING PROTOCOL
            ────────────────────────────────────────
            CORE RULE: Only create a clickable link if the exact, complete URL or email address is present in the SOURCE DOCUMENT CONTEXT. Never guess, change, or invent a link.

            LINK HANDLING ALGORITHM
            1. CHECK FOR EXACT URL/EMAIL:
            Scan the SOURCE DOCUMENT CONTEXT for a complete URL (starting with https:// or http://) or a valid email address.

            2. APPLY CASE:
            CASE A: Exact Link Found
            -If you find an exact URL, format it as: <URL_FROM_SOURCE>
            -If you find an exact email, format it as: <mailto:EMAIL_FROM_SOURCE>

            CRITICAL: The text inside the <...> must be an exact, character-for-character copy from the source. Do not change anything.

            CASE B: No Exact Link Found
            -If the source only has a name or description (like "EcoVadis pricing page") but no actual URL, do not create a link.
            -Instead, state clearly: I do not have the direct link for [Name of page/organization from source].

            **STRICT RULE:** Only create clickable links when the complete, actual URL is explicitly present in the source context.

            ────────────────────────────────────────
            ANSWER GENERATION ALGORITHM
            ────────────────────────────────────────
            1. Search the provided **SOURCE DOCUMENT CONTEXT** section for passages that directly answer the question: [USER_QUESTION].
            However, if the user's query is broad or general (e.g., "clarify targets," "summarize initiatives"), then reinterpret it as a request to restate the available evidence from the context in a clear, user-friendly way. Always include information supported by sources.
            
            2. If the question is a follow-up, then search the **PAST CONVERSATION HISTORY CONTEXT** section for potentially relevant and accurate information.
            
            3. If still no relevant evidence is found in either context, provide a fallback message:
            "I'm sorry, but I don't have enough information to answer that"

            4. **EXTRACT & REPHRASE**
            • If evidence is found, generate response based on the stated data in the sources.
            • Rephrase into a clean, coherent, user‑friendly answer.
            • Always respond in valid GitHub-flavored Markdown.
            • Do not include decorative characters like ─────── lines.
            • Use only standard Markdown features (headings, lists, tables, links, code blocks).

            5. **APPLY URL/LINK HANDLING PROTOCOL** (see section above)
            • Preserve any actual URLs found in the source context and format them as proper Markdown links only if the raw url string begins with one of these allowed prefixes:
            `https://`, `http://`, `www.`, `mailto:` or is an email(can be any pattern).

            6. **SOURCE TRACKING**
            • Track the Document IDs of all sources actually used.
            • Include these IDs in the sources array of your JSON response.
            • Do NOT mention sources in your text response - only in the sources array.

            ────────────────────────────────────────
            RESPONSE VERIFICATION CHECKLIST
            ────────────────────────────────────────
            Before finalizing your answer, confirm:
            1. ✓ The information is stated in the provided context.
            2. ✓ Each fact can be matched to a specific source document ID.
            3. ✓ No information is from external knowledge or inference.
            4. ✓ All document IDs actually used are included in sources array.
            5. ✓ The response text contains NO source citations or mentions.
            6. ✓ All links are GitHub-flavored Markdown autolinks and approved link types `https://`, `http://`, `www.`, `mailto:` or an email(can be any pattern) used are present in the source documents and can be traced.
            7. ✓ Email always use the format **[email@domain.com](mailto:email@domain.com)**

            ────────────────────────────────────────
            HALLUCINATION PREVENTION RULES
            ────────────────────────────────────────
            • Do NOT guess, infer, or generalize beyond the context.
            • If the user asks a broad or vague question, you may reinterpret it narrowly in terms of what is explicitly stated in the context (never beyond it).
            • Only answer using the provided Source Document Context; if the user asks anything beyond it (including general knowledge), refuse to answer.
            • Do NOT add external examples or data.
            • Do NOT change provided facts or numbers.
            • Do NOT create fake URLs, placeholder links or random links.
            • Fallback IMMEDIATELY if evidence is missing.
            • Always ensure to include links if mentioning about them in the answer.

            ────────────────────────────────────────
            SOURCE DOCUMENT CONTEXT FOLLOWS
            ────────────────────────────────────────
            """);
        String userMessage = chatRequest.getMessage();
        finalPrompt = StringUtils.hasText(chatRequest.getSystemContent()) ? chatRequest.getSystemContent() : finalPrompt;
        finalPrompt = finalPrompt.replace("[PERSONA]", persona)
                .replace("[FULL_LANGUAGE_NAME]", fullLanguage)
                .replace("[USER_LANGUAGE_CODE]", userLangCode)
                .replace("[USER_QUESTION]", chatRequest.getMessage());

        List<Message> messages = new ArrayList<>();

        messages.add(new Message("system", finalPrompt));
        StringBuilder sourcesContext = new StringBuilder();
        sourcesContext.append("Available Knowledge Base Sources:\n\n");

        for (int i = 0; i < sourceobjects.size(); i++) {
            sourcesContext.append("=== Source ").append(i + 1).append(" ===\n");
            sourcesContext.append("Document Name: ").append(documents.get(i).getDocumentName()).append("\n");
            sourcesContext.append("Document ID: ").append(documents.get(i).getDocumentId()).append("\n");
            sourcesContext.append("Page: ").append(documents.get(i).getPage()).append("\n");
            sourcesContext.append("Content: ").append(sourceobjects.get(i).getSource()).append("\n\n");
        }

        messages.add(new Message("system", sourcesContext.toString()));

        messages.add(new Message("system", """
            ### PAST CONVERSATION HISTORY CONTEXT FOLLOWS ###
            """));
        for (int a = 0; a < chatRequest.getPreviousMessages().size(); a++) {
            String userMsg = chatRequest.getPreviousMessages().get(a).getUserMessage();
            String botMsg = chatRequest.getPreviousMessages().get(a).getBotMessage();
            if (userMsg == null) {
                continue;
            }
            messages.add(new Message("user", userMsg));
            if (botMsg != null) {
                messages.add(new Message("assistant", botMsg));
            }
        }
        messages.add(new Message("user", "User's Question: " + userMessage));

        ChatResponse chatResponsee = geminiService.createChatCompletionWithSchema(
                messages, chatRequest.getOutputLength(), chatRequest.getTemperature());

        String geminiResponse = chatResponsee.getChoices().get(0).getMessage().getContent();

        try {
            ObjectMapper mapper = new ObjectMapper();

            // Try to clean and extract JSON from potentially mixed response
            String cleanJsonResponse = extractJsonFromMixedResponse(geminiResponse);
            JsonNode jsonNode = mapper.readTree(cleanJsonResponse);

            String responseText = jsonNode.has("response") ? jsonNode.get("response").asText() : "";
            JsonNode sourcesNode = jsonNode.get("sources");

            // Parse sources from JSON
            List<String> usedIds = new ArrayList<>();
            if (sourcesNode != null && sourcesNode.isArray()) {
                for (JsonNode source : sourcesNode) {
                    usedIds.add(source.asText());
                }
            }

            // If response is empty but we have content before JSON, extract it
            if (responseText.isEmpty() && !cleanJsonResponse.equals(geminiResponse)) {
                responseText = extractTextBeforeJson(geminiResponse);
            }

            // Map document IDs to source objects
            Map<String, SourceObject> idToSource = new HashMap<>();
            for (SourceObject src : sourceobjects) {
                idToSource.put(src.getDocumentId(), src);
            }

            List<SourceObject> relevantSources = new ArrayList<>();
            Set<String> addedIds = new HashSet<>();

            for (String id : usedIds) {
                SourceObject found = idToSource.get(id);
                if (found != null && !addedIds.contains(found.getDocumentId())) {
                    relevantSources.add(found);
                    addedIds.add(found.getDocumentId());
                }
            }
            String finalRes = markDownToHtml(responseText);

            chatResponse.setAnswered(!relevantSources.isEmpty());
            chatResponse.setSources(relevantSources);
            chatResponse.setResponse(finalRes);

        } catch (Exception e) {
            log.error("Failed to parse JSON response: {}", geminiResponse, e);

            try {
                String responseText = extractTextBeforeJson(geminiResponse);
                List<String> extractedIds = extractSourceIdsFromText(geminiResponse);

                Map<String, SourceObject> idToSource = new HashMap<>();
                for (SourceObject src : sourceobjects) {
                    idToSource.put(src.getDocumentId(), src);
                }

                List<SourceObject> relevantSources = new ArrayList<>();
                Set<String> addedIds = new HashSet<>();

                for (String id : extractedIds) {
                    SourceObject found = idToSource.get(id);
                    if (found != null && !addedIds.contains(found.getDocumentId())) {
                        relevantSources.add(found);
                        addedIds.add(found.getDocumentId());
                    }
                }
                chatResponse.setAnswered(!relevantSources.isEmpty());
                chatResponse.setSources(relevantSources.isEmpty() ? sourceobjects : relevantSources);
                chatResponse.setResponse(responseText.isEmpty() ? geminiResponse : responseText);

            } catch (Exception fallbackException) {
                log.error("Fallback parsing also failed", fallbackException);
                chatResponse.setSources(sourceobjects);
                chatResponse.setResponse(geminiResponse);
            }
        }

        if (chatResponsee.getUsage() != null) {
            chatResponse.setPromptTokens(chatResponsee.getUsage().getPromptTokens());
            chatResponse.setCompletionTokens(chatResponsee.getUsage().getCompletionTokens());
            chatResponse.setTotalTokens(chatResponsee.getUsage().getTotalTokens());
        }
        chatResponse.setEmbeddingTokens(totalEmbeddingTokens);
        return chatResponse;

    }


    public Map<String, Object> generateSuggestedQuestions(String answer, String headerLine, int maxTokens,
                                                          double temperature, String suggestedQuestionsPrompt,
                                                          String userLanguage, List<PreviousMessages> previousMessages,
                                                          List<SourceObject> sources) throws IOException, InterruptedException {

        String openApiKey = geminiConfigProperties.getApiKey();
        if(openApiKey == null){
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("response", List.of("Sorry, I am unable to get proper configuration of Gemini."));
            return errorResponse;
        }
        if(answer == null || answer.trim().isEmpty()) {
            return Collections.emptyMap();
        }

        /* ───────────────────────── 2. LANGUAGE RESOLUTION ───────────────────────── */
        String userLangCode = (userLanguage == null || userLanguage.isBlank()) ? "en" : userLanguage;
        String fullLanguage  = LanguageUtils.getEnglishLanguageName(userLangCode);

        /* ───────────────────────── 3. PROMPT CONSTRUCTION ───────────────────────── */
        String promptToUse;
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode  inputJson = mapper.createObjectNode();

        // Always-present fields
        inputJson.put("text",       answer.trim());
        inputJson.put("headerLine", headerLine.trim());

        boolean isPastConvo = false;
        /* 3-A  Sources present → use context-based prompt */
        if (sources != null && !sources.isEmpty()) {
            // Build/choose the prompt template
            if (suggestedQuestionsPrompt != null && !suggestedQuestionsPrompt.isBlank()) {
                // Caller supplied prompt → just append context
                promptToUse = suggestedQuestionsPrompt + "\n\n**CONTEXT FOLLOWS**:\n";
            } else {
                // Fallback prompt kept *inside* the method
                String defaultContextPrompt = """
                        Role:
                        You are SpotlineGPT, an intelligent multilingual Follow-Up Question Assistant developed by Spotline Inc. You specialize in generating contextually relevant follow-up questions that are guaranteed to be answerable from provided source materials.
     
                        JSON OUTPUT REQUIREMENT:
                        CRITICAL: Your response will be automatically structured as JSON with these fields:
                        - "suggestedQuestions": Array of 2-3 follow-up questions
                        - "translatedHeader": Translated version of the headerLine
                        Do NOT include any text outside the JSON structure. Do NOT add markdown code blocks or explanatory text.
     
                        Task:
                        Given headerLine and sources in JSON format, translate the headerLine and generate 2-3 follow-up questions in [FULL_LANGUAGE_NAME] using a systematic source-validation approach with hierarchical source priority.
                        
                        Input Format:
                        {
                          "text": "to be used as source in extreme case where no follow-up question can be generated from 'sources'",
                          "headerLine": "text to be translated into [FULL_LANGUAGE_NAME]",
                          "sources": ["source snippet 1", "source snippet 2", ...]
                        }
                        
                        CRITICALLY STRICT SOURCE VALIDATION PROTOCOL:
                        • PRIMARY RULE: Every question must have a complete, explicit answer in "sources"\s
                        • EXTREME FALLBACK RULE: Use "text" field ONLY when zero quality questions can be generated from "sources"
                        • VERIFICATION MANDATE: Each question undergoes triple validation before inclusion
                        
                        Enhanced Question Generation Algorithm:
                        
                        1. **PRIMARY SOURCE ANALYSIS PHASE**
                           • Extract 5-7 specific, concrete facts from "sources" ONLY
                           • Identify actionable information (processes, requirements, features, numbers)
                           • Map each fact to its exact source location for verification
                        
                        2. **CANDIDATE QUESTION CREATION FROM SOURCES**
                           • Generate 6-7 potential questions from extracted facts in "sources"
                           • Keep questions concise (<10 words)
                           • Focus on: specific details, how-to processes, requirements, features mentioned
                           • Prioritize questions that explore different aspects of provided information
                        
                        3. **TRIPLE VALIDATION SYSTEM FOR SOURCE-BASED QUESTIONS**
                           For each candidate question, verify:
                        
                           **Validation Check 1 - Source Availability:**
                           - Can I locate the exact answer in "sources"? (Must be YES)
                        
                           **Validation Check 2 - Completeness:**
                           - Is the answer complete without requiring external inference and from the sources provided? (Must be YES)
                        
                           **Validation Check 3 - User Experience:**
                           - Would a user get a satisfactory, complete answer from provided sources alone? (Must be YES)
                        
                        4. **EXTREME FALLBACK PROTOCOL**
                           **ONLY IF zero questions pass validation from "sources":**
                           • Analyze "text" field using same extraction and validation process
                           • Apply identical triple validation system to "text" content
                           • Generate questions answerable ONLY from "text" field
                           • **IMPORTANT**: This is a last resort - prefer "sources" whenever possible
                        
                        5. **FINAL SELECTION & TRANSLATION**
                           • Select 2-3 highest-quality validated questions (prioritizing source-based over text-based)
                           • Translate "headerLine" to [FULL_LANGUAGE_NAME]
                           • Ensure all questions are in [FULL_LANGUAGE_NAME]
                        
                        EXAMPLES FOR GUIDANCE:
                        
                        ✅ GOOD Questions (answerable from sources):
                        - If sources mention "filter by country, name, commodity" → "What filtering options are available?"
                        - If sources explain a 3-step process → "How does [specific process] work?"
                        - If sources list specific requirements → "What are the main requirements?"
                        
                        ❌ BAD Questions (avoid these):
                        - If sources only mention "ECOSPHERA dashboard" without details → DON'T ask "What is ECOSPHERA dashboard?"
                        - If sources reference unexplained features → DON'T ask for specifications not provided
                        - If sources mention terms without definitions → DON'T ask for definitions not given
                        
                        QUALITY ASSURANCE CHECKLIST:
                        Before finalizing output, confirm:
                        1. Each question has an explicit, complete answer in provided materials
                        2. No question requires information beyond the given context
                        3. All questions are in [FULL_LANGUAGE_NAME]
                        4. HeaderLine is accurately translated
                        5. Questions explore different aspects (avoid repetition)
                        6. **Source hierarchy respected**: "sources" used before "text" fallback
                        
                        ADAPTIVE FALLBACK SYSTEM:
                        • **1-3 validated questions from "sources":** Standard output format
                        • **0 validated questions from "sources":** Attempt generation from "text" field
                        • **0 validated questions from both:** Return empty array
                        
                        Source Priority Hierarchy:
                        1. **First Priority**: Generate from "sources" array
                        2. **Extreme Fallback**: Use "text" field only if sources yield zero quality questions
                        3. **Final Fallback**: Empty array if neither source provides adequate content
                        
                        Output Format:
                        {
                          "suggestedQuestions": ["question1", "question2", "question3"],
                          "translatedHeader": "translated headerLine text"
                        }
                        
                        HALLUCINATION PREVENTION PROTOCOL:
                        • Generate questions ONLY about information explicitly present in provided materials
                        • Never create questions requiring speculation, inference, or external knowledge
                        • If uncertain about answer availability, exclude the question
                        • Prioritize source fidelity over question quantity
                        • **Strictly respect source hierarchy**: exhaust "sources" before considering "text"
                        
                        **CONTEXT FOLLOWS**:
                        
    	""";
                promptToUse = defaultContextPrompt;
            }

            /* add "sources" array into the JSON input */
            ArrayNode sourceArray = mapper.createArrayNode();
            int counter = 1;
            for (SourceObject so : sources) {
                sourceArray.add("Source " + counter + ": " + so.getSource());
                counter++;
            }
            inputJson.set("sources", sourceArray);

        } else {

            isPastConvo = true;
            promptToUse = """
					Role:
					You are SpotlineGPT, an intelligent multilingual Follow-Up Question Assistant developed by Spotline Inc.
						
					JSON OUTPUT REQUIREMENT:
                    CRITICAL: Your response will be automatically structured as JSON with these fields:
                    - "suggestedQuestions": Array of 2-3 suggested questions plus helpful resources text
                    - "translatedHeader": Translated version of the headerLine
                    - "helpfulResourcesText": Translation of 'Helpful Resources'
                    - "createTicketText": Translation of 'Create Ticket'
                    Do NOT include any text outside the JSON structure. Do NOT add markdown code blocks or explanatory text.
                
					Task:
					Using ONLY the conversation history below, generate 2-3 suggested questions by reframing questions that the assistant successfully answered and translate headerLine in [FULL_LANGUAGE_NAME] language.
					
					CRITICAL LANGUAGE PROTOCOL:
					• The target language is [FULL_LANGUAGE_NAME] (ISO code [USER_LANGUAGE_CODE])
					• Produce your ENTIRE response strictly in [FULL_LANGUAGE_NAME]
					• Translate both suggestedQuestions and translatedHeader to [FULL_LANGUAGE_NAME]
					• Never switch languages or mention detection/translation
					
					TASK:
					1. Identify user questions that received complete answers from the assistant
					2. Reframe these questions while keeping the same meaning and avoid including foreign terms which are not present
					3. Focus on questions where the assistant provided detailed, factual responses
					4. Translate all output to [FULL_LANGUAGE_NAME], including:
					  • suggestedQuestions array
					  • translatedHeader (from [HEADER_LINE])
					  • createTicketText (translate "Create Ticket")
					  • helpfulResourcesText (translate "Helpful Resources")
					
					CRITICAL REQUIREMENTS:
					• Only reframe questions that the assistant actually answered (not unanswered or partial responses)
					• Use different wording but maintain the same intent/topic without using new complex terms
					• Questions should NOT be follow-ups - they should be alternative ways to ask the same thing
					• If fewer than 2 reframable questions exist, return empty suggestedQuestions array
					• ALL output must be in [FULL_LANGUAGE_NAME]
					
					Reframing Guidelines:
					• Original: "What data does Ecosphere provide?" → Reframed: "What information is available from Ecosphere?"
					• Original: "How are transport emissions calculated?" → Reframed: "What method is used for transport emission calculations?"
					• Original: "What are the main themes?" → Reframed: "Which key areas are covered?"
					
					Quality Checks:
					- Was this question answered by the assistant? (Must be Yes)
					- Is the reframed question asking for the same information? (Must be Yes) \s
					- Is it worded differently from the original? (Must be Yes)
					- Is the entire output in [FULL_LANGUAGE_NAME]? (Must be Yes)
					- Are createTicketText and helpfulResourcesText properly translated? (Must be Yes)
					
					Output Format (ALL in [FULL_LANGUAGE_NAME]):
					{
					  "suggestedQuestions": ["reframed_question1", "reframed_question2", "reframed_question3"],
					  "translatedHeader": "[HEADER_LINE]",
					  "createTicketText": "Create Ticket translated to [FULL_LANGUAGE_NAME]",
					  "helpfulResourcesText": "Helpful Resources translated to [FULL_LANGUAGE_NAME]"
					}
					
					***Past Conversation***:
			
                """;

        }

        promptToUse = promptToUse
                .replace("[HEADER_LINE]",        headerLine)
                .replace("[FULL_LANGUAGE_NAME]", fullLanguage)
                .replace("[USER_LANGUAGE_CODE]", userLangCode)
                .replace("[USER_RESPONSE]",      answer);

        /* ───────────────────────── 4. MESSAGE BUILDING ─────────────────────────── */
        List<Message> messages = new ArrayList<>();
        String systemContent  = promptToUse + "\n\nInput:\n" + inputJson.toPrettyString();
        messages.add(new Message("system", systemContent));

        // Add previous messages so the LLM keeps chat continuity
        if(isPastConvo) {
            if (previousMessages != null && !previousMessages.isEmpty()) {
                for (PreviousMessages pm : previousMessages) {
                    if (pm.getUserMessage() != null && !pm.getUserMessage().isBlank()) {
                        messages.add(new Message("user", pm.getUserMessage()));
                    }
                    if (pm.getBotMessage() != null && !pm.getBotMessage().isBlank()) {
                        messages.add(new Message("assistant", pm.getBotMessage()));
                    }
                }
            }
        }

            ChatResponse resp = geminiService.createExtendedSuggestedQuestionsCompletion(messages, maxTokens, temperature);

        String raw = resp.getChoices().get(0).getMessage().getContent();

        try {
            // Try to extract and parse JSON from potentially mixed response
            String cleanedJson = extractJsonFromSuggestedQuestionsResponse(raw);
            JsonNode root = mapper.readTree(cleanedJson);

            // Extract suggested questions
            List<String> suggestedQs;
            if (root.has("suggestedQuestions") && root.get("suggestedQuestions").isArray()) {
                suggestedQs = new ArrayList<>();
                for (JsonNode question : root.get("suggestedQuestions")) {
                    suggestedQs.add(question.asText());
                }
            } else {
                suggestedQs = List.of("Sorry, I could not generate follow-up questions.");
            }

            // Extract translated header
            String translatedHeader = root.has("translatedHeader") ?
                    root.get("translatedHeader").asText() : headerLine;

            // For past conversation mode, add resource options
            if(isPastConvo) {
                String resources = root.has("helpfulResourcesText") ?
                        root.get("helpfulResourcesText").asText() : "helpful resources";
                String ticket = root.has("createTicketText") ?
                        root.get("createTicketText").asText() : "create ticket";

                // Create mutable list and add resource options
                List<String> mutableSuggestions = new ArrayList<>(suggestedQs);
                mutableSuggestions.add(resources);
                mutableSuggestions.add(ticket);
                suggestedQs = mutableSuggestions;
            }

            // BUILD RETURN MAP
            Map<String, Object> result = new HashMap<>();
            result.put("response", suggestedQs);
            result.put("translatedHeader", translatedHeader);

            if (resp.getUsage() != null) {
                result.put("promptTokens", resp.getUsage().getPromptTokens());
                result.put("completionTokens", resp.getUsage().getCompletionTokens());
                result.put("totalTokens", resp.getUsage().getTotalTokens());
            }

            return result;

        } catch (Exception e) {
            log.error("Failed to parse JSON response for suggested questions: {}", raw, e);

            try {
                Map<String, Object> fallbackResult = parseMixedSuggestedQuestionsResponse(raw, headerLine, fullLanguage, isPastConvo);

                if (resp.getUsage() != null) {
                    fallbackResult.put("promptTokens", resp.getUsage().getPromptTokens());
                    fallbackResult.put("completionTokens", resp.getUsage().getCompletionTokens());
                    fallbackResult.put("totalTokens", resp.getUsage().getTotalTokens());
                }

                return fallbackResult;

            } catch (Exception fallbackException) {
                log.error("Fallback parsing also failed for suggested questions", fallbackException);

                // ULTIMATE FALLBACK
                Map<String, Object> errorResult = new HashMap<>();
                errorResult.put("response", List.of("Sorry, I could not generate follow-up questions."));
                errorResult.put("translatedHeader", headerLine);

                if (resp.getUsage() != null) {
                    errorResult.put("promptTokens", resp.getUsage().getPromptTokens());
                    errorResult.put("completionTokens", resp.getUsage().getCompletionTokens());
                    errorResult.put("totalTokens", resp.getUsage().getTotalTokens());
                }

                return errorResult;
            }
        }
    }


    @Async
    public void geminitrainBotDocuments(TrainDocumentRequest geminitrainDocumentRequest) {
        geminiVectorDocumentRepository.deleteBySiteIdAndSourceType(geminitrainDocumentRequest.getSiteId() , GeminiVectorDocuments.TRAIN_TYPE_DOCUMENT);
        log.info("train bot documents");
        StringBuilder responseBuilder = new StringBuilder();
        for (var entry : geminitrainDocumentRequest.getDocIdFileNameMap().entrySet()) {
            geminitrainDocumentRequest.setResourceId(entry.getKey());
            geminitrainDocumentRequest.setFileName(entry.getValue());
            geminitrainDocumentRequest.setSiteId(geminitrainDocumentRequest.getSiteId());

            String success = geminitrainBot(geminitrainDocumentRequest);
            responseBuilder.append(success).append("\n");
        }
        log.info(responseBuilder.toString());
    }

    public String geminitrainBot(TrainDocumentRequest geminitrainDocumentRequest) {
        String response = "";
        AiEngineTrainingStatus aiEngineTrainingStatus = new AiEngineTrainingStatus();
        aiEngineTrainingStatus.setDocumentId(geminitrainDocumentRequest.getResourceId());
        aiEngineTrainingStatus.setBotId(geminitrainDocumentRequest.getSiteId());
        aiEngineTrainingStatus.setFileName(geminitrainDocumentRequest.getFileName());
        aiEngineTrainingStatus.setEngineType(geminiConfigProperties.getEngineType());
        aiEngineTrainingStatus.setModelName(geminiConfigProperties.getModelName());
        aiEngineTrainingStatus.setEmbeddingModel(geminiConfigProperties.getEmbeddingModel());

        aiEngineTrainingStatus.setStatus("In-Progress");
        aiEngineTrainingStatus = trainingStatusRepository.save(aiEngineTrainingStatus);

        int totalEmbeddingCount = 0;
        try {
            Map<Integer, com.smartdocs.gpt.document.model.Document> documents = geminiDocumentService.processDocument(geminitrainDocumentRequest);

            Map<String, String> chunckMap = new HashMap<>();

            for (Map.Entry<Integer, com.smartdocs.gpt.document.model.Document> itr : documents.entrySet()) {

                int page = itr.getKey();
                com.smartdocs.gpt.document.model.Document document = itr.getValue();

                List<TextSegment> segments = documentService.split(document);

                List<String> batchTexts = new ArrayList<>();
                int currentBatchTokenCount = 0;

                for (TextSegment textSegment : segments) {
                    String segmentText = textSegment.text();

                    // Estimate token count for current segment (confirmed < 2048 tokens)
                    int segmentTokenCount = geminiDocumentService.estimateTokenCount(segmentText);

                    // Check if adding this segment would exceed limits
                    boolean wouldExceedTokenLimit = (currentBatchTokenCount + segmentTokenCount) > MAX_TOKENS_PER_BATCH;
                    boolean wouldExceedSegmentLimit = batchTexts.size() >= MAX_SEGMENTS_PER_BATCH;

                    // Process current batch if limits would be exceeded and batch is not empty
                    if ((wouldExceedTokenLimit || wouldExceedSegmentLimit) && !batchTexts.isEmpty()) {
                        totalEmbeddingCount += processBatch(batchTexts);

                        // Clear batch for next iteration
                        batchTexts.clear();
                        currentBatchTokenCount = 0;
                    }

                    // Add current segment to batch
                    batchTexts.add(segmentText);
                    currentBatchTokenCount += segmentTokenCount;

                    // Create vector document entry and get ID for batch processing
                    List<Double> embedding = geminiService.createEmbeddingInDouble(textSegment.text());
                    var vectorDocument = new GeminiVectorDocuments();
                    vectorDocument.setDocumentContent(textSegment.text());
                    vectorDocument.setEmbeddings(embedding);
                    vectorDocument.setPage(page);
                    vectorDocument.setSiteId(geminitrainDocumentRequest.getSiteId());
                    vectorDocument.setBotId(geminitrainDocumentRequest.getBotId());
                    vectorDocument.setDocumentId(geminitrainDocumentRequest.getResourceId());
                    vectorDocument.setDocumentName(geminitrainDocumentRequest.getFileName());
                    vectorDocument.setSourceType(GeminiVectorDocuments.TRAIN_TYPE_DOCUMENT);
                    vectorDocument = geminiVectorDocumentRepository.save(vectorDocument);
                    chunckMap.put(vectorDocument.getId(), textSegment.text());
                }
                // Process any remaining segments in the final batch
                if (!batchTexts.isEmpty()) {
                    totalEmbeddingCount += processBatch(batchTexts);
                }
                log.info("Total embeddings processed: " + totalEmbeddingCount);
            }
//            List<AiEngineFileDetails> fileDetailList = new ArrayList<>();
//
//            for (Map.Entry<String, String> itr : chunckMap.entrySet()) {
//                AiEngineFileDetails aiEngineFileDetails = new AiEngineFileDetails();
//                aiEngineFileDetails.setSiteId(geminitrainDocumentRequest.getSiteId());
//                aiEngineFileDetails.setDocumentType(geminitrainDocumentRequest.getDocumentCategory());
//                aiEngineFileDetails.setDocumentId(geminitrainDocumentRequest.getDocumentId());
//                aiEngineFileDetails.setSource(geminitrainDocumentRequest.getContent());
//                aiEngineFileDetails.setDbId(itr.getKey());
//                aiEngineFileDetails.setEngineType(AiEngineFileDetails.ENGINE_TYPE_AZURE);
//                fileDetailList.add(aiEngineFileDetails);
//            }
//
//            aiEngineFileDetailsRepository.saveAll(fileDetailList);
            aiEngineTrainingStatus.setEmbeddingTokens(totalEmbeddingCount);
            aiEngineTrainingStatus.setStatus("Completed");
            response = " Training Completed for file : " + geminitrainDocumentRequest.getFileName();

        } catch (Exception e) {
            response = " Some error occurred in file : " + geminitrainDocumentRequest.getFileName();
            aiEngineTrainingStatus.setErrorMessage(e.getMessage());
            log.info("Some Error occurred while training");
            aiEngineTrainingStatus.setStatus("Some error occurred");
            e.printStackTrace();
        }

        trainingStatusRepository.save(aiEngineTrainingStatus);
        return response;

    }

    public void deleteDocument(String documentId) {
//        aiEngineFileDetailsRepository.deleteByDocumentId(documentId);
        vectorDocumentsRepository.deleteByDocumentId(documentId);
    }

    public void deleteBot(String botId) {
        vectorDocumentsRepository.deleteBySiteId(botId);
    }

    public void deleteFile(String siteId, String documentId) {
        vectorDocumentsRepository.deleteBySiteIdAndDocumentId(siteId, documentId);
    }

    public void deleteURL(String url) {
        vectorDocumentsRepository.deleteByDocumentId(url);
    }

    private String markDownToHtml(String text) {
        Parser parser = Parser.builder().extensions(Arrays.asList(TablesExtension.create())).build();
        Node document = parser.parse(text);
        HtmlRenderer renderer = HtmlRenderer.builder().extensions(Arrays.asList(TablesExtension.create())).build();
        return renderer.render(document);
    }

    private List<String> extractIdsFromHtml(String html) {
        // Regex finds “Source Documents:” line and captures the bracketed list
        Pattern p = Pattern.compile("Source Documents:\\s*\\[([^\\]]*)\\]");
        Matcher m = p.matcher(html);
        if (!m.find()) return Collections.emptyList();
        String listContent = m.group(1).trim();
        if (listContent.isEmpty()) return Collections.emptyList();
        // Split on commas, trim whitespace
        return Arrays.stream(listContent.split(","))
                .map(String::trim)
                .collect(Collectors.toList());
    }


    private String cleanJsonResponse(String rawResponse) {
        if (rawResponse == null || rawResponse.trim().isEmpty()) {
            return "{}";
        }

        String cleaned = rawResponse.trim();

        // Handle multiple variations of markdown code blocks
        String[] patterns = {"```json", "```", "`"};

        // Remove starting patterns
        for (String pattern : patterns) {
            if (cleaned.startsWith(pattern)) {
                cleaned = cleaned.substring(pattern.length()).trim();
                break;
            }
        }

        // Remove ending patterns
        if (cleaned.endsWith("```")) {
            cleaned = cleaned.substring(0, cleaned.length() - 3).trim();
        }

        // Remove any leading/trailing text that isn't JSON
        // Find first { and last }
        int firstBrace = cleaned.indexOf('{');
        int lastBrace = cleaned.lastIndexOf('}');

        if (firstBrace != -1 && lastBrace != -1 && firstBrace < lastBrace) {
            cleaned = cleaned.substring(firstBrace, lastBrace + 1);
        }

        return cleaned;
    }


        private void makeQnaString(List<QnA> qnaList, StringBuilder st) {
        for (QnA q : qnaList) {
            st.append("question:" + q.getQuestion() + "\n");
            st.append("answer:" + q.getAnswer() + "\n\n");
        }

    }

    public int processBatch(List<String> batch) {
        try {
            // Call Gemini API to get token count for the batch
            int tokenCount = geminiService.countTokensForBatch(batch);
            log.info("Batch token count: {} for {} segments", tokenCount, batch.size());

            // Return the number of embeddings (one per text segment)
            return tokenCount;

        } catch (Exception e) {
            log.error("Error processing batch for token counting", e);
            // Return batch size as fallback
            return batch.size();
        }
    }

    // Helper method to extract JSON from mixed response
    private String extractJsonFromMixedResponse(String response) {
        if (response == null || response.trim().isEmpty()) {
            return "{}";
        }
        String trimmed = response.trim();
        if (trimmed.startsWith("{")) {
            return trimmed;
        }
        Pattern jsonBlockPattern = Pattern.compile("```json\\s*(\\{.*?\\})\\s*```", Pattern.DOTALL);
        Matcher matcher = jsonBlockPattern.matcher(response);
        if (matcher.find()) {
            return matcher.group(1);
        }

        int firstBrace = response.indexOf('{');
        int lastBrace = response.lastIndexOf('}');

        if (firstBrace != -1 && lastBrace != -1 && firstBrace < lastBrace) {
            return response.substring(firstBrace, lastBrace + 1);
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> jsonMap = new HashMap<>();
            jsonMap.put("response", response);
            jsonMap.put("sources", new ArrayList<>());
            return mapper.writeValueAsString(jsonMap);
        } catch (Exception e) {
            return "{\"response\":\"" + response.replace("\"", "\\\"") + "\",\"sources\":[]}";
        }
    }


    private String extractTextBeforeJson(String response) {
        if (response == null || response.trim().isEmpty()) {
            return "";
        }

        int jsonStart = response.indexOf("```json");
        if (jsonStart != -1) {
            return response.substring(0, jsonStart).trim();
        }

        int braceStart = response.indexOf('{');
        if (braceStart > 0) {
            return response.substring(0, braceStart).trim();
        }

        return response.trim();
    }

    private List<String> extractSourceIdsFromText(String response) {
        List<String> sources = new ArrayList<>();

        Pattern sourcesPattern = Pattern.compile("\"sources\"\\s*:\\s*\\[(.*?)\\]", Pattern.DOTALL);
        Matcher matcher = sourcesPattern.matcher(response);

        if (matcher.find()) {
            String sourcesContent = matcher.group(1);
            Pattern idPattern = Pattern.compile("\"([A-Z0-9]+)\"");
            Matcher idMatcher = idPattern.matcher(sourcesContent);

            while (idMatcher.find()) {
                sources.add(idMatcher.group(1));
            }
        }

        return sources;
    }


    // Helper method to extract JSON from mixed suggested questions response
    private String extractJsonFromSuggestedQuestionsResponse(String response) {
        if (response == null || response.trim().isEmpty()) {
            return "{}";
        }

        String trimmed = response.trim();

        // If it starts with {, try to parse as pure JSON
        if (trimmed.startsWith("{")) {
            return trimmed;
        }

        // Look for JSON block in markdown format
        Pattern jsonBlockPattern = Pattern.compile("```json\\s*(\\{.*?\\})\\s*```", Pattern.DOTALL);
        Matcher matcher = jsonBlockPattern.matcher(response);
        if (matcher.find()) {
            return matcher.group(1);
        }

        // Look for any JSON object
        int firstBrace = response.indexOf('{');
        int lastBrace = response.lastIndexOf('}');

        if (firstBrace != -1 && lastBrace != -1 && firstBrace < lastBrace) {
            return response.substring(firstBrace, lastBrace + 1);
        }

        // If no JSON found, try to extract from old cleanJsonResponse format
        String cleaned = cleanJsonResponse(response);
        if (!cleaned.equals(response)) {
            return cleaned;
        }

        // Create a basic structure if parsing completely fails
        return "{\"suggestedQuestions\":[\"Sorry, I could not generate follow-up questions.\"], \"translatedHeader\":\"" +
                response.replace("\"", "\\\"") + "\"}";
    }

    // Helper method to parse mixed suggested questions response
    private Map<String, Object> parseMixedSuggestedQuestionsResponse(String response, String headerLine,
                                                                     String fullLanguage, boolean isPastConvo) {
        Map<String, Object> result = new HashMap<>();

        try {
            // Try to extract questions from text before JSON
            List<String> questions = new ArrayList<>();
            String translatedHeader = headerLine;

            // Look for questions in the text part
            String textPart = extractTextBeforeJson(response);
            if (!textPart.isEmpty()) {
                // Simple extraction of lines that look like questions
                String[] lines = textPart.split("\n");
                for (String line : lines) {
                    line = line.trim();
                    if (line.endsWith("?") && line.length() > 5 && line.length() < 100) {
                        // Remove any numbering or bullet points
                        line = line.replaceAll("^\\d+\\.\\s*", "").replaceAll("^-\\s*", "").replaceAll("^\\*\\s*", "");
                        questions.add(line);
                    }
                }
            }

            // Try to extract from JSON part
            try {
                String jsonPart = extractJsonFromSuggestedQuestionsResponse(response);
                ObjectMapper mapper = new ObjectMapper();
                JsonNode jsonNode = mapper.readTree(jsonPart);

                if (jsonNode.has("suggestedQuestions") && jsonNode.get("suggestedQuestions").isArray()) {
                    questions.clear(); // Use JSON questions if available
                    for (JsonNode question : jsonNode.get("suggestedQuestions")) {
                        questions.add(question.asText());
                    }
                }

                if (jsonNode.has("translatedHeader")) {
                    translatedHeader = jsonNode.get("translatedHeader").asText();
                }

            } catch (Exception ignored) {
                // Continue with text-extracted questions
            }

            // Ensure we have at least some questions
            if (questions.isEmpty()) {
                questions.add("What are the main topics covered?");
                questions.add("Can you provide more details?");
                if (isPastConvo) {
                    questions.add("helpful resources");
                    questions.add("create ticket");
                }
            } else if (isPastConvo && questions.size() > 0) {
                questions.add("helpful resources");
                questions.add("create ticket");
            }

            result.put("response", questions);
            result.put("translatedHeader", translatedHeader);

        } catch (Exception e) {
            // Final fallback
            List<String> fallbackQuestions = List.of("Sorry, I could not generate follow-up questions.");
            result.put("response", fallbackQuestions);
            result.put("translatedHeader", headerLine);
        }

        return result;
    }
}