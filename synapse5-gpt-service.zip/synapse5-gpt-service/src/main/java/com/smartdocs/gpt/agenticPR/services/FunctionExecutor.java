package com.smartdocs.gpt.agenticPR.services;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.mongodb.client.AggregateIterable;
import com.smartdocs.gpt.agenticPR.DTO.*;
import com.smartdocs.gpt.agenticPR.models.*;
import com.smartdocs.gpt.agenticPR.repositories.*;
import com.smartdocs.gpt.openai.model.EmbeddingData;
import com.smartdocs.gpt.openai.service.OpenAIService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class FunctionExecutor {

    private final AdaptiveCardRepository adaptiveCardRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final AribaCatalogEmbeddingRepository aribaCatalogEmbeddingRepository;
    private final GetCommodityCodeDetails getCommodityCodeDetails;
    private final CatalogTransactionRepository catalogTransactionRepository;
    private final OpenAIService openAIService;
    private final MongoTemplate mongoTemplate;
    private final SupplierDataRepository supplierDataRepository;
    private final SupplierRepository supplierRepository;
    private final UserRepository userRepository;
    private final AribaUserRepository aribaUserRepository;
    private final UnitOfMeasureService unitOfMeasureService;
    private final GetPrefferedSuppliers getPrefferedSuppliers;

    public FunctionResponse startRequisition(String transactionId, String functionName, String rawJson) {
        try {
            JsonNode root = objectMapper.readTree(rawJson);
            String message = root.get("message").asText();

            List<String> productNames = new ArrayList<>();
            if (root.has("productName") && root.get("productName").isArray()) {
                for (JsonNode nameNode : root.get("productName")) {
                    productNames.add(nameNode.asText());
                }
            }

            String combinedQuery = String.join(" ", productNames);

            CatalogTransaction transaction = new CatalogTransaction(transactionId, combinedQuery);
            catalogTransactionRepository.save(transaction);

            switch (message) {
                case "productType":
                case "productName":
                    AdaptiveCardDto dto = getAdaptiveCard(message);
                    String cardJson = (dto != null) ? dto.getCardJson() : "{}";
                    return new FunctionResponse(functionName, cardJson, 1.0, null);
                case "searchCommodityCode":
                    log.info("searchCommodityCode invoked for transactionId={}", transactionId);
                    return searchCommodityCode(transactionId, "searchCommodityCode", combinedQuery , null);
                case "showPreferredSuppliers":
                    return showPreferredSuppliers(transactionId, combinedQuery);
                default:
                    log.warn("Unknown message type: {}", message);
                    return new FunctionResponse("error", "Unknown message type: " + message, 0.0, null);
            }

        } catch (Exception e) {
            log.error("Error in startRequisition: {}", e.getMessage(), e);
            return new FunctionResponse("error", e.getMessage(), 0.0, null);
        }
    }

    public AdaptiveCardDto getAdaptiveCard(String name) {
        return adaptiveCardRepository.findByName(name)
                .map(card -> new AdaptiveCardDto(card.getName(), card.getCardJson()))
                .orElse(null);
    }


    public FunctionResponse searchCatalog(String transactionId , String commodityCode , String commodityCodeName) {
        try {

            log.info("searchCatalog() started. transactionId={}, commodityCode={}", transactionId, commodityCode);
            CatalogTransaction catalogTransaction = catalogTransactionRepository.findTopByTransactionIdOrderByTimestampDesc(transactionId);
            String productName = catalogTransaction.getCombinedNames();

            EmbeddingData embeddingData = openAIService.createEmbeddingInDouble(productName);
            List<Double> queryEmbedding = embeddingData.getEmbedding();


            String regexPattern = ":" + commodityCode + "$";
            List<AribaCatalogEmbedding> results = aribaCatalogEmbeddingRepository.findByClassificationCodeRegex(regexPattern);

            if (results == null || results.isEmpty()) {
                log.warn("No catalog items found for commodityCode={}", commodityCode);

                return new FunctionResponse(
                        "NON_CATALOG_REQUEST",
                        "nonCatalogRequest",
                        1.0,
                        List.of(
                                Map.of(
                                        "productName", productName,
                                        "commodityCode", commodityCode,
                                        "commodityCodeName", commodityCodeName
                                )
                        )
                );
            }

            List<String> filteredIds = results.stream()
                    .map(AribaCatalogEmbedding::getId)
                    .toList();

            Document filter = new Document("_id", new Document("$in" , filteredIds));

            List<Bson> pipeline = Arrays.asList(
                    new Document("$vectorSearch",
                            new Document("index", "vector_index")
                                    .append("path", "embedding")
                                    .append("filter", filter)
                                    .append("queryVector", queryEmbedding)
                                    .append("numCandidates", 50)
                                    .append("limit", 5)
                    )
            );


            AggregateIterable<Document> result = mongoTemplate
                    .getCollection("newAribaCatalogEmbeddings")
                    .aggregate(pipeline);

            List<CatalogItem> dataList = new ArrayList<>();

            for (Document doc : result) {
                AribaCatalogEmbedding entity = mongoTemplate.getConverter().read(AribaCatalogEmbedding.class, doc);

                String unitCode = null;
                if (entity.getUnitOfMeasure() != null && entity.getUnitOfMeasure().contains(":")) {
                    unitCode = entity.getUnitOfMeasure().split(":")[1];
                }

                String supplierId = null;
                if (entity.getSupplierId() != null && entity.getSupplierId().contains(":")) {
                    supplierId = entity.getSupplierId().split(":")[1];
                }

                CatalogItem dto = new CatalogItem();
                dto.setId(entity.getId());
                dto.setProductName(entity.getShortName());
                dto.setImageUrl(entity.getUrl());
                dto.setSupplierId(supplierId);
                dto.setSupplierName(entity.getSupplierName());
                dto.setPriceAmount(entity.getPriceAmount());
                dto.setCurrency(entity.getContractPriceCurrencyUniqueName());
                dto.setUom(unitCode);
                dto.setCommodityCode(commodityCode);
                dto.setCommodityCodeName(commodityCodeName);


                dataList.add(dto);
            }

            FunctionResponse response = new FunctionResponse("CATALOGSEARCH"  , "catalogMatches", 1.0 , dataList);
            return response;

        } catch (Exception e) {
            log.error("Error in searchCatalog for transactionId={}: {}", transactionId, e.getMessage(), e);
            return new FunctionResponse("error", e.getMessage(), 0.0, Collections.emptyList());
        }
    }

    public FunctionResponse searchCommodityCode(String transactionId, String functionName, String combinedQuery, String commodityCode) {

        EmbeddingData embeddingData = openAIService.createEmbeddingInDouble(combinedQuery);
        List<Double> queryEmbeddings = embeddingData.getEmbedding();

        List<CommodityCodeDocument> document = getCommodityCodeDetails.runVectorSearchOnMultiple(queryEmbeddings);

        if (document == null || document.isEmpty()) {
            log.info("No commodity codes found for query='{}'", combinedQuery);
            AdaptiveCardDto emptyCard = getAdaptiveCard("commodityCodeNotIdentified");
            String emptyCardJson = (emptyCard != null) ? emptyCard.getCardJson() : "{}";

            return new FunctionResponse(
                    "NO_COMMODITY_FOUND",
                    emptyCardJson,
                    1.0,
                    List.of("No matching commodity codes found for your query.")
            );
        }
        CommodityCodeDocument selectedDoc;
        String adaptiveCardKey;

        if (commodityCode == null || commodityCode.isEmpty()) {
            log.info("No existing commodityCode provided. Selecting top match. Got Call By LLM Only");
            selectedDoc = document.get(0);
            adaptiveCardKey = "commodityCodeIdentified";
        } else {
            log.info("Existing commodityCode provided. Finding alternative suggestion.");
            selectedDoc = document.stream()
                    .filter(doc -> !commodityCode.equalsIgnoreCase(doc.getCommodityCode()))
                    .findFirst()
                    .orElse(document.get(0));
            adaptiveCardKey = "commodityCodeSuggestion";
        }
        CommodityInfoDTO selectedCommodity = new CommodityInfoDTO(
                selectedDoc.getCommodityCode(),
                selectedDoc.getName(),
                combinedQuery
        );
        AdaptiveCardDto dto = getAdaptiveCard(adaptiveCardKey);
        String cardJson = (dto != null) ? dto.getCardJson() : "{}";

        log.info("Returning response for commodityCode={}, cardType={}", selectedCommodity.getCommodityCode(), adaptiveCardKey);
        return new FunctionResponse(functionName, cardJson, 1.0, List.of(selectedCommodity));
    }

    public Document searchTopMatches(String userQuery) {
        EmbeddingData embeddingData = openAIService.createEmbeddingInDouble(userQuery);
        List<Double> queryEmbedding = embeddingData.getEmbedding();

        List<Bson> pipeline = List.of(
                new Document("$vectorSearch",
                        new Document("index", "vector_index")
                                .append("path", "embedding")
                                .append("queryVector", queryEmbedding)
                                .append("numCandidates", 100)
                                .append("limit", 1)
                                .append("filter", new Document("embedding", new Document("$exists", true)))
                ),
                new Document("$project",
                        new Document("_id", 0)
                                .append("uniqueName", 1)
                                .append("name", 1)
                                .append("score", new Document("$meta", "vectorSearchScore")))
        );

        AggregateIterable<Document> result = mongoTemplate
                .getCollection("newAribaCommodityCode")
                .aggregate(pipeline);


        Document topMatch = result.first();
        return topMatch;
    }

    public NonCatalogReview nonCatalogReview(String transactionId , String commodityCode , String commodityName){

        CatalogTransaction catalogTransaction = catalogTransactionRepository.findTopByTransactionIdOrderByTimestampDesc(transactionId);
        String productName = catalogTransaction.getCombinedNames();

        NonCatalogReview nonCatalogReview = new NonCatalogReview();
        nonCatalogReview.setProductName(productName);

        List<String> uomDocs = unitOfMeasureService.suggestTopUOMs(productName);
//        List<String> formattedUoms = uomDocs.stream()
//                .map(uom -> uom.getUniqueName() + " (" + uom.getDescription() + ")")
//                .collect(Collectors.toList());

        nonCatalogReview.setUom(uomDocs);
        nonCatalogReview.setCommodityCode(commodityCode);
        nonCatalogReview.setCommodityCodeName(commodityName);
        List<String> currencies = List.of("USD", "EUR", "INR");
        nonCatalogReview.setCurrency(currencies);

        return nonCatalogReview;
    }

    public FunctionResponse showPreferredSuppliers(String transactionId, String productName) {
        try {
            EmbeddingData embeddingData = openAIService.createEmbeddingInDouble(productName);
            List<Double> queryEmbeddings = embeddingData.getEmbedding();
            List<CommodityCodeDocument> commodityMatches =
                    getCommodityCodeDetails.runVectorSearchOnMultiple(queryEmbeddings);

            CommodityCodeDocument topMatch = commodityMatches.get(0);
            String topCommodityCode = topMatch.getCommodityCode();
            List<NewSupplierData> suppliers = getPrefferedSuppliers.getTop5Suppliers(topCommodityCode);

            if (suppliers == null || suppliers.isEmpty()) {
                AdaptiveCardDto dto = getAdaptiveCard("noPreferredSuppliersFound");
                String cardJson = (dto != null) ? dto.getCardJson() : "{}";
                return new FunctionResponse("NO_SUPPLIERS_FOUND",
                        cardJson,
                        1.0,
                        List.of("No matching suppliers found for your product name."));
            }

            Map<String, Object> supplierResponse = new HashMap<>();
            supplierResponse.put("commodityCode", topCommodityCode);
            supplierResponse.put("commodityName", topMatch.getName());
            supplierResponse.put("suppliers", suppliers);

            AdaptiveCardDto dto = getAdaptiveCard("preferredSuppliersCard");
            String cardJson = (dto != null) ? dto.getCardJson() : "{}";

            return new FunctionResponse("SHOW_PREFERRED_SUPPLIERS",
                    cardJson,
                    1.0,
                    List.of(supplierResponse));
        }
        catch (Exception e) {
            return new FunctionResponse("error", e.getMessage(), 0.0, null);
        }
    }

}




//    public NonCatalogReview nonCatalogReview(String channelId, String title, String commodityCode) {
//
//            User user = userRepository.findByChannelValueAndChannelType(channelId, "MSTeams")
//                    .orElseThrow(() -> new RuntimeException("User not found for channelId: " + channelId));
//
//            String aribaUserId = user.getAribaUserId();
//
//            AribaUser aribaUser = aribaUserRepository.findByUniqueName(aribaUserId)
//                    .orElseThrow(() -> new RuntimeException("AribaUser not found for id: " + aribaUserId));
//
//            NonCatalogReview nonCatalogReview = new NonCatalogReview();
//
//            nonCatalogReview.setTitle(title);
//            nonCatalogReview.setCommodityCode(commodityCode);
//
//        String numericCommodityCode = commodityCode.split(" ")[0].trim();
//        List<SupplierData> supplierDataList = supplierDataRepository.findByCommodityCode(numericCommodityCode);
//            List<Integer> supplierIds = supplierDataList.stream()
//                    .map(SupplierData::getSupplierId)
//                    .distinct()
//                    .toList();
//
//            List<Supplier> suppliers = supplierRepository.findBySupplierIdIn(supplierIds);
//            List<String> supplierNames = suppliers.stream()
//                    .map(Supplier::getSupplierName)
//                    .toList();
//
//            nonCatalogReview.setVendors(supplierNames);
//
//
//        List<AribaUnitOfMeasure> uomDocs = unitOfMeasureService.suggestTopUOMs(title);
//        List<String> formattedUoms = uomDocs.stream()
//                .map(uom -> uom.getUniqueName() + " (" + uom.getDescription() + ")")
//                .collect(Collectors.toList());
//
//        nonCatalogReview.setUom(formattedUoms);
//
//
//            AccountingDTO accounting = new AccountingDTO(
//                    aribaUser.getGeneralLedgerAccount(),
//                    aribaUser.getCostCenter()
//            );
//
//            ShippingDTO shipping = new ShippingDTO(
//                    aribaUser.getPlant(),
//                    aribaUser.getPurchasingGroup()
//            );
//
//        List<CompanyCodeDTO> companyCodeDTOList = new ArrayList<>();
//        for (CompanyCodeDTO companyCode : aribaUser.getCompanyCodes()) {
//            CompanyCodeDTO dto = new CompanyCodeDTO(
//                    companyCode.getDisplayId(),
//                    companyCode.getCompanyCodeDescription()
//            );
//            companyCodeDTOList.add(dto);
//        }
//
//        List<PurchasingOrgDTO> purchasingOrgDTOS = new ArrayList<>();
//        for (PurchasingOrgDTO purchasingOrgDTO : aribaUser.getPurchasingOrganization()) {
//            PurchasingOrgDTO dto = new PurchasingOrgDTO(
//                    purchasingOrgDTO.getDisplayId(),
//                    purchasingOrgDTO.getPurchasingOrganizationDescription()
//            );
//            purchasingOrgDTOS.add(dto);
//        }
//
//        nonCatalogReview.setCompanyCodes(companyCodeDTOList);
//        nonCatalogReview.setPurchasingOrganization(purchasingOrgDTOS);
//
//
//            nonCatalogReview.setAccounting(accounting);
//            nonCatalogReview.setShipping(shipping);
//            nonCatalogReview.setDeliverTo(aribaUser.getDeliverTo());
//
//            return nonCatalogReview;
//
//    }

//    public NonCatalogReview servicePrReview(String channelId, String title, String commodityCode) {
//
//        User user = userRepository.findByChannelValueAndChannelType(channelId, "MSTeams")
//                .orElseThrow(() -> new RuntimeException("User not found for channelId: " + channelId));
//
//        String aribaUserId = user.getAribaUserId();
//
//        AribaUser aribaUser = aribaUserRepository.findByUniqueName(aribaUserId)
//                .orElseThrow(() -> new RuntimeException("AribaUser not found for id: " + aribaUserId));
//
//        NonCatalogReview nonCatalogReview = new NonCatalogReview();
//
//        nonCatalogReview.setTitle(title);
//        nonCatalogReview.setCommodityCode(commodityCode);
//
//        String numericCommodityCode = commodityCode.split(" ")[0].trim();
//        List<SupplierData> supplierDataList = supplierDataRepository.findByCommodityCode(numericCommodityCode);
//        List<Integer> supplierIds = supplierDataList.stream()
//                .map(SupplierData::getSupplierId)
//                .distinct()
//                .toList();
//
//        List<Supplier> suppliers = supplierRepository.findBySupplierIdIn(supplierIds);
//        List<String> supplierNames = suppliers.stream()
//                .map(Supplier::getSupplierName)
//                .toList();
//
//        nonCatalogReview.setVendors(supplierNames);
//
//        AccountingDTO accounting = new AccountingDTO(
//                aribaUser.getGeneralLedgerAccount(),
//                aribaUser.getCostCenter()
//        );
//
//        ShippingDTO shipping = new ShippingDTO(
//                aribaUser.getPlant(),
//                aribaUser.getPurchasingGroup()
//        );
//
//        List<CompanyCodeDTO> companyCodeDTOList = new ArrayList<>();
//        for (CompanyCodeDTO companyCode : aribaUser.getCompanyCodes()) {
//            CompanyCodeDTO dto = new CompanyCodeDTO(
//                    companyCode.getDisplayId(),
//                    companyCode.getCompanyCodeDescription()
//            );
//            companyCodeDTOList.add(dto);
//        }
//
//        List<PurchasingOrgDTO> purchasingOrgDTOS = new ArrayList<>();
//        for (PurchasingOrgDTO purchasingOrgDTO : aribaUser.getPurchasingOrganization()) {
//            PurchasingOrgDTO dto = new PurchasingOrgDTO(
//                    purchasingOrgDTO.getDisplayId(),
//                    purchasingOrgDTO.getPurchasingOrganizationDescription()
//            );
//            purchasingOrgDTOS.add(dto);
//        }
//
//        nonCatalogReview.setCompanyCodes(companyCodeDTOList);
//        nonCatalogReview.setPurchasingOrganization(purchasingOrgDTOS);
//
//
//        nonCatalogReview.setAccounting(accounting);
//        nonCatalogReview.setShipping(shipping);
//        nonCatalogReview.setDeliverTo(aribaUser.getDeliverTo());
//
//        return nonCatalogReview;
//
//    }