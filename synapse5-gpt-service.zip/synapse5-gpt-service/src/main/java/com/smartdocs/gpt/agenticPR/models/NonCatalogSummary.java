package com.smartdocs.gpt.agenticPR.models;

import com.smartdocs.gpt.agenticPR.DTO.LineItemsSummaryDTO;
import lombok.Data;
import org.springframework.data.annotation.Id;

import java.util.List;


@Data
public class NonCatalogSummary {

    @Id
    private String Id;

    private String title;
    private String companyCode;
    private String purchasingOrganization;
    private String needByDate;
    private String startDate;
    private String endDate;
    private String deliverTo;
    private String comments;
    private String uom;
    private String vendor;
    private String commodityCode;
    private String quantity;
    private String glAccount;
    private String costCenter;
    private String plant;
    private String purchaseGroup;
    private String estimatedAmount;
}

