package com.smartdocs.gpt.agenticPR.services;

import com.smartdocs.gpt.agenticPR.models.NewSupplierData;
import com.smartdocs.gpt.agenticPR.repositories.NewSupplierDataRepository;
import lombok.Data;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SupplierExcelImportService {

    @Autowired
    private NewSupplierDataRepository repository;

    public String importSupplierData(MultipartFile file) throws Exception {

        Workbook workbook = WorkbookFactory.create(file.getInputStream());

        Sheet qualificationSheet = workbook.getSheet("Qualification_Rework");
        Sheet preferredSheet = workbook.getSheet("PreferredSuppliersExport_Rework");

        Map<String, PreferredRow> preferredMap = new HashMap<>();

        for (int i = 1; i <= preferredSheet.getLastRowNum(); i++) {
            Row row = preferredSheet.getRow(i);
            if (row == null) continue;

            String vendorIdRaw = getString(row.getCell(1));
            String vendorId = normalizeVendorId(vendorIdRaw);
            String category = getString(row.getCell(3));

            String key = vendorId + "_" + category;

            PreferredRow pr = new PreferredRow();
            pr.vendorId = vendorId;
            pr.category = category;
            pr.supplierName = getString(row.getCell(2));
            pr.region = getString(row.getCell(4));
            pr.businessUnit = getString(row.getCell(5));
            pr.level = getString(row.getCell(8));
            pr.active = getBoolean(row.getCell(9));

            preferredMap.put(key, pr);
        }

        List<NewSupplierData> finalList = new ArrayList<>();

        for (int i = 1; i <= qualificationSheet.getLastRowNum(); i++) {
            Row row = qualificationSheet.getRow(i);
            if (row == null) continue;

            String vendorId = getString(row.getCell(0));
            String type = getString(row.getCell(1));
            String categoryIds = getString(row.getCell(2));
            String regionIds = getString(row.getCell(3));
            String departmentIds = getString(row.getCell(4));
            String status = getString(row.getCell(6));
            String erpVendorIdRaw = getString(row.getCell(8));
            String sourceSystem = getString(row.getCell(9));

            String normalizedErpVendorId = normalizeVendorId(erpVendorIdRaw);
            String key = normalizedErpVendorId + "_" + categoryIds;

            NewSupplierData data = new NewSupplierData();
            data.setVendorId(vendorId);
            data.setType(type);
            data.setCategoryIds(categoryIds);
            data.setRegionIds(regionIds);
            data.setDepartmentIds(departmentIds);
            data.setStatus(status);
            data.setErpVendorId(erpVendorIdRaw);
            data.setSourceSystem(sourceSystem);

            PreferredRow pr = preferredMap.get(key);

            if (pr != null) {
                data.setSupplierName(pr.supplierName);
                data.setSupplierRegion(pr.region);
                data.setBusinessUnit(pr.businessUnit);
                data.setLevel(pr.level);
                data.setActive(pr.active);

            } else {
                data.setSupplierName(null);
                data.setSupplierRegion(null);
                data.setBusinessUnit(null);
                data.setLevel(null);
                data.setActive(null);
            }

            finalList.add(data);
        }

        repository.saveAll(finalList);

        return "Imported successfully! Total rows saved: " + finalList.size();
    }

    private String getString(Cell cell) {
        if (cell == null) return null;
        cell.setCellType(CellType.STRING);
        String s = cell.getStringCellValue();
        return (s == null) ? null : s.trim();
    }

    private Boolean getBoolean(Cell cell) {
        if (cell == null) return null;
        if (cell.getCellType() == CellType.BOOLEAN) return cell.getBooleanCellValue();
        String v = getString(cell);
        if (v == null) return null;
        v = v.trim().toLowerCase();
        return v.equals("true") || v.equals("1") || v.equals("yes");
    }

    private String normalizeVendorId(String id) {
        if (id == null) return null;
        id = id.trim();
        if (!id.matches("\\d+")) return id;
        while (id.length() < 10) id = "0" + id;
        return id;
    }

    @Data
    static class PreferredRow {
        String vendorId;
        String category;
        String supplierName;
        String region;
        String businessUnit;
        String level;
        Boolean active;
    }
}
