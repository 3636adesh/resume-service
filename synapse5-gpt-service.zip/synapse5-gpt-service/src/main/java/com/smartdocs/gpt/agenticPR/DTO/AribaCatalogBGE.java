package com.smartdocs.gpt.agenticPR.DTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "aribaCatalog_bge")
public class AribaCatalogBGE {

    @Id
    private String id;

    private String shortName;
    private Double priceAmount;
    private String priceCurrencyUniqueName;
    private String supplierName;
    private String unitOfMeasure;
    private String imageUrl;
    private String segmentCode;
    private List<Double> embedding;

    private Date timestamp = new Date();
}
