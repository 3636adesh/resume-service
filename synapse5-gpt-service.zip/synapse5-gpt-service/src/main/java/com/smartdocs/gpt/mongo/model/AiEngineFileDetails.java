package com.smartdocs.gpt.mongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document
@NoArgsConstructor
@AllArgsConstructor
@Data
public class AiEngineFileDetails {

	public static final String ENGINE_TYPE_AZURE = "AzureOpenAI";
	public static final String ENGINE_TYPE_GEMINI = "GeminiAI";

	@Id
	private String id;
	private String siteId;
	private String documentType;
	private String documentId;
	private String source;
	private String dbId;
	private String engineType;

	public AiEngineFileDetails(String siteId, String documentType, String documentId, String source) {
		super();
		this.siteId = siteId;
		this.documentType = documentType;
		this.documentId = documentId;
		this.source = source;
	}
	
	public AiEngineFileDetails(String siteId, String documentType, String documentId, String source, String dbId , String engineType) {
		this(siteId, documentType, documentId, source);
	    this.dbId=dbId;
		this.engineType = engineType;
	}


}
