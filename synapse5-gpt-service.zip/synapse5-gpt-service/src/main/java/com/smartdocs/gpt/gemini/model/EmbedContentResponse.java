package com.smartdocs.gpt.gemini.model;

import lombok.Data;

import java.util.List;

@Data
public class EmbedContentResponse {

    private Embedding embedding;

    public static class Embedding {
        private List<Float> values;

        public List<Float> getValues() {
            return values;
        }

        public void setValues(List<Float> values) {
            this.values = values;
        }
    }
}
