package com.smartdocs.gpt.agenticPR.models;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "aribaUnitOfMeasure")
@Data
public class AribaUnitOfMeasure {

    @Id
    private String id;

    private String name;
    private String uniqueName;
    private String description;
}
