package com.smartdocs.gpt.intentRecognition.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "utteranceEmbeddings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UtteranceEmbeddingDocuments {

    @Id
    private String id;

    private String utteranceText;
    private String siteId;
    private String label;
    private String description;

    @Indexed(name = "vector_index", direction = IndexDirection.ASCENDING)
    private List<Double> embeddings;

    private Integer embeddingDimension;
    private String embeddingModel;
    private Integer tokensUsed;
    private String intentId;
    private String botId;
}
