package com.smartdocs.gpt.agenticPR.DTO;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PreviousPurchaseDTO {

    private String lastOrderNumber;
    private String lastVendorName;

}
