package com.smartdocs.gpt.agenticPR.DTO;


import lombok.Data;

@Data
public class LineItemsSummaryDTO {
    private String id;

    private String productName;
    private String costCenter;
    private String glAccount;
    private String needByDate;
    private String plant;
    private String purchaseGroup;
    private String quantity;
    private String vendor;
    private String commodityCode;
}
