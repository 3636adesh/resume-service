package com.smartdocs.gpt.agenticPR.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartdocs.gpt.agenticPR.DTO.AdaptiveCardDto;
import com.smartdocs.gpt.agenticPR.DTO.CommodityInfoDTO;
import com.smartdocs.gpt.agenticPR.models.*;
import com.smartdocs.gpt.agenticPR.repositories.*;
import com.smartdocs.gpt.openai.config.AgentConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ChatService {

    private final RestTemplate restTemplate;
    private final SystemPromptRepository systemPromptRepo;
    private final AgentConfigService configService;
    private final AiFunctionRepository functionRepo;
    private final FunctionExecutor functionExecutor;
    private final ChatMessageRepository chatMessageRepo;
    private final ItemSelectionsRepository itemSelectionsRepository;
    private final ShowItemDetailsService showItemDetailsService;
    private final PrDataRepository prDataRepository;
    private final GetPrefferedSuppliers getPrefferedSuppliers;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public AgentResponse handleUserQuery(
            String channelId,
            String userQuery,
            String transactionId,
            List<CatalogItem> lineItems,
            CatalogSummary userDefaults,
            String action,
            String productName,
            String commodityCode,
            String commodityCodeName,
            NonCatalogSummary nonCatalogSummary,
            String description
    ) throws Exception {

        if (transactionId == null || transactionId.isEmpty()) {
            transactionId = UUID.randomUUID().toString();
        }

        if (action == null) action = "";

        return switch (action) {
            // case "service_pr_review" -> servicePrReview(channelId , title , commodityCode , transactionId);
            // case "pr_review_proceed" -> buildAgentResponse("SHOW_ITEMS_SUMMARY", "summaryCard", userDefaults, transactionId);
            //  case "non_catalog_request" -> handleSuggestionsForCommodityCodes(transactionId);

            case "submit_pr" -> submitPr(transactionId);
            case "non_catalog_review" -> nonCatalogReview(transactionId , commodityCode , commodityCodeName);
            case "change_commodity_code" -> buildAgentResponse("CHANGE_COMMODITY_CODE", "commodityCodeCurrentFlow", buildCommodityInfo(commodityCode, commodityCodeName, productName), transactionId);
            case "suggest_another_commodity_code" -> suggestAnotherCommodityCode(transactionId , "ANOTHER_COMMODITY_CODE" , productName , commodityCode);
            case "search_for_catalog" -> searchCatalog(transactionId , commodityCode , commodityCodeName);
            case "catalog_select_proceed" -> buildAgentResponse("CATALOG_SELECT_PROCEED" , "catalogSelectProceed" , lineItems ,  transactionId);
            case "show_supplier_data" , "change_supplier_data" -> showSupplierData(action , transactionId , lineItems , commodityCode , commodityCodeName, description);
            case "show_user_defaults"  -> handleCatalogSelect( transactionId, channelId, lineItems , commodityCode , commodityCodeName , description );
            case "show_catalog_summary" , "change_address" , "change_accounting" -> showCatalogSummary(transactionId , action , userDefaults , commodityCode , commodityCodeName );
            case "non_catalog_submit" -> buildAgentResponse("NON_CATALOG_SUMMARY", "nonCatalogSummary" , nonCatalogSummary, transactionId);
            case "service_pr_review_submit" -> buildAgentResponse("SERVICE_PR_REVIEW_SUBMIT" , "servicePrSummary" , nonCatalogSummary , transactionId);
            default -> handleChatConversation(transactionId, channelId, userQuery);
        };
    }


    private AgentResponse handleCatalogSelect( String transactionId, String channelId, List<CatalogItem> lineItems , String commodityCode , String commodityCodeName, String description) {
        Boolean isEstimatedPriceAvailable =
                lineItems != null &&
                        !lineItems.isEmpty() &&
                        lineItems.get(0).getEstimatedPrice() != null;
        itemSelectionsRepository.save(new ItemSelections(null, transactionId, channelId, lineItems, commodityCode , commodityCodeName  , System.currentTimeMillis() , null , null , null , null , null , null , null , description , isEstimatedPriceAvailable, null));

        ShowUserDefaults details = showItemDetailsService.getItemDetails( channelId , commodityCode , commodityCodeName);
        return buildAgentResponse("GET_TAXANOMY_DETAILS", "showUserDefaults", details, transactionId);
    }

    private AgentResponse showSupplierData(String action , String transactionId , List<CatalogItem> lineItems , String commodityCode , String commodityName , String description) {

        Map<String, Object> responseData = new HashMap<>();
        String adaptiveCardKey;
        responseData.put("lineItems", lineItems);
        responseData.put("commodityCode", commodityCode);
        responseData.put("commodityName", commodityName);
        responseData.put("description", description);


        if ("show_supplier_data".equalsIgnoreCase(action)) {
            List<NewSupplierData> suppliers = getPrefferedSuppliers.getTop5Suppliers(commodityCode);
            adaptiveCardKey = "showSupplierData";
            responseData.put("supplierNames", suppliers);
        }else{
            adaptiveCardKey = "changeSupplierData";
        }

        return  buildAgentResponse("SUPPLIERDATA" , adaptiveCardKey , responseData , transactionId);
    }

    private AgentResponse showCatalogSummary(String transactionId , String action , CatalogSummary userDefaults,  String commodityCode , String commodityCodeName  ){
      ItemSelections items = itemSelectionsRepository.findFirstByTransactionIdOrderByTimestampDesc(transactionId);
        if (items == null) {
            throw new RuntimeException("No ItemSelections found for transactionId: " + transactionId);
        }

        if ("change_address".equalsIgnoreCase(action)) {
            items.setCostCenter(userDefaults.getCostCenter());
            items.setGlAccount(userDefaults.getGlAccount());
            items.setCompanyCode(userDefaults.getCompanyCode());
            items.setPlant(userDefaults.getPlant());
            items.setPurchasingGroup(userDefaults.getPurchasingGroup());
            items.setPurchasingOrganization(userDefaults.getPurchasingOrganization());
            itemSelectionsRepository.save(items);
            return buildAgentResponse("SHOW_CATALOG_SUMMARY", "changeAddress", items, transactionId);

        } else if ("change_accounting".equalsIgnoreCase(action)) {
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("costCenter", userDefaults.getCostCenter());
            responseData.put("glAccount", userDefaults.getGlAccount());
            responseData.put("companyCode", userDefaults.getCompanyCode());
            responseData.put("plant", userDefaults.getPlant());
            responseData.put("purchasingGroup", userDefaults.getPurchasingGroup());
            responseData.put("purchasingOrganization", userDefaults.getPurchasingOrganization());

            return buildAgentResponse("CHANGE_ACCOUNTING", "changeAccounting", responseData, transactionId);
//            return buildAgentResponse("SHOW_CATALOG_SUMMARY", "changeAccounting", items, transactionId);
        } else if("show_catalog_summary".equalsIgnoreCase(action)){
            items.setCostCenter(userDefaults.getCostCenter());
            items.setGlAccount(userDefaults.getGlAccount());
            items.setCompanyCode(userDefaults.getCompanyCode());
            items.setPlant(userDefaults.getPlant());
            items.setDeliverTo(userDefaults.getDeliverTo());
            items.setCommodityCode(items.getCommodityCode());
            items.setCommodityCodeName(items.getCommodityCodeName());
            items.setPurchasingGroup(userDefaults.getPurchasingGroup());
            items.setPurchasingOrganization(userDefaults.getPurchasingOrganization());
        }

        itemSelectionsRepository.save(items);
        return buildAgentResponse("SHOW_CATALOG_SUMMARY", "catalogSummary", items, transactionId);

    }

    private CommodityInfoDTO buildCommodityInfo(String commodityCode, String commodityName, String productName) {
        return new CommodityInfoDTO(commodityCode, commodityName, productName);
    }

    private AgentResponse suggestAnotherCommodityCode(String transactionId , String functionName , String productName , String commodityCode){
        FunctionResponse response = functionExecutor.searchCommodityCode(transactionId , functionName , productName , commodityCode);
        return  new AgentResponse(response.getFunctionName(), response.getTemplate(), 1.0 ,  response.getData() , transactionId);
    }

    private AgentResponse nonCatalogReview(String transactionId , String commodityCode , String commodityCodeName){
        NonCatalogReview response = functionExecutor.nonCatalogReview(transactionId , commodityCode , commodityCodeName);
        return  buildAgentResponse("CatalogReview" , "nonCatalogReview" , response , transactionId);
    }

    private AgentResponse searchCatalog(String transactionId , String commodityCode , String commodityCodeName){
        FunctionResponse response = functionExecutor.searchCatalog(transactionId , commodityCode , commodityCodeName);
        return  buildAgentResponse(response.getFunctionName(), response.getTemplate(), response.getData() , transactionId);
    }

//    private AgentResponse servicePrReview(String channelId, String title , String commodityCode , String transactionId){
//        NonCatalogReview response = functionExecutor.servicePrReview(channelId , title , commodityCode );
//        return  buildAgentResponse("Service_Pr_Review" , "servicePrReview" , response , transactionId);
//    }

    private AgentResponse handleChatConversation(String transactionId, String channelId, String userQuery) throws Exception {
        chatMessageRepo.save(new ChatMessage(null, transactionId, channelId, "user", userQuery, System.currentTimeMillis()));

        List<ChatMessage> pastMessages = chatMessageRepo.findByTransactionIdOrderByTimestampAsc(transactionId);
        List<Map<String, Object>> messages = buildMessageContent(pastMessages);
        Map<String, Object> openAIResponse = callOpenAI(buildOpenAIRequest(messages));

        if (openAIResponse.containsKey("tool_calls")) {
            return handleToolCalls(openAIResponse, transactionId);
        }

        return new AgentResponse("ASSISTANT", (String) openAIResponse.get("content"), 1.0, null, transactionId);
    }

    private AgentResponse handleToolCalls(Map<String, Object> responseMessage, String transactionId) throws Exception {
        List<Map<String, Object>> toolCalls = (List<Map<String, Object>>) responseMessage.get("tool_calls");
        if (toolCalls.isEmpty()) return new AgentResponse("ASSISTANT", "No tool calls", 1.0, null, transactionId);

        Map<String, Object> toolCall = toolCalls.get(toolCalls.size() - 1);
        Map<String, Object> functionCall = (Map<String, Object>) toolCall.get("function");

        String functionName = (String) functionCall.get("name");
        String rawArgs = (String) functionCall.get("arguments");

        FunctionResponse result = switch (functionName) {
            case "startRequisition" -> functionExecutor.startRequisition(transactionId, functionName, rawArgs);
            default -> new FunctionResponse("Unknown function: " + functionName, rawArgs, 0.0, null);
        };

        return new AgentResponse(result.getFunctionName(), result.getTemplate(), result.getConfidence(), result.getData(), transactionId);
    }

    public AgentResponse buildAgentResponse(String functionName, String cardName, Object data, String transactionId) {
        AdaptiveCardDto dto = functionExecutor.getAdaptiveCard(cardName);
        String cardJson = (dto != null) ? dto.getCardJson() : "{}";
        return new AgentResponse(functionName, cardJson, 1.0, Collections.singletonList(data), transactionId);
    }

    private List<Map<String, Object>> buildMessageContent(List<ChatMessage> pastMessages) {
        List<Map<String, Object>> messages = new ArrayList<>();
        systemPromptRepo.findAll().stream().findFirst().ifPresent(sp ->
                messages.add(Map.of("role", sp.getRole(), "content", sp.getContent()))
        );
        pastMessages.forEach(msg -> messages.add(Map.of("role", msg.getRole(), "content", msg.getContent())));
        return messages;
    }

    private Map<String, Object> buildOpenAIRequest(List<Map<String, Object>> messages) throws Exception {
        AgentConfig config = configService.getOpenAIConfig();

        List<Map<String, Object>> toolDefs = new ArrayList<>();
        for (AiFunction fn : functionRepo.findAll()) {
            toolDefs.add(Map.of(
                    "type", "function",
                    "function", Map.of(
                            "name", fn.getName(),
                            "description", fn.getDescription(),
                            "parameters", objectMapper.readValue(fn.getParameters(), Map.class)
                    )
            ));
        }

        return Map.of(
                "model", config.getModel(),
                "messages", messages,
                "tools", toolDefs,
                "tool_choice", "required"
        );
    }

    private Map<String, Object> callOpenAI(Map<String, Object> request) {
        AgentConfig config = configService.getOpenAIConfig();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(config.getApiKey());

        ResponseEntity<Map> response = restTemplate.exchange(
                "https://api.openai.com/v1/chat/completions",
                HttpMethod.POST,
                new HttpEntity<>(request, headers),
                Map.class
        );

        Map<String, Object> body = response.getBody();
        if (body == null || !body.containsKey("choices")) {
            return Map.of("content", "No response from GPT");
        }

        return (Map<String, Object>) ((List<Map<String, Object>>) body.get("choices")).get(0).get("message");
    }

    public PrData savePrData(PrData prData) {
        int nextNumber = Optional.ofNullable(prDataRepository.findTopByOrderByPrIdDesc())
                .map(last -> Integer.parseInt(last.getPrId().replace("PR", "")) + 1)
                .orElse(1);

        prData.setPrId(String.format("PR%03d", nextNumber));
        return prDataRepository.save(prData);
    }



    private AgentResponse submitPr(String transactionId) {
        ItemSelections itemSelection = itemSelectionsRepository
                .findFirstByTransactionIdOrderByTimestampDesc(transactionId);
        if (itemSelection != null) {
            itemSelection.setIsSync(false);
            itemSelectionsRepository.save(itemSelection);
        }
        String message = "Your PR is submitted and it's in process. We will let you know the PR Number soon.";
        return new AgentResponse("SUBMIT_PR", message, 1.0, null, transactionId);
    }

    public List<ItemSelections> syncItemSelections() {
        List<ItemSelections> itemsToSync = itemSelectionsRepository.findByIsSyncFalse();
        itemsToSync.forEach(item -> item.setIsSync(true));
        itemSelectionsRepository.saveAll(itemsToSync);
        return itemsToSync;
    }
}
