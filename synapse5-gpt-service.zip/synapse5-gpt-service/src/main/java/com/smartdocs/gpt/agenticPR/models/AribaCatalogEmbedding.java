package com.smartdocs.gpt.agenticPR.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.ZonedDateTime;
import java.util.List;

@Document(collection = "newAribaCatalogEmbeddings")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AribaCatalogEmbedding {

    @Id
    private String id;

    private String supplierId;
    private String supplierPartId;
    private String description;
    private String manufacturerName;
    private String unitOfMeasure;
    private String supplierName;
    private String priceCurrencyUniqueName;
    private String shortName;
    private Double priceAmount;
    private String manufacturerPartId;
    private Boolean punchoutEnabled;
    private String image;
    private String url;
    private Integer leadTime;
    private String classificationCode;
    private Integer promotionRank;
    private String expirationDate;
    private Integer minimumQuantity;
    private Boolean isPartial;
    private String catalogName;
    private Boolean green;
    private Boolean isPreferredItem;
    private Integer defaultRelevance;
    private String manufacturerURL;
    private Boolean hazardousMaterials;
    private Double contractPriceAmount;
    private String contractPriceCurrencyUniqueName;
    private Double nonContractPriceAmount;
    private Boolean bestPrice;
    private String language;
    private Boolean isInternalPartId;
    private String effectiveDate;
    private String catalogContentName;
    private String logicalSystem;
    private String lastSyncDate;

    private String clazz;


    private List<Double> embedding;
}