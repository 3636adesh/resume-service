package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.Supplier;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface SupplierRepository extends MongoRepository<Supplier, String> {
    List<Supplier> findBySupplierIdIn(List<Integer> supplierIds);
    List<Supplier> findTop10ByClassificationCode(String classificationCode);
}