package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.ExcelMapping;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ExcelMappingRepository extends MongoRepository<ExcelMapping, String> {
}