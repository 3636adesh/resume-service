package com.smartdocs.gpt.intentRecognition.dto;

import lombok.Data;

@Data
public class Intent {
    private String label;
    private String description;
}
