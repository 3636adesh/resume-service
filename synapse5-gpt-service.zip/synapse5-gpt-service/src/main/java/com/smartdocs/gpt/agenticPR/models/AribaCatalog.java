package com.smartdocs.gpt.agenticPR.models;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Document(collection = "aribaCatalog")
@Data
public class AribaCatalog {

    @Id
    private String id;

    private String supplierId;
    private String supplierPartId;
    private String description;
    private String manufacturerName;
    private String unitOfMeasure;
    private String supplierName;
    private String priceCurrencyUniqueName;
    private String shortName;
    private String url;
    private String classificationCode;
    private Double priceAmount;
    private String manufacturerPartId;
    private String catalogContentName;
    private String logicalSystem;
    private Date lastSyncDate;
    private Boolean isEmbedding;

    private List<Double> embedding;
}