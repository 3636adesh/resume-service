package com.smartdocs.gpt.gemini.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.smartdocs.gpt.config.BasicSecurityConfig;
import com.smartdocs.gpt.document.model.TrainDocumentRequest;
import com.smartdocs.gpt.gemini.service.AltasDocumentGeminiService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import com.smartdocs.gpt.model.GPTChatRequest;
import com.smartdocs.gpt.model.GPTChatResponse;
import com.smartdocs.gpt.openai.model.ChatRequestForSuggestion;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("gemini/atlas-vector")

public class AtlasVectorGeminiController {

    private final AltasDocumentGeminiService altasDocumentGeminiService;

    @PostMapping("/train")
    public boolean trainDocument(HttpServletRequest request, @RequestBody TrainDocumentRequest trainDocumentRequest) {
        String authHeader = request.getHeader("Authorization");
        if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
            return altasDocumentGeminiService.train(trainDocumentRequest);
        } else {
            return false;
        }
    }

    @PostMapping("/train/bot")
    public String trainBot(HttpServletRequest request, @RequestBody TrainDocumentRequest trainDocumentRequest) {
        String authHeader = request.getHeader("Authorization");
        if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
            altasDocumentGeminiService.geminitrainBotDocuments(trainDocumentRequest);
            return "Training started successfully";
        } else {
            return "Unauthorized access";
        }
    }

    @PostMapping("/chat")
    public GPTChatResponse chat(HttpServletRequest request, @RequestBody GPTChatRequest gptChatRequest) throws IOException, InterruptedException {
        String authHeader = request.getHeader("Authorization");
        if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
            return altasDocumentGeminiService.chat(gptChatRequest);
        } else {
            GPTChatResponse response = new GPTChatResponse();
            response.setResponse("Unauthorized access");
            return response;
        }

    }


    @PostMapping("/suggestions")
    public GPTChatResponse getSuggestion(HttpServletRequest request, @RequestBody ChatRequestForSuggestion chatRequestForSuggestion) throws IOException, InterruptedException {
        String authHeader = request.getHeader("Authorization");
        if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
            GPTChatResponse gptChatResponse = new GPTChatResponse();
            String customPrompt = chatRequestForSuggestion.getSuggestedQuestionsPrompt();
            Map<String, Object> result = altasDocumentGeminiService.generateSuggestedQuestions(
                    chatRequestForSuggestion.getText(),
                    chatRequestForSuggestion.getHeaderLine(),
                    4000,
                    0.2,
                    customPrompt,
                    chatRequestForSuggestion.getUserLanguage(),
                    chatRequestForSuggestion.getPreviousMessages(),
                    chatRequestForSuggestion.getSources()
            );

            gptChatResponse.setSuggestedQuestions((List<String>) result.get("response"));
            gptChatResponse.setHeaderLine((String) result.get("translatedHeader"));
            gptChatResponse.setPromptTokens((int) result.get("promptTokens"));
            gptChatResponse.setCompletionTokens((int) result.get("completionTokens"));
            gptChatResponse.setTotalTokens((int) result.get("totalTokens"));
            return gptChatResponse;
        } else {
            GPTChatResponse response = new GPTChatResponse();
            response.setResponse("Unauthorized access");
            return response;
        }
    }

    @DeleteMapping("/deleteDocument")
    public void deleteDocument(HttpServletRequest request , @RequestParam String documentId) {
        String authHeader = request.getHeader("Authorization");
        if(BasicSecurityConfig.validateSynapseBackend(authHeader)) {
            try {
                altasDocumentGeminiService.deleteDocument(documentId);
            } catch (Exception e) {
                e.getMessage();
            }
        }else{
            throw new SecurityException("Unauthorized access");
        }
    }

    @DeleteMapping("/deleteBot/{botId}")
    public void deleteBot(HttpServletRequest request, @PathVariable(value = "botId") String siteId) {
        String authHeader = request.getHeader("Authorization");
        if(BasicSecurityConfig.validateSynapseBackend(authHeader)) {
            altasDocumentGeminiService.deleteBot(siteId);
        }else{
            throw new SecurityException("Unauthorized access");
        }
    }

    @DeleteMapping("/deleteFile")
    public void deleteFile(HttpServletRequest request,
                           @RequestParam(value = "siteId") String siteId,
                           @RequestParam(value = "docId") String docId) {
        String authHeader = request.getHeader("Authorization");
        if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
            altasDocumentGeminiService.deleteFile(siteId, docId);
        } else {
            throw new SecurityException("Unauthorized access");
        }
    }

    @DeleteMapping("/deleteDoc")
    public void deleteDoc(HttpServletRequest request, @RequestParam String docId) {
        String authHeader = request.getHeader("Authorization");
        if (BasicSecurityConfig.validateSynapseBackend(authHeader)) {
            altasDocumentGeminiService.deleteURL(docId);
        } else {
            throw new SecurityException("Unauthorized access");
        }
    }


}

