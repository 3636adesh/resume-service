package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.ItemSelections;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ItemSelectionsRepository extends MongoRepository<ItemSelections, String> {
    ItemSelections findFirstByTransactionIdOrderByTimestampDesc(String transactionId);
    List<ItemSelections> findByIsSyncFalse();
}
