package com.smartdocs.gpt.agenticPR.models;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "newSupplierData")
@Data
public class NewSupplierData {

    @Id
    private String id;

    private String vendorId;
    private String type;
    private String categoryIds;
    private String regionIds;
    private String departmentIds;
    private String status;
    private String erpVendorId;
    private String sourceSystem;
    private String supplierName;
    private String supplierRegion;
    private String businessUnit;
    private String level;
    private Boolean active;
}
