package com.smartdocs.gpt.model;

import java.util.List;

import lombok.Data;

@Data
public class GPTChatResponse {

	
	private String response;
	
	private List<SourceObject> sources;

	private List<String> suggestedQuestions;

	private String headerLine;

	private int promptTokens;

	private int completionTokens;

	private int totalTokens;

	private int embeddingTokens;

	private boolean isAnswered;
}
