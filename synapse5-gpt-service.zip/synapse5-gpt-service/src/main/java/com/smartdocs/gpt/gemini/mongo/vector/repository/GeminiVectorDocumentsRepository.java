package com.smartdocs.gpt.gemini.mongo.vector.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.smartdocs.gpt.gemini.mongo.vector.collection.GeminiVectorDocuments;

public interface GeminiVectorDocumentsRepository extends MongoRepository<GeminiVectorDocuments, String> {

    void deleteByDocumentId(String documentId);

    void deleteBySiteId(String siteId);

    void deleteBySiteIdAndSourceType(String siteId, String sourceType);

    void deleteBySiteIdAndDocumentId(String siteId, String documentId);

}
