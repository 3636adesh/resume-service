package com.smartdocs.gpt.intentRecognition.Repository;

import com.smartdocs.gpt.intentRecognition.dto.UtteranceEmbeddingDocuments;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface UtteranceEmbeddingRepository extends MongoRepository<UtteranceEmbeddingDocuments, String> {
    List<UtteranceEmbeddingDocuments> findByLabel(String label);
    List<UtteranceEmbeddingDocuments> findByBotId(String botId);
}
