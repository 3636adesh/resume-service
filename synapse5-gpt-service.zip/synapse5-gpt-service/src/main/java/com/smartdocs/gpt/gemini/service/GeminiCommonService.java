package com.smartdocs.gpt.gemini.service;

import com.smartdocs.gpt.gemini.mongo.vector.collection.GeminiVectorDocuments;
import com.smartdocs.gpt.model.SourceObject;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GeminiCommonService {

    public List<SourceObject> getSourceListFromDocument(List<GeminiVectorDocuments> documents) {
        List<SourceObject> sourceObjectList = new ArrayList<>();
        for (GeminiVectorDocuments vectorEntity : documents) {

            SourceObject sourceObject = new SourceObject();
            sourceObject.setDocumentId(vectorEntity.getDocumentId());
            sourceObject.setDocumentType("");
            sourceObject.setSource(vectorEntity.getDocumentContent());
            sourceObject.setPage_no("" + vectorEntity.getPage());
            sourceObject.setDocumentName(vectorEntity.getDocumentName());
            sourceObjectList.add(sourceObject);
        }
        return sourceObjectList;
    }
}
