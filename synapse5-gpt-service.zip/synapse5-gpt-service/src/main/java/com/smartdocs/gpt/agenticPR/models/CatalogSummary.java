package com.smartdocs.gpt.agenticPR.models;

import com.smartdocs.gpt.agenticPR.DTO.LineItemsSummaryDTO;
import lombok.Data;

import java.util.List;

@Data
public class CatalogSummary {
//    private String title;
//    private String companyCode;
//    private String purchasingUnit;
//    private String needByDate;
//    private String startDate;
//    private String endDate;
//    private String deliverTo;
//    private String comments;
//
//
//    List<LineItemsSummaryDTO> lineItemsSummaryList;

    private String costCenter;
    private String glAccount;
    private String companyCode;
    private String plant;
    private String deliverTo;
    private String purchasingGroup;
    private String purchasingOrganization;

}
