package com.smartdocs.gpt.gemini.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EmbeddingConfig {
    @JsonProperty("output_dimensionality")
    private Integer outputDimensionality;

    public Integer getOutputDimensionality() {
        return outputDimensionality;
    }

    public void setOutputDimensionality(Integer outputDimensionality) {
        this.outputDimensionality = outputDimensionality;
    }
}
