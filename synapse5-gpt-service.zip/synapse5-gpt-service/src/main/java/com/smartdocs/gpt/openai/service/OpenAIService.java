package com.smartdocs.gpt.openai.service;

import java.util.ArrayList;
import java.util.List;

import com.smartdocs.gpt.openai.model.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.smartdocs.gpt.model.ResponseFormat;
import com.smartdocs.gpt.service.OpenAIConfigProperties;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service("openAIService")
@Slf4j
public class OpenAIService {

	private final RestTemplate restTemplate;

	private final OpenAIConfigProperties openAiConfigProperties;

	public OpenAIService(
			@Qualifier("openaiRestTemplate") RestTemplate restTemplate,
			OpenAIConfigProperties openAiConfigProperties
	) {
		this.restTemplate = restTemplate;
		this.openAiConfigProperties = openAiConfigProperties;
	}

	public ChatResponse createChatCompletion(String prompt) {
		ChatRequest request = new ChatRequest(openAiConfigProperties.getModelName(), prompt);
		// Azure URL includes deployment name and api-version
		String url = openAiConfigProperties.getApiUrl()
				+ "/openai/deployments/" + openAiConfigProperties.getModelName()
				+ "/chat/completions?api-version=" + openAiConfigProperties.getChatApiVersion();
		return restTemplate.postForObject(url, request, ChatResponse.class);
	}

	public ChatResponse createChatCompletion(List<Message> messages, int maxTokens, double temperature) {
		ChatRequest request = new ChatRequest(openAiConfigProperties.getModelName(), messages, temperature);
		log.info(request.toString());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<ChatRequest> requestEntity = new HttpEntity<>(request, headers);
		String url = openAiConfigProperties.getApiUrl()
				+ "/openai/deployments/" + openAiConfigProperties.getModelName()
				+ "/chat/completions?api-version=" + openAiConfigProperties.getChatApiVersion();
		ResponseEntity<ChatResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, ChatResponse.class);
		return response.getBody();
	}

	public EmbedingsResponse createEmbeddings(String text) {
		String embedingsModel = openAiConfigProperties.getEmbeddingModel();
		EmbedingsRequest request = new EmbedingsRequest(embedingsModel, text);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<EmbedingsRequest> requestEntity = new HttpEntity<>(request, headers);
		String url = openAiConfigProperties.getApiUrl()
				+ "/openai/deployments/" + embedingsModel
				+ "/embeddings?api-version=" + openAiConfigProperties.getEmbeddingApiVersion();
		ResponseEntity<EmbedingsResponse> embeddingsResponse =
				restTemplate.exchange(url, HttpMethod.POST, requestEntity, EmbedingsResponse.class);
		return embeddingsResponse.getBody();
	}

	public EmbeddingData createEmbeddingInDouble(String text) {
		EmbedingsResponse response = createEmbeddings(text);
		List<Float> queryEmbeddings = response.getData().get(0).getEmbedding();
		int embeddingTokens = response.getUsage().total_tokens;
		List<Double> queryEmbeddingsDouble = new ArrayList<>();
		for (Float f : queryEmbeddings) {
			queryEmbeddingsDouble.add(f.doubleValue());
		}
		return new EmbeddingData(queryEmbeddingsDouble, embeddingTokens);
	}

	public ChatResponse createChatCompletionJson(List<Message> messages, int maxTokens, double temperature) {
		ResponseFormat responseformat = new ResponseFormat();
		responseformat.setType("json_object");
		ChatRequestJson request = new ChatRequestJson(openAiConfigProperties.getModelName(), messages, maxTokens, temperature, responseformat);
		log.info(request.toString());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<ChatRequestJson> requestEntity = new HttpEntity<>(request, headers);
		String url = openAiConfigProperties.getApiUrl()
				+ "/openai/deployments/" + openAiConfigProperties.getModelName()
				+ "/chat/completions?api-version=" + openAiConfigProperties.getChatApiVersion();
		ResponseEntity<ChatResponse> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, ChatResponse.class);
		return response.getBody();
	}

}
