package com.smartdocs.gpt.openai.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "app_config")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AgentConfig {

    @Id
    private String id;  // e.g., "openai.config"

    private String apiKey;
    private String model;
}

