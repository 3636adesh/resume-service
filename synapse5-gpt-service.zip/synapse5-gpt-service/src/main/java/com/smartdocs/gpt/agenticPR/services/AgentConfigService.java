package com.smartdocs.gpt.agenticPR.services;

import com.smartdocs.gpt.agenticPR.repositories.AgentConfigRepository;
import com.smartdocs.gpt.openai.config.AgentConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AgentConfigService {

    private final AgentConfigRepository configRepo;

    public AgentConfig getOpenAIConfig() {
        return configRepo.findById("openai.config")
                .orElseThrow(() -> new RuntimeException("Missing OpenAI config"));
    }
}
