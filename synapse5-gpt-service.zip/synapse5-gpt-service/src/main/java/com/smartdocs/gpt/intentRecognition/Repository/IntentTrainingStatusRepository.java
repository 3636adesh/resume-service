package com.smartdocs.gpt.intentRecognition.Repository;

import com.smartdocs.gpt.intentRecognition.models.IntentTrainingStatus;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface IntentTrainingStatusRepository extends MongoRepository<IntentTrainingStatus, String> {
    Optional<IntentTrainingStatus> findByIntentAndBotId(String intent, String botId);
}
