package com.smartdocs.gpt.agenticPR.services;

import com.smartdocs.gpt.agenticPR.models.ExcelMapping;
import com.smartdocs.gpt.agenticPR.repositories.ExcelMappingRepository;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class ExcelImportService {

    private final ExcelMappingRepository excelMappingRepository;

    // Regex to extract pattern like 0000240975_RO_920602
    private static final Pattern PATTERN = Pattern.compile("^(\\d{10})_([A-Z]{2})_(\\d{6})$");

    public String importExcel(MultipartFile file) {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {

            String line;
            boolean headerSkipped = false;

            while ((line = reader.readLine()) != null) {
                if (!headerSkipped) {
                    headerSkipped = true; // skip header line
                    continue;
                }

                // Split CSV line by comma or tab — your sample looks tab-separated
                String[] columns = line.split("[,\t]");

                if (columns.length == 0) continue;
                String uniqueName = columns[0].trim();
                if (uniqueName.isEmpty()) continue;

                Matcher matcher = PATTERN.matcher(uniqueName);
                if (matcher.matches()) {
                    String transactionId = matcher.group(1);
                    String countryCode = matcher.group(2);
                    String commodityCode = matcher.group(3);

                    ExcelMapping mapping = new ExcelMapping();
                    mapping.setTransactionId(transactionId);
                    mapping.setCountryCode(countryCode);
                    mapping.setCommodityCode(commodityCode);

                    excelMappingRepository.save(mapping);
                }
            }

            return "CSV data imported successfully";

        } catch (Exception e) {
            e.printStackTrace();
            return "Error importing CSV: " + e.getMessage();
        }
    }
}