package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.NewSupplierData;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface NewSupplierDataRepository extends MongoRepository<NewSupplierData, String> {

    List<NewSupplierData> findByCategoryIdsAndLevelIn(String categoryIds, List<String> levels);

    List<NewSupplierData> findByCategoryIdsAndLevel(String categoryIds, String level);

    List<NewSupplierData> findByCategoryIds(String categoryIds);
}

