package com.smartdocs.gpt.intentRecognition.dto;

import lombok.Data;

import java.util.ArrayList;

@Data
public class IntentDetectionResponse {
    private String response;
    private String intent;
    private float confidence;
    private ArrayList<String> entities;
    private String reason;
}
