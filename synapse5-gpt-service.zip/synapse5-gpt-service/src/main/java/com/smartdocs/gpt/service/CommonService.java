package com.smartdocs.gpt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.smartdocs.gpt.model.SourceObject;
import com.smartdocs.gpt.mongo.repository.AiEngineFileDetailsRepository;
import com.smartdocs.gpt.mongo.vector.collection.VectorDocuments;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CommonService {
	
	private final AiEngineFileDetailsRepository aiEngineFileDetailsRepository;
	
	public List<SourceObject> getSourceListFromDocument(List<VectorDocuments> documents) {
		List<SourceObject> sourceObjectList = new ArrayList<>();
		for (VectorDocuments vectorEntity : documents) {
			
				SourceObject sourceObject = new SourceObject();
				sourceObject.setDocumentId(vectorEntity.getDocumentId());
				sourceObject.setDocumentType("");
				sourceObject.setSource(vectorEntity.getDocumentContent());
				sourceObject.setPage_no("" + vectorEntity.getPage());
				sourceObject.setDocumentName(vectorEntity.getDocumentName());
				sourceObjectList.add(sourceObject);
				

			

		}

		return sourceObjectList;
	}

}
