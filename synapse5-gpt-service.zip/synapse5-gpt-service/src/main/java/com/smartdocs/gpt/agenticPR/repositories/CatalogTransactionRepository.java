package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.CatalogTransaction;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CatalogTransactionRepository extends MongoRepository<CatalogTransaction , String> {
    CatalogTransaction findTopByTransactionIdOrderByTimestampDesc(String transactionId);
}
