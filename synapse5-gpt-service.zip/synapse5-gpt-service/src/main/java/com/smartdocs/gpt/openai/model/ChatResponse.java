package com.smartdocs.gpt.openai.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChatResponse {

	private List<Choice> choices;

	private Usage usage;

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Choice {
		private int index;
		private Message message;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Usage {

		@JsonProperty("prompt_tokens")
		private Integer promptTokens;

		@JsonProperty("completion_tokens")
		private Integer completionTokens;

		@JsonProperty("total_tokens")
		private Integer totalTokens;
	}
}
