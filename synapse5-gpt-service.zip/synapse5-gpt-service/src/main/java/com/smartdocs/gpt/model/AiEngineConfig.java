package com.smartdocs.gpt.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Document
public class AiEngineConfig {

//	public static final String ID = "1000";

	public  static final String KEY_DEFAULT = "Default";
	public  static final String KEY_CUSTOM = "Custom";

	public static final String ENGINE_TYPE_AZURE = "AzureOpenAI";
	public static final String ENGINE_TYPE_GEMINI = "GeminiAI";




	@Id
	@JsonIgnore
	private String id;
	private String apiKey;
	private String engineType;
	private String modelName;
	private String engineName;
	private String endPointUrl;
	private String embeddingModel;
	private String keyType;
	private boolean enable;
	private String embeddingApiVersion;
	private String chatApiVersion;

}

