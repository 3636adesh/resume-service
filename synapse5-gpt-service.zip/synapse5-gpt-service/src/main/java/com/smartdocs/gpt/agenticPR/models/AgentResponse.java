package com.smartdocs.gpt.agenticPR.models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AgentResponse {
    private String functionName;
    private String template;
    private double confidence;
    private List<?> data;
    private String transactionId;
}
