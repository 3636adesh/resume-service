// com.smartdocs.gpt.gemini.model.GenerateContentResponse.java
package com.smartdocs.gpt.gemini.model;

import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class GenerateContentResponse {
    private List<Candidate> candidates;

    private UsageMetadata usageMetadata;

    @Data
    @NoArgsConstructor
    public static class Candidate {
        private Content content;
    }

    @Data
    public static class UsageMetadata {
        private int promptTokenCount;
        private int candidatesTokenCount;
        private int totalTokenCount;
    }
}
