package com.smartdocs.gpt.mongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document(collection = "GPT_TaxanomyDetails")
@Data
public class TaxanomyDetails {

	@Id
	private String id;
	private String portfolio;
	private String commodity;
	private String subCommodity;
	private String detailedDescription;
	private String segmentCode;
	private String segmentName;
	private String action;
	private String segmentNewName;
//	    private String codeNameLength;
	private String shortDescription;
//	    private String shortNameLength;
	private String valuationClass;
	private String glAccount;
	private String glAccountName;
	private String capexAuthorized;
	private String ifrs16;
	private String zfcbAuthorized;
	private String limitOrderAuthorized;
	private String defaultPOType;
	private String otvAuthorized;
	private String managementLevel2;
	private String managementLevel;
	private String unspscsMappedToSegment;
	@Override
	public String toString() {
		return "TaxanomyDetails [portfolio=" + portfolio + ", commodity=" + commodity + ", subCommodity=" + subCommodity
				+ ", detailedDescription=" + detailedDescription + ", segmentCode=" + segmentCode + ", segmentName="
				+ segmentName + ", action=" + action + ", segmentNewName=" + segmentNewName + ", shortDescription="
				+ shortDescription + ", valuationClass=" + valuationClass + ", glAccount=" + glAccount
				+ ", glAccountName=" + glAccountName + ", capexAuthorized=" + capexAuthorized + ", ifrs16=" + ifrs16
				+ ", zfcbAuthorized=" + zfcbAuthorized + ", limitOrderAuthorized=" + limitOrderAuthorized
				+ ", defaultPOType=" + defaultPOType + ", otvAuthorized=" + otvAuthorized + ", managementLevel2="
				+ managementLevel2 + ", managementLevel=" + managementLevel + ", unspscsMappedToSegment="
				+ unspscsMappedToSegment + "]";
	}
	
	

}
