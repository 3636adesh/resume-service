package com.smartdocs.gpt.BGME3.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartdocs.gpt.BGME3.model.BGEEmbeddingData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class BGEM3EmbeddingService {

    private static final Logger logger = LoggerFactory.getLogger(BGEM3EmbeddingService.class);

    @Value("${bge.api.url}")
    private String bgeApiUrl;

    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;

    public BGEM3EmbeddingService() {
        this.httpClient = HttpClient.newHttpClient();
        this.objectMapper = new ObjectMapper();
    }

    /**
     * Create embedding for a single text using BGE-M3
     *
     * @param text Input text to embed
     * @return BGEEmbeddingData containing the embedding and metadata
     * @throws IOException if API call fails
     * @throws InterruptedException if request is interrupted
     */
    public BGEEmbeddingData createEmbedding(String text) throws IOException, InterruptedException {
        logger.debug("Creating BGE-M3 embedding for text of length: {}", text.length());

        // Prepare request body
        Map<String, String> requestBody = Map.of("text", text);
        String requestJson = objectMapper.writeValueAsString(requestBody);

        // Build HTTP request
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(bgeApiUrl + "/embed/single"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestJson))
                .build();

        try {
            // Send request
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                String errorMsg = String.format("BGE-M3 API returned status %d: %s",
                        response.statusCode(), response.body());
                logger.error(errorMsg);
                throw new IOException(errorMsg);
            }

            // Parse response
            Map<String, Object> responseData = objectMapper.readValue(response.body(), Map.class);

            @SuppressWarnings("unchecked")
            List<Double> embedding = (List<Double>) responseData.get("embedding");
            Integer tokens = (Integer) responseData.get("tokens");
            String model = (String) responseData.get("model");
            Integer dimensions = (Integer) responseData.get("dimensions");

            logger.debug("BGE-M3 embedding created successfully. Dimensions: {}, Tokens: {}", dimensions, tokens);

            return new BGEEmbeddingData(embedding, tokens, model, dimensions);

        } catch (Exception e) {
            logger.error("Error calling BGE-M3 API", e);
            throw e;
        }
    }

    /**
     * Create embeddings for multiple texts using BGE-M3
     *
     * @param texts List of input texts to embed
     * @return List of BGEEmbeddingData
     * @throws IOException if API call fails
     * @throws InterruptedException if request is interrupted
     */

    public List<BGEEmbeddingData> createEmbeddings(List<String> texts) throws IOException, InterruptedException {
        logger.debug("Creating BGE-M3 embeddings for {} texts", texts.size());

        // Prepare request body
        Map<String, Object> requestBody = Map.of("texts", texts);
        String requestJson = objectMapper.writeValueAsString(requestBody);

        // Build HTTP request
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(bgeApiUrl + "/embeddings"))  // Fixed endpoint name
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestJson))
                .build();

        try {
            // Send request
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                String errorMsg = String.format("BGE-M3 API returned status %d: %s",
                        response.statusCode(), response.body());
                logger.error(errorMsg);
                throw new IOException(errorMsg);
            }

            // Parse response
            Map<String, Object> responseData = objectMapper.readValue(response.body(), Map.class);

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> embeddingsList = (List<Map<String, Object>>) responseData.get("embeddings");

            List<BGEEmbeddingData> results = new ArrayList<>();

            for (Map<String, Object> embeddingData : embeddingsList) {
                @SuppressWarnings("unchecked")
                List<Double> embedding = (List<Double>) embeddingData.get("embedding");
                Integer tokens = (Integer) embeddingData.get("tokens");
                String model = (String) embeddingData.get("model");
                Integer dimensions = (Integer) embeddingData.get("dimensions");

                results.add(new BGEEmbeddingData(embedding, tokens, model, dimensions));
            }

            logger.debug("BGE-M3 embeddings created successfully for {} texts", texts.size());
            return results;

        } catch (Exception e) {
            logger.error("Error calling BGE-M3 API for multiple texts", e);
            throw e;
        }
    }


    /**
     * Check if BGE-M3 API is healthy
     *
     * @return true if API is healthy, false otherwise
     */
    public boolean isHealthy() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(bgeApiUrl + "/health"))
                    .GET()
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            boolean isHealthy = response.statusCode() == 200;
            logger.debug("BGE-M3 API health check: {}", isHealthy ? "HEALTHY" : "UNHEALTHY");

            return isHealthy;

        } catch (Exception e) {
            logger.warn("BGE-M3 API health check failed", e);
            return false;
        }
    }

    /**
     * Get BGE-M3 model information
     *
     * @return Map containing model information
     * @throws IOException if API call fails
     * @throws InterruptedException if request is interrupted
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> getModelInfo() throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(bgeApiUrl + "/model/info"))
                .GET()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new IOException("Failed to get model info: " + response.body());
        }

        return objectMapper.readValue(response.body(), Map.class);
    }
}
