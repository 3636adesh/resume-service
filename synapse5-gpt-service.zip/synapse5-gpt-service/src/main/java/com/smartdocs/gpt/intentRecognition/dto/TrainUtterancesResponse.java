package com.smartdocs.gpt.intentRecognition.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Response DTO for training utterances
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainUtterancesResponse {

    private String label;

    private Integer totalUtterances;

    private Integer successCount;

    private Integer failureCount;

    private Integer savedCount;

    private String status;

    private String errorMessage;

    private String embeddingModel;

    private Integer embeddingDimensions;

    private Long totalTokens;
}
