package com.smartdocs.gpt.intentRecognition.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainUtterancesRequest {
    private List<String> utterances;
    private String label;
    private String siteId;
    private String description;
    private Integer batchSize;
    private String botId;
    private String embeddingModel;
}
