package com.smartdocs.gpt.mongo.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.gpt.mongo.model.TaxanomyDetails;

@Repository
public interface TaxanomyDetailsRepository extends MongoRepository<TaxanomyDetails, String>{
	
	Optional<TaxanomyDetails> findBySegmentCode(String segmentCode);

}
