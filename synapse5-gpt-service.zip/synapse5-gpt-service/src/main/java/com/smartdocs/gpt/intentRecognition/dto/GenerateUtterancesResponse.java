package com.smartdocs.gpt.intentRecognition.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GenerateUtterancesResponse {

    private List<String> generatedUtterances;

    private String label;

    private Integer requestedCount;

    private Integer actualCount;

    private String status;

    private String errorMessage;
}
