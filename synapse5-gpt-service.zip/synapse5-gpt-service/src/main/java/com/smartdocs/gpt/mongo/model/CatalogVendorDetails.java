package com.smartdocs.gpt.mongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document(collection = "GPT_CatalogDetails")
@Data
public class CatalogVendorDetails {
	
	@Id
	private String id;
	
	private String supplierName;
    private String parentSupplier;
    private String country;
    private String region;
    private String buyerInCharge;
    private String supplierEnablementMember;
    private String vendorID;
    private String catalogSubscriptionName;
    private String cmdt2_1; 
    private String mergeMappingNewSegment; 
    private String taxoNameSegmentNameCurrentVersion; 
    private String commercialExpirationDate;
    private String catalogExpirationDate;
    private String reminderStatus;
    private String status;
    private String anid;  
    private String type;
    private String lastStatusUpdate;
    private String images;
    private String keywords;
    private String bim;

}
