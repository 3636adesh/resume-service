package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.AiFunction;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface AiFunctionRepository extends MongoRepository<AiFunction, String> {
    AiFunction findByName(String name);
}
