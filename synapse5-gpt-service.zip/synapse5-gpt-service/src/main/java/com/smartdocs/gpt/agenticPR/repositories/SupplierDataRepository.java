package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.SupplierData;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface SupplierDataRepository extends MongoRepository<SupplierData, String> {
    List<SupplierData> findByCommodityCode(String commodityCode);
}
