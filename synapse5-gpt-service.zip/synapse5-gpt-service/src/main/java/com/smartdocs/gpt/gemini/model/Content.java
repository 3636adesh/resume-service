package com.smartdocs.gpt.gemini.model;

import com.smartdocs.gpt.gemini.model.ContentPart;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class Content {
    private String role;
    private List<ContentPart> parts;
}
