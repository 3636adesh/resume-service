package com.smartdocs.gpt.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.gpt.mongo.model.AiEngineFileDetails;



@Repository
public interface AiEngineFileDetailsRepository extends MongoRepository<AiEngineFileDetails, String>{

	void deleteByDocumentId(String documentId);

	void deleteByDocumentIdAndEngineType(String documentId , String engineType);

}
