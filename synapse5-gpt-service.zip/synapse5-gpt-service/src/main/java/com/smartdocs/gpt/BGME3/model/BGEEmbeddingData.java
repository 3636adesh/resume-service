package com.smartdocs.gpt.BGME3.model;

import java.util.List;

public class BGEEmbeddingData {
    private List<Double> embedding;
    private Integer tokens;
    private String model;
    private Integer dimensions;

    public BGEEmbeddingData() {}

    public BGEEmbeddingData(List<Double> embedding, Integer tokens, String model, Integer dimensions) {
        this.embedding = embedding;
        this.tokens = tokens;
        this.model = model;
        this.dimensions = dimensions;
    }

    // Getters and setters
    public List<Double> getEmbedding() {
        return embedding;
    }

    public void setEmbedding(List<Double> embedding) {
        this.embedding = embedding;
    }

    public Integer getTokens() {
        return tokens;
    }

    public void setTokens(Integer tokens) {
        this.tokens = tokens;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getDimensions() {
        return dimensions;
    }

    public void setDimensions(Integer dimensions) {
        this.dimensions = dimensions;
    }

    @Override
    public String toString() {
        return "BGEEmbeddingData{" +
                "embedding size=" + (embedding != null ? embedding.size() : 0) +
                ", tokens=" + tokens +
                ", model='" + model + '\'' +
                ", dimensions=" + dimensions +
                '}';
    }
}
