package com.smartdocs.gpt.agenticPR.models;


import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document(collection = "catalogTransactions")
public class CatalogTransaction {

    @Id
    private String id;

    private String transactionId;
    private Instant timestamp;
    private String combinedNames;

    public CatalogTransaction(String transactionId, String combinedNames) {
        this.transactionId = transactionId;
        this.combinedNames = combinedNames;
        this.timestamp = Instant.now();
    }
}