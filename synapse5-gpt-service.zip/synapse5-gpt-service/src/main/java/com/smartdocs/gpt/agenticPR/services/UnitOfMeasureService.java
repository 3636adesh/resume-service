package com.smartdocs.gpt.agenticPR.services;

import com.smartdocs.gpt.agenticPR.models.AribaUnitOfMeasure;
import com.smartdocs.gpt.agenticPR.repositories.AribaUnitOfMeasureRepository;
import com.smartdocs.gpt.agenticPR.services.AgentConfigService;
import com.smartdocs.gpt.openai.config.AgentConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UnitOfMeasureService {

    private final AribaUnitOfMeasureRepository uomRepository;
    private final AgentConfigService configService;
    private final RestTemplate restTemplate;

    private static final int TOP_COUNT = 4;

    public List<String> suggestTopUOMs(String catalogItemName) {
        try {
            AgentConfig config = configService.getOpenAIConfig();
            if (config == null || config.getApiKey() == null) {
                throw new IllegalStateException("OpenAI configuration not found in database");
            }

            String apiKey = config.getApiKey();
            String model = config.getModel() != null ? config.getModel() : "gpt-4o-mini";

            List<AribaUnitOfMeasure> allUoms = uomRepository.findAll();
            if (allUoms.isEmpty()) {
                log.warn("No UOM data found in Mongo");
                return Collections.emptyList();
            }

            StringBuilder prompt = new StringBuilder();
            prompt.append("Given the catalog item: '").append(catalogItemName).append("', ")
                    .append("suggest the top ").append(TOP_COUNT)
                    .append(" most appropriate unit of measure codes from this list:\n");

            for (AribaUnitOfMeasure uom : allUoms) {
                prompt.append("- ")
                        .append(uom.getName())
                        .append(" (").append(uom.getUniqueName()).append(")\n");
            }

            prompt.append("\nReturn only the top 4 uniqueName values, comma-separated, no explanations.");

            JSONObject request = new JSONObject();
            request.put("model", model);
            request.put("messages", new JSONArray()
                    .put(new JSONObject()
                            .put("role", "system")
                            .put("content", "You are a procurement assistant that suggests relevant units of measure."))
                    .put(new JSONObject()
                            .put("role", "user")
                            .put("content", prompt.toString()))
            );


            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(apiKey);

            HttpEntity<String> entity = new HttpEntity<>(request.toString(), headers);
            ResponseEntity<Map> response = restTemplate.exchange(
                    "https://api.openai.com/v1/chat/completions",
                    HttpMethod.POST,
                    entity,
                    Map.class
            );

            Map<String, Object> body = response.getBody();
            if (body == null || !body.containsKey("choices")) {
                log.error("Invalid response from OpenAI: {}", body);
                return Collections.emptyList();
            }

            List<Map<String, Object>> choices = (List<Map<String, Object>>) body.get("choices");
            Map<String, Object> message = (Map<String, Object>) choices.get(0).get("message");
            String llmText = String.valueOf(message.get("content")).trim();

            log.info("LLM raw response: {}", llmText);

            List<String> topUomCodes = Arrays.stream(llmText.split(","))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .limit(TOP_COUNT)
                    .collect(Collectors.toList());

//            List<AribaUnitOfMeasure> matchedUoms = allUoms.stream()
//                    .filter(u -> topUomCodes.contains(u.getUniqueName()))
//                    .sorted(Comparator.comparingInt(u -> topUomCodes.indexOf(u.getUniqueName())))
//                    .collect(Collectors.toList());

            log.info("Top {} UOMs for '{}': {}", TOP_COUNT, catalogItemName, topUomCodes);
            return topUomCodes;

        } catch (Exception e) {
            log.error("Error suggesting UOMs for '{}': {}", catalogItemName, e.getMessage(), e);
            return Collections.emptyList();
        }
    }
}
