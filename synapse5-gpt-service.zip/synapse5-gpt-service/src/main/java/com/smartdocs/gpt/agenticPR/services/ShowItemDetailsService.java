package com.smartdocs.gpt.agenticPR.services;

import com.smartdocs.gpt.agenticPR.DTO.AccountingDTO;
import com.smartdocs.gpt.agenticPR.DTO.ShippingDTO;
import com.smartdocs.gpt.agenticPR.models.AribaUser;
import com.smartdocs.gpt.agenticPR.models.CatalogItem;
import com.smartdocs.gpt.agenticPR.models.ShowUserDefaults;
import com.smartdocs.gpt.agenticPR.models.User;
import com.smartdocs.gpt.agenticPR.repositories.AribaUserRepository;
import com.smartdocs.gpt.agenticPR.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


@Service
@RequiredArgsConstructor
public class ShowItemDetailsService {

    private final UserRepository userRepository;
    private final AribaUserRepository aribaUserRepository;

    public ShowUserDefaults getItemDetails( String channelId , String commodityCode , String commodityCodeName) {

        User user = userRepository.findByChannelValueAndChannelType(channelId, "MSTeams")
                .orElseThrow(() -> new RuntimeException("User not found for channelId: " + channelId));

        String aribaUserId = user.getAribaUserId();

        AribaUser aribaUser = aribaUserRepository.findByUniqueName(aribaUserId)
                .orElseThrow(() -> new RuntimeException("AribaUser not found for id: " + aribaUserId));

        ShowUserDefaults details = new ShowUserDefaults();

//        String title = lineItems.stream()
//                .map(CatalogItem::getProductName)
//                .filter(Objects::nonNull)
//                .collect(Collectors.joining(", "));
//        details.setTitle(title);

        details.setCompanyCodes(aribaUser.getCompanyCodes());
        details.setPurchasingOrganization(aribaUser.getPurchasingOrganization());
        details.setDeliverTo(aribaUser.getDeliverTo());

            AccountingDTO accounting = new AccountingDTO(
                    aribaUser.getGeneralLedgerAccount(),
                    aribaUser.getCostCenter()
            );
            details.setAccounting(accounting);

            ShippingDTO shipping = new ShippingDTO(
                    aribaUser.getPlant(),
                    aribaUser.getPurchasingGroup()
            );
            details.setShipping(shipping);
            details.setCommodityCode(commodityCode);
            details.setCommodityCodeName(commodityCodeName);


//        item.setAccounting(accounting);
//        item.setShipping(shipping);
//        details.setLineItems(lineItems);
        return details;
    }

}
