package com.smartdocs.gpt.agenticPR.services;

import com.smartdocs.gpt.agenticPR.repositories.AribaCatalogEmbeddingRepository;
import com.smartdocs.gpt.agenticPR.repositories.ItemSelectionsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SelectedItemsService {

    private final ItemSelectionsRepository itemSelectionsRepository;
    private final AribaCatalogEmbeddingRepository catalogRepository;

//    public SelectedItemResponse processSelectedItems(String transactionId, List<SelectedItemRequest> requests) {
//
//        if (transactionId == null || transactionId.isEmpty()) {
//            throw new IllegalArgumentException("TransactionId is required");
//        }
//        if (requests == null || requests.isEmpty()) {
//            throw new IllegalArgumentException("At least one SelectedItemRequest is required");
//        }
//
//        ItemSelections items = itemSelectionsRepository.findFirstByTransactionIdOrderByTimestampDesc(transactionId);
//        List<String> itemIds = items.getItemIds();
//        List<AribaCatalogEmbedding> catalogItems = catalogRepository.findAllById(itemIds);
//
//        String combinedShortName = catalogItems.stream()
//                .map(AribaCatalogEmbedding::getShortName)
//                .collect(Collectors.joining(" and "));
//
//        String targetCurrency = requests.get(0).getCurrency();
//
//        double totalPrice = catalogItems.stream()
//                .map(item -> convertCurrency(
//                        BigDecimal.valueOf(item.getPriceAmount()),
//                        "USD",
//                        targetCurrency)
//                        .multiply(BigDecimal.valueOf(requests.get(0).getQuantity()))  // multiply by quantity
//                )
//                .reduce(BigDecimal.ZERO, BigDecimal::add)
//                .doubleValue();
//
//        SelectedItemRequest firstReq = requests.get(0);
//
//        return new SelectedItemResponse(
//                catalogItems.get(0).getId(),
//                catalogItems.get(0).getSupplierName(),
//                combinedShortName,
//                totalPrice,
//                firstReq.getQuantity(),
//                targetCurrency,
//                firstReq.getNeedByDate(),
//                firstReq.getCommodityCode(),
//                "IT-EU-CC-0042",
//                "SmartDocs HQ, 4th Floor, Tower B, Hyderabad, IN 500081"
//        );
//    }
//
//    private BigDecimal convertCurrency(BigDecimal amount, String fromCurrency, String toCurrency) {
//        if (fromCurrency.equalsIgnoreCase(toCurrency)) {
//            return amount;
//        }
//        switch (toCurrency.toUpperCase()) {
//            case "EUR": return amount.multiply(BigDecimal.valueOf(0.9));
//            case "INR": return amount.multiply(BigDecimal.valueOf(83));
//            case "USD": return amount;
//            default: return amount;
//        }
//    }
}
