package com.smartdocs.gpt.intentRecognition.dto;

import lombok.Data;

import java.util.List;

@Data
public class IntentDetectionRequest {
    private String userQuery;
    private String siteId;
    private double temperature=0.2;
    private String userLanguage;
    private List<Intent> intents;
    private int outputLength;
}
