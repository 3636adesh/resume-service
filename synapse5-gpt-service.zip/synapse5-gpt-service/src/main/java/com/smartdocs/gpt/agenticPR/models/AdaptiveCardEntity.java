package com.smartdocs.gpt.agenticPR.models;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "adaptive_cards")
public class AdaptiveCardEntity {

    @Id
    private String id;
    private String name;
    private String cardJson;
}
