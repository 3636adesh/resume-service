package com.smartdocs.gpt.gemini.model;

import lombok.Data;

import java.util.List;

@Data
public class CountTokensRequest {
    private List<Content> contents;
}
