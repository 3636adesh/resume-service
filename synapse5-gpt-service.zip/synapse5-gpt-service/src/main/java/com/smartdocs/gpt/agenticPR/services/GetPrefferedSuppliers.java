package com.smartdocs.gpt.agenticPR.services;

import com.smartdocs.gpt.agenticPR.models.NewSupplierData;
import com.smartdocs.gpt.agenticPR.repositories.NewSupplierDataRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class GetPrefferedSuppliers {

    private final NewSupplierDataRepository repo;

    public List<NewSupplierData> getTop5Suppliers(String categoryId) {

        List<String> priorityLevels = Arrays.asList("1", "2", "3", "4", "5");
        List<NewSupplierData> topCandidates =
                repo.findByCategoryIdsAndLevelIn(categoryId, priorityLevels);

        List<NewSupplierData> sorted = topCandidates.stream()
                .sorted(Comparator.comparingInt(s ->
                        priorityLevels.indexOf(s.getLevel())))
                .collect(Collectors.toList());

        List<NewSupplierData> result = sorted.stream()
                .limit(5)
                .collect(Collectors.toList());
        if (result.size() == 5) return result;
        if (result.size() < 5) {
            List<NewSupplierData> zeroLevel =
                    repo.findByCategoryIdsAndLevel(categoryId, "0");

            zeroLevel.stream()
                    .limit(5 - result.size())
                    .forEach(result::add);
        }

        if (result.size() < 5) {
            List<NewSupplierData> all =
                    repo.findByCategoryIds(categoryId);
            Collections.shuffle(all);

            all.stream()
                    .filter(s -> !result.contains(s))
                    .limit(5 - result.size())
                    .forEach(result::add);
        }

        return result;
    }
}
