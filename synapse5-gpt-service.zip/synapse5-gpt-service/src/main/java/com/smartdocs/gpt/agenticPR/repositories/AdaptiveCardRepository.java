package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.AdaptiveCardEntity;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface AdaptiveCardRepository extends MongoRepository<AdaptiveCardEntity, String> {
    Optional<AdaptiveCardEntity> findByName(String name);
}
