package com.smartdocs.gpt.agenticPR.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShippingDTO {
    private List<PlantDTO> plants;
    private List<PurchasingGroupDTO> purchasingGroups;
}
