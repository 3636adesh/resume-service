package com.smartdocs.gpt.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.gpt.mongo.model.AiEngineTrainingStatus;

@Repository
public interface TrainingStatusRepository extends MongoRepository<AiEngineTrainingStatus, String> {

}
