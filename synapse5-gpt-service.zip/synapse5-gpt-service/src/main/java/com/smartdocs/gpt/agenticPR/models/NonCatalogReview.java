package com.smartdocs.gpt.agenticPR.models;

import com.smartdocs.gpt.agenticPR.DTO.AccountingDTO;
import com.smartdocs.gpt.agenticPR.DTO.CompanyCodeDTO;
import com.smartdocs.gpt.agenticPR.DTO.PurchasingOrgDTO;
import com.smartdocs.gpt.agenticPR.DTO.ShippingDTO;
import lombok.Data;

import java.util.List;

@Data
public class NonCatalogReview {

//    private String title;
//    private String commodityCode;
//    private String quantity = "";
//    private List<String> vendors;
//    private String estimatedAmount = "";
//    private List<String> uom;
//    private String deliverTo;
//    private String startDate = "";
//    private String endDate = "";
//    private String needByDate = "";
//    private String comments = "";
//    private AccountingDTO accounting;
//    private ShippingDTO shipping;
//    private List<CompanyCodeDTO> companyCodes;
//    private List<PurchasingOrgDTO> purchasingOrganization;


    private String productName;
    private String quantity = "";
    private String needByDate = "";
    private String estimatedPrice = "";
    private String commodityCode;
    private String commodityCodeName;
    private List<String> uom;
    private List<String> currency;



}
