package com.smartdocs.gpt.agenticPR.controllers;

import com.smartdocs.gpt.agenticPR.services.BGEEmbeddingJobService;
import com.smartdocs.gpt.agenticPR.services.CommodityEmbeddingsMigrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/embeddings")
public class EmbeddingController {

    @Autowired
    private CommodityEmbeddingsMigrationService service;

    @Autowired
    private BGEEmbeddingJobService bgeEmbeddingJobService;

    @PostMapping("/migrate")
    public String migrate() {
        service.migrateEmbeddings();
        return "Embedding creation started!";
    }

    @PostMapping("/start")
    public ResponseEntity<String> startEmbeddingCreation() {
        bgeEmbeddingJobService.startEmbeddingJob();
        return ResponseEntity.ok("🚀 Embedding creation started asynchronously!");
    }

}
