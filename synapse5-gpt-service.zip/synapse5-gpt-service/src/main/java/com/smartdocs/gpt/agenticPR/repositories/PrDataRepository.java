package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.PrData;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PrDataRepository extends MongoRepository<PrData, String> {
    PrData findTopByOrderByPrIdDesc();
}
