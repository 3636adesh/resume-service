package com.smartdocs.gpt.mongo.vector.collection;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "BgeVectorDocuments")
public class VectorDocuments {

	public static final String TRAIN_TYPE_DOCUMENT = "document";
	public static final String TRAIN_TYPE_URLS = "urls";

	@Id
	private String id;
	private String botId;
    private String sourceType;
	private String documentName;
	private String documentContent;
	private String siteId;

	@Indexed(name = "bge_vector_index", direction = IndexDirection.ASCENDING)
	private List<Double> embeddings;

	private String documentId;
	private int page;

}
