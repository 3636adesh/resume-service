package com.smartdocs.gpt.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.gpt.mongo.model.PurchaseOrder;

@Repository
public interface PurchaseOrderRepository extends MongoRepository<PurchaseOrder, String>{
	List<PurchaseOrder> findByCommodityId(String commodityId);
}
