package com.smartdocs.gpt.agenticPR.models;

import lombok.Data;

import java.util.List;

@Data
public class UserMessage {

    private String channelId;
    private String productName;
    private String query;
    private String description;
    private String commodityCode;
    private String commodityCodeName;
    List<CatalogItem> lineItems;
    private String transactionId;
    private CatalogSummary userDefaults;
    private NonCatalogSummary nonCatalogSummary;
    private String action;


}
