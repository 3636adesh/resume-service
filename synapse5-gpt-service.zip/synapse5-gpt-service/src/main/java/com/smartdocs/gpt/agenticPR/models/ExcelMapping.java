package com.smartdocs.gpt.agenticPR.models;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "excelMappings")
public class ExcelMapping {

    @Id
    private String id;

    private String transactionId;
    private String countryCode;
    private String commodityCode;
}
