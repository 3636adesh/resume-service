package com.smartdocs.gpt.agenticPR.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "ItemSelections")
public class ItemSelections {
    @Id
    private String id;

    private String transactionId;
    private String userId;
    private List<CatalogItem> items;


    private String commodityCode;
    private String commodityCodeName;
    private long timestamp;

    private String costCenter;
    private String glAccount;
    private String companyCode;
    private String plant;
    private String deliverTo;
    private String purchasingGroup;
    private String purchasingOrganization;
    private String description;
    private Boolean isNonCatalog;
    private Boolean isSync;
}
