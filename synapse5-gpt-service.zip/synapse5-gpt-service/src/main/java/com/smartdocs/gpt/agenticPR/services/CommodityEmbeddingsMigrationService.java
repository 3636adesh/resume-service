package com.smartdocs.gpt.agenticPR.services;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.smartdocs.gpt.openai.model.EmbedingsResponse;
import com.smartdocs.gpt.openai.service.OpenAIService;
import lombok.RequiredArgsConstructor;
import org.bson.Document;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CommodityEmbeddingsMigrationService {

    private final MongoClient mongoClient;
    private final OpenAIService openAiService;

    private static final String DB_NAME = "dev-synapse-ha1_17112025";
    private static final String COLLECTION_NAME = "newAribaCatalogEmbeddings";
//private static final String COLLECTION_NAME = "commodityCodeEmbeddings";

    @Async
    public void migrateEmbeddings() {
        MongoDatabase db = mongoClient.getDatabase(DB_NAME);
        MongoCollection<Document> collection = db.getCollection(COLLECTION_NAME);

        System.out.println("🚀 Starting embedding migration...");

        while (true) {
            Document doc = collection.find(
                    new Document("embedding", new Document("$exists", false))
//                    new Document("embeddings", new Document("$exists", false))
                            .append("skip", new Document("$exists", false))
            ).first();

            if (doc == null) {
                System.out.println("🎉 All documents already have embeddings. Migration complete!");
                break;
            }

            String id = doc.getString("_id");
            String name = doc.getString("shortName");
//            String name = doc.getString("name");

            if (name == null || name.isBlank()) {
                collection.updateOne(new Document("_id", id), new Document("$set", new Document("skip", true)));
                System.out.println("⚠️ Skipping document (no name): " + id);
                continue;
            }

            System.out.println("🧠 Generating embedding for: " + name + " | ID=" + id);

            try {
                EmbedingsResponse response = openAiService.createEmbeddings(name);

                if (response != null && response.getData() != null && !response.getData().isEmpty()) {
                    List<Float> raw = response.getData().get(0).getEmbedding();
                    List<Double> embedding = new ArrayList<>();
                    for (Float f : raw) embedding.add(f.doubleValue());
                    collection.updateOne(
                            new Document("_id", id),
                            new Document("$set", new Document("embedding", embedding))
//                            new Document("$set", new Document("embeddings", embedding))
                    );

                    System.out.println("✅ Updated document with embedding: " + id);
                } else {
                    System.out.println("❌ No embedding returned for document: " + id);
                }
            } catch (Exception e) {
                System.err.println("💥 Error processing document " + id + ": " + e.getMessage());
            }
        }
    }
}
