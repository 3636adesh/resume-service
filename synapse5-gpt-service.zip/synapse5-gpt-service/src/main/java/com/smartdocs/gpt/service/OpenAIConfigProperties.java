package com.smartdocs.gpt.service;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.smartdocs.gpt.model.AiEngineConfig;
import com.smartdocs.gpt.mongo.repository.GptConfigRepository;

import lombok.Data;

@Data
@Component
public class OpenAIConfigProperties {

	private String apiKey;
	private String embeddingModel;
	private String apiUrl;
	private String modelName;
	private String engineName;
    private String engineType;
	private String embeddingApiVersion;
	private String chatApiVersion;

	private final GptConfigRepository gptConfigRepository;

	public OpenAIConfigProperties(GptConfigRepository gptConfigRepository) {
		this.gptConfigRepository = gptConfigRepository;
		buildGptConfig();

	}

	private void buildGptConfig() {
		Optional<AiEngineConfig> existCfgOpt = gptConfigRepository.findByEngineType(AiEngineConfig.ENGINE_TYPE_AZURE);
		if (existCfgOpt.isPresent()) {
			AiEngineConfig existCfg = existCfgOpt.get();
			if (existCfg.isEnable()) {
				setApiUrl(existCfg.getEndPointUrl());
				setModelName(existCfg.getModelName());
				setEngineType(existCfg.getEngineType());
				setApiKey(existCfg.getApiKey());
				setEmbeddingModel(existCfg.getEmbeddingModel());
				setEmbeddingApiVersion(existCfg.getEmbeddingApiVersion());
				setChatApiVersion(existCfg.getChatApiVersion());
			}
		}
	}

}
