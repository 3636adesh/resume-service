package com.smartdocs.gpt.mongo.model;

import java.time.ZonedDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Document
public class AiEngineTrainingStatus {

	public static final String TRAINING_SUCCESS = "Success";
	public static final String TRAINING_FAILED = "Failed";
	public static final String UNSUPPORTED_FILE = "UnsupportedFile";

	@Id
	private String id;

	private String documentId;
	private String engineType;
	private String modelName;
	private String embeddingModel;
	private String status;
	private String errorMessage;
	private ZonedDateTime date = ZonedDateTime.now();
	private String botId;
	private String docId;
	private String fileName;
	private int embeddingTokens;

}
