package com.smartdocs.gpt.agenticPR.models;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "newAribaSupplier")
public class Supplier {
    @Id
    private String id;
    private String supplierId;
    private String supplierName;
    private String classificationCode;
}
