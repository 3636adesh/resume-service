package com.smartdocs.gpt.agenticPR.models;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "supplierData")
public class SupplierData {

    @Id
    private String id;

    private Integer supplierId;
    private String commodityCode;
    private String countryCode;
}
