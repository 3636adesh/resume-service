package com.smartdocs.gpt.intentRecognition.service;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.smartdocs.gpt.BGME3.model.BGEEmbeddingData;
import com.smartdocs.gpt.BGME3.service.BGEM3EmbeddingService;
import com.smartdocs.gpt.helper.TenantContext;
import com.smartdocs.gpt.intentRecognition.Repository.IntentTrainingStatusRepository;
import com.smartdocs.gpt.intentRecognition.Repository.UtteranceEmbeddingRepository;
import com.smartdocs.gpt.intentRecognition.dto.*;
import com.smartdocs.gpt.intentRecognition.models.IntentTrainingStatus;
import com.smartdocs.gpt.model.GPTChatResponse;
import com.smartdocs.gpt.mongo.vector.collection.VectorDocuments;
import com.smartdocs.gpt.openai.model.ChatResponse;
import com.smartdocs.gpt.openai.model.Message;
import com.smartdocs.gpt.openai.service.OpenAIService;
import com.smartdocs.gpt.utils.LanguageUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

@Service
@Slf4j
@RequiredArgsConstructor
public class IntentRecognitionService {

    private final OpenAIService openAIService;

    private final BGEM3EmbeddingService bgeEmbeddingService;

    private final UtteranceEmbeddingRepository utteranceEmbeddingRepository;

    private final IntentTrainingStatusRepository trainingStatusRepository;

    private final MongoClient mongoClient;

    @Value("${vector.db.name}")
    private String dbName;

    private final ObjectMapper objectMapper = new ObjectMapper();

    public GenerateUtterancesResponse generateUtterances(GenerateUtterancesRequest request) {
        String prompt = buildPrompt(request);

        List<Message> messages = new ArrayList<>();

        messages.add(new Message("system","You are an expert in natural language understanding and intent recognition. Your task is to generate diverse and natural utterances that match the given intent pattern."));
        messages.add(new Message("user",prompt));

        Integer outputLength = request.getOutputLength() != null ? request.getOutputLength() : 2000;

        Double temperature = request.getTemperature() != null ? request.getTemperature() : 0.7;

        try {
            ChatResponse chatResponse = openAIService.createChatCompletion(
                    messages,
                    outputLength,
                    temperature
            );

            List<String> generatedUtterances = parseGeneratedUtterances(
                    chatResponse.getChoices().get(0).getMessage().getContent(),
                    request.getNumberOfUtterances()
            );

            GenerateUtterancesResponse response = new GenerateUtterancesResponse();
            response.setGeneratedUtterances(generatedUtterances);
            response.setLabel(request.getLabel());
            response.setRequestedCount(request.getNumberOfUtterances());
            response.setActualCount(generatedUtterances.size());
            response.setStatus("SUCCESS");

            log.info("Successfully generated {} utterances for label: {}",
                    generatedUtterances.size(), request.getLabel());

            return response;

        } catch (Exception e) {
            log.error("Error calling OpenAI service: ", e);
            throw new RuntimeException("Failed to generate utterances: " + e.getMessage(), e);
        }
    }

    public TrainUtterancesResponse trainUtterances(TrainUtterancesRequest request) {

        TrainUtterancesResponse response = new TrainUtterancesResponse();
        response.setLabel(request.getLabel());
        response.setTotalUtterances(request.getUtterances().size());

        IntentTrainingStatus trainingStatus = null;

        try {
            trainingStatus = new IntentTrainingStatus();
            trainingStatus.setIntent(request.getLabel());
            trainingStatus.setBotId(request.getBotId());
            trainingStatus.setStatus("In-Progress");
            trainingStatus.setEmbeddingModel(request.getEmbeddingModel());
            trainingStatus.setDate(ZonedDateTime.now());
            trainingStatusRepository.save(trainingStatus);

            List<String> failedUtterances = new ArrayList<>();
            int savedCount = 0;
            long totalTokens = 0;

            int batchSize = request.getBatchSize() != null ? request.getBatchSize() : 32;
            List<String> utterances = request.getUtterances();

            for (int i = 0; i < utterances.size(); i += batchSize) {
                int end = Math.min(i + batchSize, utterances.size());
                List<String> batch = utterances.subList(i, end);

                try {
                    List<BGEEmbeddingData> embeddings = bgeEmbeddingService.createEmbeddings(batch);

                    for (int j = 0; j < batch.size(); j++) {
                        if (j < embeddings.size()) {
                            try {
                                BGEEmbeddingData embData = embeddings.get(j);
                                UtteranceEmbeddingDocuments entity = new UtteranceEmbeddingDocuments();
                                entity.setUtteranceText(batch.get(j));
                                entity.setSiteId(request.getSiteId());
                                entity.setLabel(request.getLabel());
                                entity.setDescription(request.getDescription());
                                entity.setEmbeddingModel(embData.getModel());
                                entity.setEmbeddingDimension(embData.getDimensions());
                                entity.setTokensUsed(embData.getTokens());
                                entity.setBotId(request.getBotId());
                                entity.setEmbeddings(embData.getEmbedding());

                                utteranceEmbeddingRepository.save(entity);
                                savedCount++;
                                totalTokens += embData.getTokens() != null ? embData.getTokens() : 0;

                            } catch (Exception e) {
                                log.error("Error saving embedding", e);
                                failedUtterances.add(batch.get(j));
                            }
                        }
                    }

                } catch (Exception e) {
                    log.error("Error processing batch", e);
                    failedUtterances.addAll(batch);
                }
            }

            response.setSavedCount(savedCount);
            response.setStatus(failedUtterances.isEmpty() ? "SUCCESS" : "PARTIAL");

            if (trainingStatus != null) {
                trainingStatus.setStatus("Completed");
                trainingStatus.setEmbeddingTokens((int) totalTokens);
                trainingStatusRepository.save(trainingStatus);
            }

        } catch (Exception e) {
            log.error("Error in training", e);
            response.setStatus("ERROR");
            response.setErrorMessage(e.getMessage());
            response.setSavedCount(0);

            if (trainingStatus != null) {
                trainingStatus.setStatus(IntentTrainingStatus.TRAINING_FAILED);
                trainingStatus.setErrorMessage(e.getMessage());
                trainingStatusRepository.save(trainingStatus);
            }
        }

        return response;
    }

    public IntentDetectionResponse intentDetection(IntentDetectionRequest request) throws IOException, InterruptedException{
        BGEEmbeddingData queryEmbeddings = bgeEmbeddingService.createEmbedding(request.getUserQuery());
        MongoDatabase database = mongoClient.getDatabase(dbName);

        MongoCollection<Document> collection = database.getCollection("utteranceEmbeddings");
        int numCandidates = 50;
        int limit = 5;

        double similarityThreshold = 0.00;

        List<String> matchingSiteIds = mongoClient.getDatabase(dbName)
                .getCollection("utteranceEmbeddings")
                .distinct("siteId",
                        Filters.regex("siteId", "^" + Pattern.quote(request.getSiteId())),
                        String.class)
                .into(new ArrayList<>());

        System.out.println("Matching siteIds for BGE vector search: " + matchingSiteIds);

        if (matchingSiteIds.isEmpty()) {
            IntentDetectionResponse errorResponse = new IntentDetectionResponse();
            errorResponse.setResponse("No matching documents found for siteId prefix: " + request.getSiteId());
            return errorResponse;
        }

        Document filter = new Document("siteId", new Document("$in", matchingSiteIds));

        List<Bson> aggregationPipeline = Arrays.asList(
                new Document("$vectorSearch",
                        new Document()
                                // CHANGE 4: Use BGE vector index name
                                .append("index", "vector_index")
                                .append("path", "embeddings")
                                .append("filter", filter)
                                // CHANGE 5: Use BGE embedding vector
                                .append("queryVector", queryEmbeddings.getEmbedding())
                                .append("numCandidates", numCandidates)
                                .append("limit", limit * 2) // Get more candidates for filtering
                ),
                new Document("$addFields",
                        new Document("similarityScore", new Document("$meta", "vectorSearchScore"))
                ),
                new Document("$match",
                        new Document("similarityScore", new Document("$gte", similarityThreshold))
                ),
                new Document("$sort",
                        new Document("similarityScore", -1)
                ),
                new Document("$limit", limit)
        );

        AggregateIterable<Document> result = collection.aggregate(aggregationPipeline);
        List<UtteranceEmbeddingDocuments> documents = new ArrayList<>();

        for (var doc : result){
            JSONObject jsonObject = JSONObject.parseObject(doc.toJson());
            UtteranceEmbeddingDocuments vectorDocuments = new UtteranceEmbeddingDocuments();
            vectorDocuments.setUtteranceText(jsonObject.getString("utteranceText"));
            vectorDocuments.setLabel(jsonObject.getString("label"));
            vectorDocuments.setDescription(jsonObject.getString("description"));

            String oId = jsonObject.getString("_id");
            var id = new org.json.JSONObject(oId).getString("$oid");

            vectorDocuments.setId(id);
            documents.add(vectorDocuments);
            double similarity = jsonObject.getDoubleValue("similarityScore");
            System.out.println("BGE Similarity score for: " + vectorDocuments.getUtteranceText() + " : " + similarity);
        }

        String userLangCode = request.getUserLanguage() != null ? request.getUserLanguage() : "en";
        String fullLanguage = LanguageUtils.getEnglishLanguageName(userLangCode);

        String systemPrompt = String.format("""
        ROLE:
        You are an intent classifier. Use the retrieved examples as hints but ALWAYS compare the user query to the KNOWN_INTENTS list below. 
        Use examples only as context; do not be forced to follow them. Output strict JSON only.
        
        TASK:
        Given a user query, up to 5 nearest labeled examples (may be noisy), and the list of KNOWN_INTENTS (with descriptions), return the best intent from the KNOWN_INTENTS, a confidence (0.0-1.0), optional alternatives [{intent,confidence}], entities (object), missing_slots (array), and a one-line reason. 
        If multiple intents apply, return them as an array with confidences.
        """);

        List<Message> messages = new ArrayList<>();

        messages.add(new Message("system", systemPrompt));

        String userPrompt = String.format("""
        USER QUERY:
        [USER_QUERY]
        
        NEAREST EXAMPLES(label-text):
        [UTTERANCES_RETRIEVED]
        
        KNOWN INTENTS WITH DESCRIPTION:
        [INTENTS]
        
        REQUIREMENTS:
        1) Output JSON only: keys = intent, confidence, alternatives (opt), entities, missing_slots, reason.
        2) If all example similarities < {{medium_sim}} and no KNOWN_INTENT matches, return "unknown" with low confidence.
        3) If multiple intents plausibly apply, return alternatives with confidences.
        4) Validate simple entities (e.g., PO numbers digits-only).
        """);

        StringBuilder utteranceContext = new StringBuilder();
        for (UtteranceEmbeddingDocuments document : documents) {
            utteranceContext.append(document.getUtteranceText());
            utteranceContext.append("->").append(document.getLabel()).append("\n");
        }

        StringBuilder intentContext = new StringBuilder();
        for(int i = 0 ; i < request.getIntents().size() ; i++){
            intentContext.append(request.getIntents().get(i).getLabel()).append(": ").append(request.getIntents().get(i).getDescription()).append("\n");
        }
        String finalUserPrompt = userPrompt.replace("[USER_QUERY]", request.getUserQuery()).replace("[UTTERANCES_RETRIEVED]", utteranceContext.toString()).replace("[INTENTS]", intentContext.toString());
        messages.add(new Message("user", finalUserPrompt));

        ChatResponse chatResponsee = openAIService.createChatCompletion(messages, request.getOutputLength(),
                request.getTemperature());
        String openAiResponse = chatResponsee.getChoices().get(0).getMessage().getContent();

        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(openAiResponse);

        IntentDetectionResponse res = new IntentDetectionResponse();
        res.setResponse("Response sent successfully!");
        res.setIntent(root.path("intent").asText());
        res.setConfidence((float) root.path("confidence").asDouble());
        res.setReason(root.path("reason").asText());

        ArrayList<String> entityList = new ArrayList<>();
        JsonNode entitiesNode = root.path("entities");

        entitiesNode.fieldNames().forEachRemaining(key -> {
            entityList.add(entitiesNode.get(key).asText());
        });

        res.setEntities(entityList);

        return res;
    }

    private String buildPrompt(GenerateUtterancesRequest request) {
        StringBuilder prompt = new StringBuilder();

        prompt.append("Generate ").append(request.getNumberOfUtterances())
                .append(" new utterances for the intent labeled '").append(request.getLabel()).append("'.\\n\\n");

        if (request.getDescription() != null && !request.getDescription().isEmpty()) {
            prompt.append("Intent Description: ").append(request.getDescription()).append("\\n\\n");
        }

        prompt.append("Example utterances:\\n");
        for (int i = 0; i < request.getUtterances().size(); i++) {
            prompt.append((i + 1)).append(". ").append(request.getUtterances().get(i)).append("\\n");
        }

        prompt.append("\\nGenerate ").append(request.getNumberOfUtterances())
                .append(" new, diverse utterances that follow the same pattern and intent as the examples above. ")
                .append("Return them as a numbered list, one utterance per line.\\n")
                .append("Do not include any explanations, just the utterances.");

        return prompt.toString();
    }

    private List<String> parseGeneratedUtterances(String content, int expectedCount) {
        List<String> utterances = new ArrayList<>();

        if (content == null || content.isEmpty()) {
            return utterances;
        }

        String[] lines = content.split("\\n");

        for (String line : lines) {
            line = line.trim();

            if (line.isEmpty()) {
                continue;
            }

            String utterance = line.replaceFirst("^\\d+[\\.\\)\\-]\\s*", "")
                    .replaceFirst("^[-\\*•]\\s*", "")
                    .trim();

            if (!utterance.isEmpty()) {
                utterances.add(utterance);
            }

            if (utterances.size() >= expectedCount) {
                break;
            }
        }

        return utterances;
    }
}
