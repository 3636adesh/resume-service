package com.smartdocs.gpt.config;


import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Base64;

@Component
public class BasicSecurityConfig {

    private static String gptAppId;
    private static String gptAppSecret;

    @Value("${gpt.be.appId}")
    public void setGptAppId(String gptAppId) {
        BasicSecurityConfig.gptAppId = gptAppId;
    }

    @Value("${gpt.be.appSecret}")
    public void setGptAppSecret(String gptAppSecret){
        BasicSecurityConfig.gptAppSecret = gptAppSecret;
    }

    public static boolean validateSynapseBackend(String authzHeader) {
        boolean flag = false;
        if (authzHeader != null && !StringUtils.isEmpty(authzHeader)) {
            String appIdAndAppSecret = new String(Base64.getDecoder().decode(authzHeader.substring(6).getBytes()));
            int appIdIndex = appIdAndAppSecret.indexOf(":");
            String appId = appIdAndAppSecret.substring(0, appIdIndex);
            String appSecret = appIdAndAppSecret.substring(appIdIndex + 1);
            if (appId != null && appSecret != null && (appId.equals(gptAppId) && appSecret.equals(gptAppSecret))) {
                flag = true;
            }
        }
        return flag;
    }


}
