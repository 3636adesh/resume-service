package com.smartdocs.gpt.model;

import lombok.Data;

@Data
public class PreviousMessages {
	private String userMessage;
	private String botMessage;

}
