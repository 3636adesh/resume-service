package com.smartdocs.gpt.intentRecognition.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.ZonedDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document
public class IntentTrainingStatus {

    public static final String TRAINING_SUCCESS = "Success";
    public static final String TRAINING_FAILED = "Failed";
    public static final String UNSUPPORTED_FILE = "UnsupportedFile";

    @Id
    private String id;

    private String engineType;
    private String modelName;
    private String embeddingModel;
    private String status;
    private String errorMessage;
    private ZonedDateTime date = ZonedDateTime.now();
    private String botId;
    private String intent;
    private int embeddingTokens;

}
