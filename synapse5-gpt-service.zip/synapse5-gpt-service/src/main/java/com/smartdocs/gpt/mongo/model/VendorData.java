package com.smartdocs.gpt.mongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document(collection = "GPT_vendor_data")
@Data
public class VendorData {

	@Id
    private String id;
    private String erpVendorId;
    private String description;
    private String category;
    private String qualificationRegion;
    private String status;
    private String level;
    private String levelID;
    private String legacySLPDepartmentIds;
    private String supplierANNumber;
    private String phone;
    private String fax;
    private String line1;
    private String postalCode;
    private String city;
    private String state;
    private String stateName;
    private String countryCode;
    
    
	@Override
	public String toString() {
		return "VendorData [erpVendorId=" + erpVendorId + ", description=" + description + ", category=" + category
				+ ", qualificationRegion=" + qualificationRegion + ", status=" + status + ", level=" + level
				+ ", levelID=" + levelID + ", legacySLPDepartmentIds=" + legacySLPDepartmentIds + ", supplierANNumber="
				+ supplierANNumber + ", phone=" + phone + ", fax=" + fax + ", line1=" + line1 + ", postalCode="
				+ postalCode + ", city=" + city + ", state=" + state + ", stateName=" + stateName + ", countryCode="
				+ countryCode + "]";
	}
    
    
    
}
