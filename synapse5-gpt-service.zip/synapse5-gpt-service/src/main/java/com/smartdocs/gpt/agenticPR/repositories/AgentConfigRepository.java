package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.openai.config.AgentConfig;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AgentConfigRepository extends MongoRepository<AgentConfig, String> {
}
