package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.AribaUnitOfMeasure;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AribaUnitOfMeasureRepository extends MongoRepository<AribaUnitOfMeasure , String> {
}
