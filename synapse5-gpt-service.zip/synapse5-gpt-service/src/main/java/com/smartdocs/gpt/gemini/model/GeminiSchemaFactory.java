package com.smartdocs.gpt.gemini.model;

import java.util.List;
import java.util.Map;

public class GeminiSchemaFactory {

    /**
     * Schema for chat responses with response text and sources
     */
    public static Map<String, Object> createChatResponseSchema() {
        return Map.of(
                "type", "object",
                "properties", Map.of(
                        "response", Map.of(
                                "type", "string",
                                "description", "The main response content answering the user's question"
                        ),
                        "sources", Map.of(
                                "type", "array",
                                "items", Map.of("type", "string"),
                                "description", "List of source document IDs used to generate the response"
                        )
                ),
                "required", List.of("response", "sources")
        );
    }

    /**
     * Schema for suggested questions with questions array and translated header
     */
    public static Map<String, Object> createSuggestedQuestionsSchema() {
        return Map.of(
                "type", "object",
                "properties", Map.of(
                        "suggestedQuestions", Map.of(
                                "type", "array",
                                "items", Map.of("type", "string"),
                                "description", "Array of 2-3 suggested follow-up questions"
                        ),
                        "translatedHeader", Map.of(
                                "type", "string",
                                "description", "Translated version of the header line"
                        )
                ),
                "required", List.of("suggestedQuestions", "translatedHeader")
        );
    }

    /**
     * Extended schema for suggested questions with additional fields for past conversations
     */
    public static Map<String, Object> createExtendedSuggestedQuestionsSchema() {
        return Map.of(
                "type", "object",
                "properties", Map.of(
                        "suggestedQuestions", Map.of(
                                "type", "array",
                                "items", Map.of("type", "string"),
                                "description", "Array of 2-3 suggested follow-up questions"
                        ),
                        "translatedHeader", Map.of(
                                "type", "string",
                                "description", "Translated version of the header line"
                        ),
                        "helpfulResourcesText", Map.of(
                                "type", "string",
                                "description", "Translation of 'Helpful Resources'"
                        ),
                        "createTicketText", Map.of(
                                "type", "string",
                                "description", "Translation of 'Create Ticket'"
                        )
                ),
                "required", List.of("suggestedQuestions", "translatedHeader", "helpfulResourcesText", "createTicketText")
        );
    }

    /**
     * Generic schema for simple text analysis tasks
     */
    public static Map<String, Object> createAnalysisResponseSchema() {
        return Map.of(
                "type", "object",
                "properties", Map.of(
                        "analysis", Map.of(
                                "type", "string",
                                "description", "The analysis result"
                        ),
                        "confidence", Map.of(
                                "type", "number",
                                "description", "Confidence score between 0 and 1"
                        ),
                        "categories", Map.of(
                                "type", "array",
                                "items", Map.of("type", "string"),
                                "description", "Relevant categories or tags"
                        )
                ),
                "required", List.of("analysis")
        );
    }

    /**
     * Schema for summary generation tasks
     */
    public static Map<String, Object> createSummarySchema() {
        return Map.of(
                "type", "object",
                "properties", Map.of(
                        "summary", Map.of(
                                "type", "string",
                                "description", "The generated summary"
                        ),
                        "keyPoints", Map.of(
                                "type", "array",
                                "items", Map.of("type", "string"),
                                "description", "Key points extracted from the content"
                        ),
                        "wordCount", Map.of(
                                "type", "integer",
                                "description", "Number of words in the summary"
                        )
                ),
                "required", List.of("summary", "keyPoints")
        );
    }

    /**
     * Custom schema builder for dynamic schema creation
     */
    public static class SchemaBuilder {
        private Map<String, Object> properties = new java.util.HashMap<>();
        private List<String> required = new java.util.ArrayList<>();

        public SchemaBuilder addStringProperty(String name, String description, boolean isRequired) {
            properties.put(name, Map.of(
                    "type", "string",
                    "description", description
            ));
            if (isRequired) {
                required.add(name);
            }
            return this;
        }

        public SchemaBuilder addArrayProperty(String name, String description, String itemType, boolean isRequired) {
            properties.put(name, Map.of(
                    "type", "array",
                    "items", Map.of("type", itemType),
                    "description", description
            ));
            if (isRequired) {
                required.add(name);
            }
            return this;
        }

        public SchemaBuilder addNumberProperty(String name, String description, boolean isRequired) {
            properties.put(name, Map.of(
                    "type", "number",
                    "description", description
            ));
            if (isRequired) {
                required.add(name);
            }
            return this;
        }

        public SchemaBuilder addIntegerProperty(String name, String description, boolean isRequired) {
            properties.put(name, Map.of(
                    "type", "integer",
                    "description", description
            ));
            if (isRequired) {
                required.add(name);
            }
            return this;
        }

        public SchemaBuilder addBooleanProperty(String name, String description, boolean isRequired) {
            properties.put(name, Map.of(
                    "type", "boolean",
                    "description", description
            ));
            if (isRequired) {
                required.add(name);
            }
            return this;
        }

        public Map<String, Object> build() {
            return Map.of(
                    "type", "object",
                    "properties", properties,
                    "required", required
            );
        }
    }

    /**
     * Create a new schema builder for custom schemas
     */
    public static SchemaBuilder builder() {
        return new SchemaBuilder();
    }
}