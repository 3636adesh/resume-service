package com.smartdocs.gpt.utils;

import java.util.ArrayList;
import java.util.List;

public class VectorNormalizer {

    /**
     * L2 normalize a vector (make its magnitude = 1.0)
     * Critical for gemini-embedding-001 with 1536 dimensions
     */
    public static List<Double> normalizeVector(List<Double> vector) {
        if (vector == null || vector.isEmpty()) {
            throw new IllegalArgumentException("Vector cannot be null or empty");
        }

        double sumOfSquares = 0.0;
        for (Double value : vector) {
            if (value != null) {
                sumOfSquares += value * value;
            }
        }

        double magnitude = Math.sqrt(sumOfSquares);

        if (magnitude == 0.0) {
            return new ArrayList<>(vector);
        }

        List<Double> normalizedVector = new ArrayList<>(vector.size());
        for (Double value : vector) {
            normalizedVector.add(value != null ? value / magnitude : 0.0);
        }

        return normalizedVector;
    }

    public static boolean isNormalized(List<Double> vector, double tolerance) {
        double magnitude = calculateMagnitude(vector);
        return Math.abs(magnitude - 1.0) <= tolerance;
    }
    
    public static double calculateMagnitude(List<Double> vector) {
        double sumOfSquares = 0.0;
        for (Double value : vector) {
            if (value != null) {
                sumOfSquares += value * value;
            }
        }
        return Math.sqrt(sumOfSquares);
    }
}

