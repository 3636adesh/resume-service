package com.smartdocs.gpt.openai.model;

import com.smartdocs.gpt.model.PreviousMessages;
import com.smartdocs.gpt.model.SourceObject;
import lombok.Data;

import java.util.List;

@Data 
public class ChatRequestForSuggestion {

	private String suggestedQuestionsPrompt;
	private String text;
	List<PreviousMessages> previousMessages;
	List<SourceObject> sources;
	private String headerLine;
	private String userLanguage;

}
