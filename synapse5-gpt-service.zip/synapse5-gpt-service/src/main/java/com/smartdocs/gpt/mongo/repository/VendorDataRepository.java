package com.smartdocs.gpt.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.smartdocs.gpt.mongo.model.VendorData;

public interface VendorDataRepository extends MongoRepository<VendorData, String> {
	
	List<VendorData> findByCategory(String category);
}
