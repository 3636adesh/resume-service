package com.smartdocs.gpt.gemini.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmbedContentRequest {
    private Content content;

    @JsonProperty("output_dimensionality")
    private Integer outputDimensionality;
}
