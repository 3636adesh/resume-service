package com.smartdocs.gpt.agenticPR.models;

import com.smartdocs.gpt.agenticPR.DTO.AccountingDTO;
import com.smartdocs.gpt.agenticPR.DTO.ShippingDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CatalogItem {
    private String id;
    private String productName;
    private String supplierId;
    private String supplierName;
    private String imageUrl;
    private Double priceAmount;
    private String currency;
    private String estimatedPrice;
    private String uom;
    private String needByDate = "";
    private String quantity = "";
    private String commodityCode;
    private String commodityCodeName;

//    private AccountingDTO accounting;
//    private ShippingDTO shipping;

}