package com.smartdocs.gpt.mongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document(collection = "GPT_purchaseOrder")
@Data
public class PurchaseOrder {
	
	@Id
	private String Id;
	private String requisitionId;
    private String requisitionDate;
    private String commodityId;
    private String companyCode;
    private String purchasingUnitId;
    private String description;
    private String orderId;
    private String orderedDate;
    private String supplierId;
    private String supplier;
    private String shipToAddress;
    private String shipToCity;
    private String shipToCountry;
    private String shipToLocationId;

}
