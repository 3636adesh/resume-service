package com.smartdocs.gpt.document.util;
public class Utils {

	public static String quoted(String string) {
		if (string == null) {
			return "null";
		}
		return "\"" + string + "\"";
	}
}