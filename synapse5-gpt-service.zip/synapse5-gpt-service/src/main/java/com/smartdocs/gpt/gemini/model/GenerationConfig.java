package com.smartdocs.gpt.gemini.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GenerationConfig {
    private Integer maxOutputTokens;
    private Float temperature;
    private String responseMimeType;
    private Object responseSchema;    
}