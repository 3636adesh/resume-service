package com.smartdocs.gpt.agenticPR.services;

import com.smartdocs.gpt.BGME3.model.BGEEmbeddingData;
import com.smartdocs.gpt.BGME3.service.BGEM3EmbeddingService;
import com.smartdocs.gpt.agenticPR.DTO.AribaCatalogBGE;
import com.smartdocs.gpt.agenticPR.models.AribaCatalog;
import com.smartdocs.gpt.agenticPR.repositories.AribaCatalogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BGEEmbeddingJobService {

    private final AribaCatalogRepository catalogRepository;
    private final MongoTemplate mongoTemplate;
    private final BGEM3EmbeddingService bgem3EmbeddingService;

    @Async
    public void startEmbeddingJob() {
        int batchNumber = 1;

        while (true) {
            List<AribaCatalog> batch = catalogRepository.findTop500ByIsEmbeddingIsNull();
            if (batch.isEmpty()) {
                log.info("✅ All documents have embeddings — job completed!");
                break;
            }

            log.info("🚀 Processing batch {} ({} docs)", batchNumber, batch.size());
            AtomicInteger success = new AtomicInteger();
            AtomicInteger failed = new AtomicInteger();
            AtomicInteger skipped = new AtomicInteger();

            List<AribaCatalog> validDocs = batch.stream()
                    .filter(doc -> doc.getShortName() != null && !doc.getShortName().trim().isEmpty())
                    .collect(Collectors.toList());

            if (validDocs.isEmpty()) {
                batch.forEach(this::markAsFailed);
                log.warn("⚠️ Batch {} skipped — no valid shortNames", batchNumber);
                continue;
            }

            List<String> texts = validDocs.stream().map(AribaCatalog::getShortName).toList();

            try {
                List<BGEEmbeddingData> embeddingResults = bgem3EmbeddingService.createEmbeddings(texts);
                for (int i = 0; i < validDocs.size(); i++) {
                    AribaCatalog doc = validDocs.get(i);
                    try {
                        List<Double> embedding = embeddingResults.get(i).getEmbedding();
                        saveToBgeCollection(doc, embedding);
                        doc.setIsEmbedding(true);
                        catalogRepository.save(doc);
                        success.incrementAndGet();
                    } catch (Exception e) {
                        markAsFailed(doc);
                        failed.incrementAndGet();
                        log.warn("❌ Failed to save embedding for doc {}: {}", doc.getId(), e.getMessage());
                    }
                }

                batch.stream()
                        .filter(d -> d.getShortName() == null || d.getShortName().trim().isEmpty())
                        .forEach(d -> {
                            markAsFailed(d);
                            skipped.incrementAndGet();
                        });

                log.info("✅ Batch {} complete — success={}, failed={}, skipped={}",
                        batchNumber, success.get(), failed.get(), skipped.get());

            } catch (Exception e) {
                log.error("🔥 Batch {} error during embedding generation: {}", batchNumber, e.getMessage(), e);
                validDocs.forEach(this::markAsFailed);
            }

            batchNumber++;
        }
    }

    private void markAsFailed(AribaCatalog doc) {
        doc.setIsEmbedding(false);
        catalogRepository.save(doc);
    }

    private void saveToBgeCollection(AribaCatalog doc, List<Double> embedding) {
        String segmentCode = extractSegmentCode(doc.getClassificationCode());
        AribaCatalogBGE bgeDoc = AribaCatalogBGE.builder()
                .id(doc.getId())
                .shortName(doc.getShortName())
                .priceAmount(doc.getPriceAmount())
                .priceCurrencyUniqueName(doc.getPriceCurrencyUniqueName())
                .supplierName(doc.getSupplierName())
                .unitOfMeasure(doc.getUnitOfMeasure())
                .segmentCode(segmentCode)
                .imageUrl(doc.getUrl())
                .embedding(embedding)
                .timestamp(new Date())
                .build();

        mongoTemplate.save(bgeDoc);
    }

    private String extractSegmentCode(String classificationCode) {
        if (classificationCode == null) return null;
        if (classificationCode.contains(":")) {
            return classificationCode.substring(classificationCode.indexOf(":") + 1).trim();
        }
        return classificationCode;
    }
}
