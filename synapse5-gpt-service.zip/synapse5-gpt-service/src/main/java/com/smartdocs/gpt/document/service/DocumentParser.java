package com.smartdocs.gpt.document.service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.extractor.ExtractorFactory;
import org.apache.poi.extractor.POITextExtractor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.smartdocs.gpt.document.model.Document;
import com.smartdocs.gpt.document.util.HtmlToPlainText;

public class DocumentParser {

	public static Map<Integer, Document> msOfficeDocumentParser(InputStream inputStream) {
		Map<Integer, Document> content = new HashMap<Integer, Document>();
		try (POITextExtractor extractor = ExtractorFactory.createExtractor(inputStream)) {
			String text = extractor.getText();
			content.put(0, Document.from(preprocessText(text)));

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return content;
	}
    // Improved parser for Excel files (.xls, .xlsx)
    public static Map<Integer, Document> excelDocumentParser(InputStream inputStream) {
        Map<Integer, Document> content = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            int numberOfSheets = workbook.getNumberOfSheets();
            for (int i = 0; i < numberOfSheets; i++) {
                Sheet sheet = workbook.getSheetAt(i);
                sb.append("Sheet: ").append(sheet.getSheetName()).append("\n");
                for (Row row : sheet) {
                    for (Cell cell : row) {
                       
                        sb.append(cell.getStringCellValue()).append("\t");
                    }
                    sb.append("\n");
                }
                sb.append("\n");
            }
            content.put(0, Document.from(preprocessText(sb.toString())));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return content;
    }

    // Improved parser for PowerPoint files (.ppt, .pptx)
    public static Map<Integer, Document> pptDocumentParser(InputStream inputStream, String fileExtension) {
       return null;
    }

    public static Map<Integer, Document> textDocumentparse(InputStream inputStream) {
        Map<Integer, Document> content = new HashMap<>();

        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            int nRead;
            byte[] data = new byte[1024];
            while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }
            buffer.flush();

            String text = new String(buffer.toByteArray(), StandardCharsets.UTF_8);
            content.put(0, Document.from(preprocessText(text)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return content;
    }

    public static Map<Integer, Document> pdfDocumentParse(InputStream inputStream) {
		Map<Integer, Document> content = new HashMap<>();

		try {

			PdfReader pdfReader = new PdfReader(inputStream);
			int numberOfPages = pdfReader.getNumberOfPages();
			for (int page = 1; page <= numberOfPages; page++) {
				String pageText = PdfTextExtractor.getTextFromPage(pdfReader, page);
				if (StringUtils.isNotBlank(pageText)) {
					content.put(page, Document.from(preprocessText(pageText)));
				}
			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return content;
	}

    public static Map<Integer, Document> qnaDocumentParse(String question, String answer) {
        Map<Integer, Document> content = new HashMap<>();
        try {
            StringBuilder sb = new StringBuilder("This is the pair of question and answer which is the source in this case");
            sb.append("'''\nQuestion: ").append(question).append("\n\n");
            sb.append("Answer: ").append(answer).append("'''");
            content.put(0, Document.from(preprocessText(sb.toString())));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return content;
    }

    public static Map<Integer, Document> htmlDocumentParse(String htmlLink) {
        Map<Integer, Document> content = new HashMap<>();
        try {
            String textContent = HtmlToPlainText.convert(htmlLink, null);
            content.put(0, Document.from(preprocessText(textContent)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return content;
    }

    public static Map<Integer, Document> articleDocumentParse(String data) {
        Map<Integer, Document> content = new HashMap<>();
        try {
            content.put(0, Document.from(preprocessText(data)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return content;
    }

    // Function to clean string
    private static String preprocessText(String inputText) {
//        Pattern nonAlphanumericPattern = Pattern.compile("[^a-zA-Z0-9\\s]");
//        Pattern extraSpacesPattern = Pattern.compile("\\s{2,}");
//        Pattern newlinePattern = Pattern.compile("\\r?\\n");
//
//        Matcher matcher = nonAlphanumericPattern.matcher(inputText);
//        String cleanText = matcher.replaceAll(" ");
//        matcher = newlinePattern.matcher(cleanText);
//        cleanText = matcher.replaceAll(" ");
//        matcher = extraSpacesPattern.matcher(cleanText);
//        cleanText = matcher.replaceAll(" ");

        return inputText.trim();
    }

    // Function to get chunks (if needed for further processing)
    public static List<String> getChunks(String input) {
        List<String> dividedStrings = new ArrayList<>();
        int maxLength = 7061;
        int length = input.length();
        int startIndex = 0;
        while (startIndex < length) {
            int endIndex = Math.min(startIndex + maxLength, length);
            String substring = input.substring(startIndex, endIndex);
            dividedStrings.add(substring);
            startIndex = endIndex;
        }
        return dividedStrings;
    }
}