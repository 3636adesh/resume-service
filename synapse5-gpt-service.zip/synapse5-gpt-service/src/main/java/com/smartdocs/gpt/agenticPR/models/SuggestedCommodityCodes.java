package com.smartdocs.gpt.agenticPR.models;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class SuggestedCommodityCodes {

    private String name;
    List<String> commodityCodes;
    private String commodityType;
//    private List<String> recommendedVendors;
   // private List<PreviousPurchaseDTO> previousPurchses;
}
