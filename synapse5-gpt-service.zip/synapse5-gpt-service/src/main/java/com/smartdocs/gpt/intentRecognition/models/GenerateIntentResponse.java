package com.smartdocs.gpt.intentRecognition.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GenerateIntentResponse {
    private String content;
    private String model;
    private Integer totalTokens;
    private String finishReason;
}
