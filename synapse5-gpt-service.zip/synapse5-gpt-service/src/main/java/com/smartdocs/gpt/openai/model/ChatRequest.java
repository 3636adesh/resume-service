package com.smartdocs.gpt.openai.model;

import java.util.ArrayList;
import java.util.List;

import com.smartdocs.gpt.model.ResponseFormat;

import lombok.Data;

@Data
public class ChatRequest {

	private String model;
	private List<Message> messages;

	private double temperature;
//	private ResponseFormat response_format;

	public ChatRequest(String model, String prompt) {
		this.model = model;

		this.messages = new ArrayList<>();
		this.messages.add(new Message("user", prompt));
	}

	public ChatRequest(String model, List<Message> messages, double temperature) {
		this.model = model;
		this.messages = messages;
		
		this.temperature = temperature;
//		this.response_format=responseformat;
	}

	@Override
	public String toString() {
		return "ChatRequest [model=" + model + ", messages=" + messages + ", temperature=" + temperature + "]";
	}

	

	
}
