package com.smartdocs.gpt.intentRecognition.controller;

import com.azure.core.annotation.Post;
import com.smartdocs.gpt.intentRecognition.dto.*;
import com.smartdocs.gpt.intentRecognition.service.IntentRecognitionService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/intent")
@Slf4j
public class IntentRecognitionController {

    @Autowired
    private IntentRecognitionService intentRecognitionService;

    @Autowired
    private IntentRecognitionService trainUtterancesService;

    @PostMapping("/generateUtterances")
    public ResponseEntity<GenerateUtterancesResponse> generateUtterances(
            @Valid @RequestBody GenerateUtterancesRequest request) {

        log.info("Received request to generate {} utterances for label: {}",
                request.getNumberOfUtterances(), request.getLabel());

        try {
            GenerateUtterancesResponse response = intentRecognitionService.generateUtterances(request);

            if (response.getGeneratedUtterances() != null && !response.getGeneratedUtterances().isEmpty()) {
                return ResponseEntity.status(HttpStatus.CREATED).body(response);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            }

        } catch (Exception e) {
            log.error("Error generating utterances: ", e);

            GenerateUtterancesResponse errorResponse = new GenerateUtterancesResponse();
            errorResponse.setLabel(request.getLabel());
            errorResponse.setRequestedCount(request.getNumberOfUtterances());
            errorResponse.setActualCount(0);
            errorResponse.setStatus("ERROR");
            errorResponse.setErrorMessage(e.getMessage());

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }


    @PostMapping("/trainUtterances")
    public ResponseEntity<TrainUtterancesResponse> trainUtterances(
            @RequestBody TrainUtterancesRequest request) {

        log.info("Training utterances for label: {} and botId: {}",
                request.getLabel(), request.getBotId());

        try {
            TrainUtterancesResponse response = trainUtterancesService.trainUtterances(request);

            if ("SUCCESS".equals(response.getStatus())) {
                return ResponseEntity.status(HttpStatus.CREATED).body(response);
            } else {
                return ResponseEntity.ok(response);
            }

        } catch (Exception e) {
            log.error("Error training utterances", e);
            TrainUtterancesResponse error = new TrainUtterancesResponse();
            error.setLabel(request.getLabel());
            error.setStatus("ERROR");
            error.setErrorMessage(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    @PostMapping("/detectIntent")
    public IntentDetectionResponse detectIntent(@RequestBody IntentDetectionRequest request) {

        log.info("Training utterances for query: {} ",
                request.getUserQuery());

        try {
            IntentDetectionResponse response = trainUtterancesService.intentDetection(request);
            return response;

        } catch (Exception e) {
            log.error("Error training utterances", e);
            IntentDetectionResponse error = new IntentDetectionResponse();
            error.setResponse(e.getMessage());
            return error;
        }
    }

}
