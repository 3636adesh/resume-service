package com.smartdocs.gpt.agenticPR.models;

import com.smartdocs.gpt.agenticPR.DTO.LineItemsSummaryDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "pr_data")
public class PrData {

    @Id
    private String id;
    private String prId;
    private CatalogSummary lineItemsSummary;
    private String action;
    private NonCatalogSummary nonCatalogSummary;
}
