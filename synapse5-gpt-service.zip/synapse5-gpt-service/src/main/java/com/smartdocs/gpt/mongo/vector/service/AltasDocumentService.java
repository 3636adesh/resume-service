package com.smartdocs.gpt.mongo.vector.service;

import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.mongodb.client.model.Filters;
import com.smartdocs.gpt.BGME3.model.BGEEmbeddingData;
import com.smartdocs.gpt.BGME3.service.BGEM3EmbeddingService;
import com.smartdocs.gpt.mongo.model.*;
import com.smartdocs.gpt.mongo.repository.*;
import com.smartdocs.gpt.openai.model.EmbeddingData;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.smartdocs.gpt.model.*;
import com.smartdocs.gpt.service.OpenAIConfigProperties;
import com.smartdocs.gpt.utils.LanguageUtils;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.commonmark.ext.gfm.tables.TablesExtension;
import org.commonmark.node.Node;
import org.commonmark.parser.Parser;
import org.commonmark.renderer.html.HtmlRenderer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.smartdocs.gpt.document.model.QnA;
import com.smartdocs.gpt.document.model.TextSegment;
import com.smartdocs.gpt.document.model.TrainDocumentRequest;
import com.smartdocs.gpt.document.service.DocumentService;
import com.smartdocs.gpt.helper.PhraseResponse;
import com.smartdocs.gpt.helper.TenantContext;
import com.smartdocs.gpt.mongo.vector.collection.UrlObject;
import com.smartdocs.gpt.mongo.vector.collection.VectorDocuments;
import com.smartdocs.gpt.mongo.vector.repository.UrlObjectRepository;
import com.smartdocs.gpt.mongo.vector.repository.VectorDocumentsRepository;
import com.smartdocs.gpt.openai.model.ChatResponse;
import com.smartdocs.gpt.openai.model.Message;
import com.smartdocs.gpt.openai.model.TranslationResponse;
import com.smartdocs.gpt.openai.service.OpenAIService;
import com.smartdocs.gpt.service.CommonService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class AltasDocumentService {

	private final VectorDocumentsRepository vectorDocumentsRepository;

	private final DocumentService documentService;

	private final TrainingStatusRepository trainingStatusRepository;

	private final MongoClient mongoClient;

	private final OpenAIService openAIService;

	private final CommonService commonService;

	private final UrlObjectRepository urlObjectRepository;

	private final TaxanomyDetailsRepository taxanomyDetailsRepository;

	private final VendorDataRepository vendorDataRepository;

	private final PurchaseOrderRepository purchaseOrderRepository;

	private final CatalogVendorDetailsRepository catalogVendorDetailsRepository;

	private final OpenAIConfigProperties openAIConfigProperties;

	private final AiEngineFileDetailsRepository aiEngineFileDetailsRepository;

	private final BGEM3EmbeddingService bgeEmbeddingService;


	@Value("${vector.db.name}")
	private String dbName;

	public boolean train(TrainDocumentRequest trainDocumentRequest) {

		AiEngineTrainingStatus aiEngineTrainingStatus = new AiEngineTrainingStatus();
		aiEngineTrainingStatus.setDocumentId(trainDocumentRequest.getDocumentId());
		aiEngineTrainingStatus.setEngineType(openAIConfigProperties.getEngineType());
		aiEngineTrainingStatus.setModelName(openAIConfigProperties.getModelName());
		aiEngineTrainingStatus.setStatus("In-Progress");
		aiEngineTrainingStatus = trainingStatusRepository.save(aiEngineTrainingStatus);

		int totalEmbeddingTokens = 0;

		try {
			Map<Integer, com.smartdocs.gpt.document.model.Document> documents = documentService
					.processDocument(trainDocumentRequest);

			Map<String, String> chunckMap = new HashMap<>();

			for (Map.Entry<Integer, com.smartdocs.gpt.document.model.Document> itr : documents.entrySet()) {

				int page = itr.getKey();
				com.smartdocs.gpt.document.model.Document document = itr.getValue();

				List<TextSegment> segments = documentService.split(document);

				for (TextSegment textSegment : segments) {

					EmbeddingData embedding = openAIService.createEmbeddingInDouble(textSegment.text());
					var vectorDocument = new VectorDocuments();
					vectorDocument.setBotId(trainDocumentRequest.getBotId());
					vectorDocument.setDocumentContent(textSegment.text());
					vectorDocument.setEmbeddings(embedding.getEmbedding());
					vectorDocument.setPage(page);
					vectorDocument.setSiteId(trainDocumentRequest.getSiteId());
					vectorDocument.setDocumentId(trainDocumentRequest.getDocumentId());
					vectorDocument.setDocumentName(trainDocumentRequest.getFileName());
					vectorDocument = vectorDocumentsRepository.save(vectorDocument);
					chunckMap.put(vectorDocument.getId(), textSegment.text());
					totalEmbeddingTokens = totalEmbeddingTokens + embedding.getTokens();
				}

			}
//			List<AiEngineFileDetails> fileDetailList = new ArrayList<>();
//
//			for (Map.Entry<String, String> itr : chunckMap.entrySet()) {
//				AiEngineFileDetails aiEngineFileDetails = new AiEngineFileDetails(trainDocumentRequest.getSiteId(),
//						trainDocumentRequest.getDocumentCategory(), trainDocumentRequest.getDocumentId(),
//						itr.getValue(), itr.getKey() , openAIConfigProperties.getEngineType());
//				fileDetailList.add(aiEngineFileDetails);
//			}
//
//			aiEngineFileDetailsRepository.saveAll(fileDetailList);
			aiEngineTrainingStatus.setEmbeddingTokens(totalEmbeddingTokens);
			aiEngineTrainingStatus.setStatus("Completed");

		} catch (Exception e) {

			aiEngineTrainingStatus.setErrorMessage(e.getMessage());
			log.info("Some Error occurred while training");
			aiEngineTrainingStatus.setStatus("Some error occurred");
			e.printStackTrace();
		}

		trainingStatusRepository.save(aiEngineTrainingStatus);

		return true;
	}

	public void trainOnUrl(List<String> urls, String siteId) {
		vectorDocumentsRepository.deleteBySiteIdAndSourceType(siteId, VectorDocuments.TRAIN_TYPE_URLS);
		for (String url : urls) {
			AiEngineTrainingStatus aiEngineTrainingStatus = new AiEngineTrainingStatus();
			aiEngineTrainingStatus.setDocumentId(url);
			aiEngineTrainingStatus.setStatus("In-Progress");
			aiEngineTrainingStatus = trainingStatusRepository.save(aiEngineTrainingStatus);
			try {
				UrlObject urlObject = urlObjectRepository.findById(url).get();
				VectorDocuments vectorDocuments = new VectorDocuments();
				vectorDocuments.setDocumentContent(urlObject.getContent());
				vectorDocuments.setDocumentId(url);
				vectorDocuments.setDocumentName(url);
				EmbeddingData embedding = openAIService.createEmbeddingInDouble(urlObject.getContent());
				vectorDocuments.setEmbeddings(embedding.getEmbedding());
				vectorDocuments.setSiteId(siteId);
				vectorDocuments.setPage(0);
				vectorDocuments.setSourceType(VectorDocuments.TRAIN_TYPE_URLS);
				vectorDocumentsRepository.save(vectorDocuments);
				aiEngineTrainingStatus.setEmbeddingTokens(embedding.getTokens());
				aiEngineTrainingStatus.setStatus("Completed");
				trainingStatusRepository.save(aiEngineTrainingStatus);
			} catch (Exception e) {
				aiEngineTrainingStatus.setStatus("some error occured" + e.getMessage());
				trainingStatusRepository.save(aiEngineTrainingStatus);
			}
		}

	}

	public Optional<String> getFileExtension(String filename) {
		return Optional.ofNullable(filename).filter(f -> f.contains("."))
				.map(f -> f.substring(filename.lastIndexOf(".") + 1));
	}

	public void deleteDocument(String documentId) {
//		aiEngineFileDetailsRepository.deleteByDocumentId(documentId);
		vectorDocumentsRepository.deleteByDocumentId(documentId);

	}

	public GPTChatResponse chat(GPTChatRequest chatRequest) throws IOException, InterruptedException {

		String apiKey = openAIConfigProperties.getApiKey();
		if(apiKey == null){
			GPTChatResponse errorResponse = new GPTChatResponse();
			errorResponse.setResponse("Sorry, I am unable to get proper configuration of Gpt");
			return errorResponse;
		}
		
		BGEEmbeddingData queryEmbeddings = bgeEmbeddingService.createEmbedding(chatRequest.getMessage());
		System.out.println(TenantContext.getTenantId());

		MongoDatabase database = mongoClient.getDatabase(dbName);

		MongoCollection<Document> collection = database.getCollection("BgeVectorDocuments");
		int numCandidates = 50;
		int limit = 7;

		double similarityThreshold = 0.00;

		List<String> matchingSiteIds = mongoClient.getDatabase(dbName)
				.getCollection("BgeVectorDocuments")
				.distinct("siteId",
						Filters.regex("siteId", "^" + Pattern.quote(chatRequest.getSiteId())),
						String.class)
				.into(new ArrayList<>());

		System.out.println("Matching siteIds for BGE vector search: " + matchingSiteIds);

		if (matchingSiteIds.isEmpty()) {
			GPTChatResponse errorResponse = new GPTChatResponse();
			errorResponse.setResponse("No matching documents found for siteId prefix: " + chatRequest.getSiteId());
			return errorResponse;
		}

		Document filter = new Document("siteId", new Document("$in", matchingSiteIds));

		List<Bson> aggregationPipeline = Arrays.asList(
				new Document("$vectorSearch",
						new Document()
								// CHANGE 4: Use BGE vector index name
								.append("index", "bge_vector_index")
								.append("path", "embeddings")
								.append("filter", filter)
								// CHANGE 5: Use BGE embedding vector
								.append("queryVector", queryEmbeddings.getEmbedding())
								.append("numCandidates", numCandidates)
								.append("limit", limit * 2) // Get more candidates for filtering
				),
				new Document("$addFields",
						new Document("similarityScore", new Document("$meta", "vectorSearchScore"))
				),
				new Document("$match",
						new Document("similarityScore", new Document("$gte", similarityThreshold))
				),
				new Document("$sort",
						new Document("similarityScore", -1)
				),
				new Document("$limit", limit)
		);

		AggregateIterable<Document> result = collection.aggregate(aggregationPipeline);
		List<VectorDocuments> documents = new ArrayList<>();
		for (var doc : result) {
			JSONObject jsonObject = JSONObject.parseObject(doc.toJson());
			VectorDocuments vectorDocuments = new VectorDocuments();
			vectorDocuments.setDocumentId(jsonObject.getString("documentId"));
			vectorDocuments.setDocumentContent(jsonObject.getString("documentContent"));
			vectorDocuments.setPage(jsonObject.getInteger("page"));
			vectorDocuments.setDocumentName(jsonObject.getString("documentName"));

			String oId = jsonObject.getString("_id");
			var id = new org.json.JSONObject(oId).getString("$oid");

			vectorDocuments.setId(id);
			documents.add(vectorDocuments);
			double similarity = jsonObject.getDoubleValue("similarityScore");
			// System.out.println("BGE Similarity score for: " + vectorDocuments.getDocumentName() + " : " + similarity);
		}

		List<SourceObject> sourceobjects = commonService.getSourceListFromDocument(documents);

		List<String> sourceStrings = new ArrayList<>();
		for (SourceObject sourceObject : sourceobjects) {
			sourceStrings.add(sourceObject.getSource());
		}
		GPTChatResponse chatResponse = new GPTChatResponse();
		chatResponse.setSources(sourceobjects);

		String userLangCode = chatRequest.getUserLanguage() != null ? chatRequest.getUserLanguage() : "en";
		String fullLanguage = LanguageUtils.getEnglishLanguageName(userLangCode);

		String persona = chatRequest.getPersona() != null ? chatRequest.getPersona() : "helpful assistant";

		String finalPrompt = String.format("""
				────────────────────────────────────────
				ROLE
				────────────────────────────────────────
				
				You are SpotlineGPT, an intelligent multilingual assistant developed by Spotline Inc.
				You are not OpenAI. Your purpose is to help users by answering questions only using the internal knowledge base you were trained on.
				You only answer using the supplied knowledge base context—never the internet or general training data.
				
				
				 ────────────────────────────────────────
				CRITICAL LANGUAGE PROTOCOL
				────────────────────────────────────────
				• The user’s query language is [FULL_LANGUAGE_NAME] (ISO code [USER_LANGUAGE_CODE]). \\s
				• Produce your entire answer strictly in [FULL_LANGUAGE_NAME]. \\s
				• Never switch languages or mention detection/translation. \\s
				• Internally verify that every token of your reply is in [FULL_LANGUAGE_NAME]. \\s
				
				────────────────────────────────────────
				CRITICALLY STRICT SOURCE ATTRIBUTION PROTOCOL
				────────────────────────────────────────
				• Only include sources that explicitly support the answer.
				• Never guess or add information not in the provided context.
				• Each factual statement must be traceable to at least one listed source document.
				• List each document ID only once at the end.
				
				────────────────────────────────────────
				ANSWER GENERATION ALGORITHM
				────────────────────────────────────────
				1. Search the provided **SOURCE DOCUMENT CONTEXT** section for passages that directly answer the question: [USER_QUESTION].
				However, if the user’s query is broad or general (e.g., “clarify targets,” “summarize initiatives”), then reinterpret it as a request to restate the available evidence from the context in a clear, user-friendly way. Always include information supported by sources.
				2. If the question is a follow , then search the **PAST CONVERSATION HISTORY CONTEXT** section for potentially relevant and accurate information.
				3. If still no relevant evidence is found in either context, provide a fallback message:
				`I'm sorry, but I don't have enough information to answer that`
				
				4. **EXTRACT & REPHRASE**\s
				• If evidence is found, generate response based on the stated data in the sources.\s
				• Rephrase into a clean, coherent, user‑friendly answer.\s
				• Always respond in valid GitHub-flavored Markdown.
				• Do not include decorative characters like ─────── lines.
				• Use only standard Markdown features (headings, lists, tables, links, code blocks).
				• Only format text as clickable links if the **complete, valid email address or full URL is explicitly written in the context** (e.g., https://example.com, john@company.com).
				• Use short, descriptive text for clickable links instead of the full URL.
				• Format as Markdown: [descriptive_text](actual_url)
					Examples:\s
					- "mary.smith@forvia.com" → [Mary Smith](mailto:mary.smith@forvia.com)
				• **Never fabricate, guess, or infer missing URLs.** If only a display name or reference is given without the actual link, leave it as plain text.
				• Never add links from outside the context provided to you.
			
				5. **TRACK SOURCES (NO INLINE CITATIONS)**
				• Track the Document IDs of all sources actually used. 
				• Do not place citations inside the text. 
				
				6. **MANDATORY ENDING** s
				• Append **at the very end** of the response (after all text) in this exact format: 
				`Source Documents: [list all document IDs actually used]` 
				• If no sources were used, write: "Source Documents: []"
				• LIST FORMAT: Present document IDs as comma-separated values in square brackets
				• EXAMPLE: "Source Documents: [DOC123ABC, DOC456DEF, DOC789GHI]
				
				────────────────────────────────────────
				RESPONSE VERIFICATION CHECKLIST
				────────────────────────────────────────
				Before finalizing your answer, confirm:
				1. ✓ The information is stated in the provided context.
				2. ✓ Each fact can be matched to a specific source document ID.
				3. ✓ No information is from external knowledge or inference.
				4. ✓ Source list at end is non-empty if an answer is provided.
				5. ✓ No inline citations present.
				
				────────────────────────────────────────
				HALLUCINATION PREVENTION RULES
				────────────────────────────────────────
				• Do NOT guess, infer, or generalize beyond the context.
				• If the user asks a broad or vague question, you may reinterpret it narrowly in terms of what is explicitly stated in the context (never beyond it).
				• Only answer using the provided Source Document Context; if the user asks anything beyond it (including general knowledge), refuse to answer.
				• Do NOT add external examples or data.
				• Do NOT change provided facts or numbers.
				• Fallback IMMEDIATELY if evidence is missing.
				
				────────────────────────────────────────
				SOURCE DOCUMENT CONTEXT FOLLOWS
				────────────────────────────────────────
            """);

//
//		String promptString = String.format("""
//
//				""");
//		String userPrompt = StringUtils.hasText(chatRequest.getSystemContent()) ? chatRequest.getSystemContent() : promptString;
//
//		userPrompt = userPrompt + """
//
//				""";
//		String finalPrompt = defaultPrompt + userPrompt;		
        String userMessage = chatRequest.getMessage();
		finalPrompt = StringUtils.hasText(chatRequest.getSystemContent()) ? chatRequest.getSystemContent() : finalPrompt;
		finalPrompt = finalPrompt.replace("[PERSONA]", persona).replace("[FULL_LANGUAGE_NAME]", fullLanguage).replace("[USER_LANGUAGE_CODE]", userLangCode).replace("[USER_QUESTION]", chatRequest.getMessage());

		List<Message> messages = new ArrayList<>();

		messages.add(new Message("system", finalPrompt));
		StringBuilder sourcesContext = new StringBuilder();
		sourcesContext.append("Available Knowledge Base Sources:\n\n");

		for (int i = 0; i < sourceobjects.size(); i++) {
			sourcesContext.append("=== Source ").append(i + 1).append(" ===\n");
			sourcesContext.append("Document Name: ").append(documents.get(i).getDocumentName()).append("\n");
			sourcesContext.append("Document ID: ").append(documents.get(i).getDocumentId()).append("\n");
			sourcesContext.append("Page: ").append(documents.get(i).getPage()).append("\n");
			sourcesContext.append("Content: ").append(sourceobjects.get(i).getSource()).append("\n\n");
		}

		messages.add(new Message("system", sourcesContext.toString()));

		messages.add(new Message("system", """
            ### PAST CONVERSATION HISTORY CONTEXT FOLLOWS ###
            """));
		for (int a = 0; a < chatRequest.getPreviousMessages().size(); a++) {
			String userMsg = chatRequest.getPreviousMessages().get(a).getUserMessage();
			String botMsg = chatRequest.getPreviousMessages().get(a).getBotMessage();
			if (userMsg == null) {
				continue;
			}
			messages.add(new Message("user", userMsg));
			if (botMsg != null) {
				messages.add(new Message("assistant", botMsg));
			}
		}
		messages.add(new Message("user", "User's Question: " + userMessage));

		ChatResponse chatResponsee = openAIService.createChatCompletion(messages, chatRequest.getOutputLength(),
				chatRequest.getTemperature());
		String openAiResponse = chatResponsee.getChoices().get(0).getMessage().getContent();

		String html = markDownToHtml(openAiResponse);

		List<String> usedIds = extractIdsFromHtml(html);
		Map<String, SourceObject> idToSource = new HashMap<>();
		for (SourceObject src : sourceobjects) {
			idToSource.put(src.getDocumentId(), src);
		}

		List<SourceObject> relevantSources = new ArrayList<>();
		Set<String> addedIds = new HashSet<>();

		for (String id : usedIds) {
			SourceObject found = idToSource.get(id);
			if (found != null && !addedIds.contains(found.getDocumentId())) {
				relevantSources.add(found);
				addedIds.add(found.getDocumentId());
			}
		}

		chatResponse.setSources(relevantSources);
		chatResponse.setAnswered(!relevantSources.isEmpty());
		String cleanedHtml = html.replaceAll("(?s)<p>Source Documents:.*?</p>\\s*", "");

		chatResponse.setResponse(cleanedHtml);
		chatResponse.setPromptTokens(chatResponsee.getUsage().getPromptTokens());
		chatResponse.setCompletionTokens(chatResponsee.getUsage().getCompletionTokens());
		chatResponse.setTotalTokens(chatResponsee.getUsage().getTotalTokens());

		chatResponse.setEmbeddingTokens(queryEmbeddings.getTokens());

		return chatResponse;
	}

	public Map<String, Object> generateSuggestedQuestions(String answer, String headerLine, int maxTokens, double temperature, String suggestedQuestionsPrompt, String userLanguage, List<PreviousMessages> previousMessages, List<SourceObject> sources) throws IOException, InterruptedException {

		String openApiKey = openAIConfigProperties.getApiKey();
		if (openApiKey == null || openApiKey.isBlank()) {
			return Map.of("response",
					List.of("Sorry, I am unable to get proper configuration of GPT."));
		}
		if (answer == null || answer.trim().isEmpty()) {
			return Collections.emptyMap();
		}

		String userLangCode = (userLanguage == null || userLanguage.isBlank()) ? "en" : userLanguage;
		String fullLanguage  = LanguageUtils.getEnglishLanguageName(userLangCode);

		String promptToUse;
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode  inputJson = mapper.createObjectNode();

		inputJson.put("text",       answer.trim());
		inputJson.put("headerLine", headerLine.trim());

		boolean isPastConvo = false;
		if (sources != null && !sources.isEmpty()) {
			if (suggestedQuestionsPrompt != null && !suggestedQuestionsPrompt.isBlank()) {
				promptToUse = suggestedQuestionsPrompt + "\n\n**CONTEXT FOLLOWS**:\n";
			} else {
				String defaultContextPrompt = """
				Role:
				You are SpotlineGPT, an intelligent multilingual Follow-Up Question Assistant developed by Spotline Inc.
				
				Task:
				Given a headerLine, text, and sources in JSON format, translate the headerLine and generate 2-3 follow-up questions in [FULL_LANGUAGE_NAME] that are STRICTLY answerable from the provided sources.
				
				Input Format:
				{
				  "text": "LLM response for follow-up generation",
				  "headerLine": "text to be translated",\s
				  "sources": ["source snippet 1", "source snippet 2", ...]
				}
				
				CRITICAL REQUIREMENTS:
				1. **Source Validation**: Before generating any question, verify that its answer exists explicitly in the sources
				2. **No Hallucination**: Generate questions ONLY about information present in the sources
				3. **Retrievability**: Each question must be answerable by retrieving and citing the provided sources
				4. **Language Consistency**: Translate headerLine and generate all questions in [FULL_LANGUAGE_NAME]
				
				Question Generation Process:
				1. **Extract Key Facts**: Identify 5-7 specific facts/details mentioned in the sources
				2. **Create Candidate Questions**: For each fact, formulate a potential question
				3. **Source Verification**: For each candidate question, verify the answer exists in sources
				4. **Final Selection**: Choose 2-3 questions with the strongest source support
				
				Answer Generation Rules:
				- Questions must be concise (<10 words)
				- Focus on specific details, numbers, processes, or requirements mentioned in sources
				- Avoid broad or conceptual questions that require inference beyond sources
				- Prioritize questions about actionable information (how-to, requirements, specific features)
				- If fewer than 2 verifiable questions can be generated, return empty suggestedQuestions array
				
				Quality Checks:
				- Can I find the exact answer in the sources? (Yes/No)
				- Does the question require information not in sources? (Must be No)
				- Would a user get a complete answer from these sources alone? (Must be Yes)
				
				Output Format:
				{
				  "suggestedQuestions": ["question1", "question2", "question3"],
				  "translatedHeader": "translated headerLine text"
				}
				
				**CONTEXT FOLLOWS**:
                %s
    		""";
				promptToUse = defaultContextPrompt;
			}

			ArrayNode sourceArray = mapper.createArrayNode();
			int counter = 1;
			for (SourceObject so : sources) {
				sourceArray.add("Source " + counter + ": " + so.getSource());
				counter++;
			}
			inputJson.set("sources", sourceArray);

		} else {

			isPastConvo = true;
			promptToUse = """
					Role:
						You are SpotlineGPT, an intelligent multilingual Follow-Up Question Assistant developed by Spotline Inc.
					
					Task:
					Using ONLY the conversation history below, generate 2-3 suggested questions by reframing questions that the assistant successfully answered and translate headerLine in [FULL_LANGUAGE_NAME] language.
					
					CRITICAL LANGUAGE PROTOCOL:
					• The target language is [FULL_LANGUAGE_NAME] (ISO code [USER_LANGUAGE_CODE])
					• Produce your ENTIRE response strictly in [FULL_LANGUAGE_NAME]
					• Translate both suggestedQuestions and translatedHeader to [FULL_LANGUAGE_NAME]
					• Never switch languages or mention detection/translation
					
					TASK:
					1. Identify user questions that received complete answers from the assistant
					2. Reframe these questions using different wording while keeping the same meaning
					3. Focus on questions where the assistant provided detailed, factual responses
					4. Translate all output to [FULL_LANGUAGE_NAME], including:
					  • suggestedQuestions array
					  • translatedHeader (from [HEADER_LINE])
					  • createTicketText (translate "Create Ticket")
					  • helpfulResourcesText (translate "Helpful Resources")
					
					CRITICAL REQUIREMENTS:
					• Only reframe questions that the assistant actually answered (not unanswered or partial responses)
					• Use different wording but maintain the same intent/topic
					• Questions should NOT be follow-ups - they should be alternative ways to ask the same thing
					• If fewer than 2 reframable questions exist, return empty suggestedQuestions array
					• ALL output must be in [FULL_LANGUAGE_NAME]
					
					Reframing Guidelines:
					• Original: "What data does Ecosphere provide?" → Reframed: "What information is available from Ecosphere?"
					• Original: "How are transport emissions calculated?" → Reframed: "What method is used for transport emission calculations?"
					• Original: "What are the main themes?" → Reframed: "Which key areas are covered?"
					
					Quality Checks:
					- Was this question answered by the assistant? (Must be Yes)
					- Is the reframed question asking for the same information? (Must be Yes) \s
					- Is it worded differently from the original? (Must be Yes)
					- Is the entire output in [FULL_LANGUAGE_NAME]? (Must be Yes)
					- Are createTicketText and helpfulResourcesText properly translated? (Must be Yes)
					
					Output Format (ALL in [FULL_LANGUAGE_NAME]):
					{
					  "suggestedQuestions": ["reframed_question1", "reframed_question2", "reframed_question3"],
					  "translatedHeader": "[HEADER_LINE]",
					  "createTicketText": "Create Ticket translated to [FULL_LANGUAGE_NAME]",
					  "helpfulResourcesText": "Helpful Resources translated to [FULL_LANGUAGE_NAME]"
					}
					
					***Past Conversation***:
			
                """;

		}

		promptToUse = promptToUse
				.replace("[HEADER_LINE]",        headerLine)
				.replace("[FULL_LANGUAGE_NAME]", fullLanguage)
				.replace("[USER_LANGUAGE_CODE]", userLangCode)
				.replace("[USER_RESPONSE]",      answer);

		List<Message> messages = new ArrayList<>();
		String systemContent  = promptToUse + "\n\nInput:\n" + inputJson.toPrettyString();
		messages.add(new Message("system", systemContent));

		if(isPastConvo) {
			if (previousMessages != null && !previousMessages.isEmpty()) {
				for (PreviousMessages pm : previousMessages) {
					if (pm.getUserMessage() != null && !pm.getUserMessage().isBlank()) {
						messages.add(new Message("user", pm.getUserMessage()));
					}
					if (pm.getBotMessage() != null && !pm.getBotMessage().isBlank()) {
						messages.add(new Message("assistant", pm.getBotMessage()));
					}
				}
			}
		}

		ChatResponse resp = openAIService.createChatCompletion(messages, maxTokens, temperature);

		String raw = resp.getChoices().get(0).getMessage().getContent();
		JsonNode root = mapper.readTree(raw);

		List<String> suggestedQs = root.has("suggestedQuestions")
				? mapper.convertValue(root.get("suggestedQuestions"), List.class)
				: List.of("Sorry, I could not generate follow-up questions.");

		String translatedHeader = root.has("translatedHeader")
				? root.get("translatedHeader").asText()
				: headerLine;

		if(isPastConvo) {
			String resources = root.has("helpfulResourcesText") ? root.get("helpfulResourcesText").asText() : "helpful resources";
			String ticket = root.has("createTicketText") ? root.get("createTicketText").asText() : "create ticket";
			suggestedQs.add(resources);
			suggestedQs.add(ticket);
		}

		Map<String, Object> result = new HashMap<>();
		result.put("response",           suggestedQs);
		result.put("translatedHeader",   translatedHeader);
		result.put("promptTokens",       resp.getUsage().getPromptTokens());
		result.put("completionTokens",   resp.getUsage().getCompletionTokens());
		result.put("totalTokens",        resp.getUsage().getTotalTokens());

		return result;
	}

	public void deleteBot(String botId) {

		vectorDocumentsRepository.deleteBySiteId(botId);

	}

	private String markDownToHtml(String text) {
		Parser parser = Parser.builder().extensions(Arrays.asList(TablesExtension.create())).build();
		Node document = parser.parse(text);
		HtmlRenderer renderer = HtmlRenderer.builder().extensions(Arrays.asList(TablesExtension.create())).build();
		return renderer.render(document);
	}

	private List<String> extractIdsFromHtml(String html) {
		// Regex finds “Source Documents:” line and captures the bracketed list
		Pattern p = Pattern.compile("Source Documents:\\s*\\[([^\\]]*)\\]");
		Matcher m = p.matcher(html);
		if (!m.find()) return Collections.emptyList();
		String listContent = m.group(1).trim();
		if (listContent.isEmpty()) return Collections.emptyList();
		// Split on commas, trim whitespace
		return Arrays.stream(listContent.split(","))
				.map(String::trim)
				.collect(Collectors.toList());
	}

	private void makeQnaString(List<QnA> qnaList, StringBuilder st) {
		for (QnA q : qnaList) {
			st.append("question:" + q.getQuestion() + "\n");
			st.append("answer:" + q.getAnswer() + "\n\n");
		}

	}

	private ResponseJson convertToObject(String jsonString) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.readValue(jsonString, ResponseJson.class);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	private String openAIJsonReponse(String query, String sources, int outputlength, double temperature) {
		List<Message> messages = new ArrayList<>();
		messages.add(new Message("system",
				"You are smartdocsGPT and act like that only, your job is to try to answer users query based on the context provided"));
		messages.add(new Message("system",
				"using the context provided only you have to answer user's query based on that only, do not go beyond that knowledge"));
		messages.add(new Message("system",
				"You need to respond in proper json format always keeping the key value pairs are response:value will be string , confidenceScore: value will be a number"));
		messages.add(new Message("system",
				"response should be the actual response for which user has asked for along with that you need to provide a confidence score between 0 to 100 that how much confident you are that your response should resolve users query where 0 is lower and 100 is higher "));
		messages.add(new Message("system",
				"In situations you are not able to answer questions from the provided content give lower confidence score, and never say that terms like based on provided context , if you dont know to the answer just say I dont know about this topic , is there any thing with which I can help you? something like that and say that humbly"));
		messages.add(new Message("system", "here are the question and answers " + sources));
		messages.add(new Message("system", "here is the user's query : " + query));
		ChatResponse chatResponse = openAIService.createChatCompletion(messages, outputlength, temperature);
		System.out.println(chatResponse.getChoices().get(0).getMessage().getContent());
		String jsonResponse = chatResponse.getChoices().get(0).getMessage().getContent();
		return jsonResponse;
	}

	@Async
	public void trainBotDocuments(TrainDocumentRequest trainDocumentRequest) {
		vectorDocumentsRepository.deleteBySiteIdAndSourceType(trainDocumentRequest.getSiteId() , VectorDocuments.TRAIN_TYPE_DOCUMENT);
		log.info("train bot documents");
		StringBuilder responseBuilder = new StringBuilder();
		for (var entry : trainDocumentRequest.getDocIdFileNameMap().entrySet()) {
			trainDocumentRequest.setResourceId(entry.getKey());
			trainDocumentRequest.setFileName(entry.getValue());
			trainDocumentRequest.setSiteId(trainDocumentRequest.getSiteId());

			String success = trainBot(trainDocumentRequest);
			responseBuilder.append(success).append("\n");
		}
		log.info(responseBuilder.toString());
	}

	public String trainBot(TrainDocumentRequest trainDocumentRequest) {
		String response = "";
		AiEngineTrainingStatus aiEngineTrainingStatus = new AiEngineTrainingStatus();
		aiEngineTrainingStatus.setDocumentId(trainDocumentRequest.getResourceId());
		aiEngineTrainingStatus.setBotId(trainDocumentRequest.getSiteId());
		aiEngineTrainingStatus.setFileName(trainDocumentRequest.getFileName());

		aiEngineTrainingStatus.setEngineType(openAIConfigProperties.getEngineType());
		aiEngineTrainingStatus.setModelName(openAIConfigProperties.getModelName());
		aiEngineTrainingStatus.setEmbeddingModel(openAIConfigProperties.getEmbeddingModel());

		aiEngineTrainingStatus.setStatus("In-Progress");
		aiEngineTrainingStatus = trainingStatusRepository.save(aiEngineTrainingStatus);

		int totalEmbeddingTokens=0;

		try {
			Map<Integer, com.smartdocs.gpt.document.model.Document> documents = documentService
					.processDocument(trainDocumentRequest);

			Map<String, String> chunckMap = new HashMap<>();

			for (Map.Entry<Integer, com.smartdocs.gpt.document.model.Document> itr : documents.entrySet()) {

				int page = itr.getKey();
				com.smartdocs.gpt.document.model.Document document = itr.getValue();

				List<TextSegment> segments = documentService.split(document);

				for (TextSegment textSegment : segments) {

//					EmbeddingData embedding = openAIService.createEmbeddingInDouble(textSegment.text());
					BGEEmbeddingData embedding = bgeEmbeddingService.createEmbedding(textSegment.text());
					var vectorDocument = new VectorDocuments();
					vectorDocument.setDocumentContent(textSegment.text());
					vectorDocument.setEmbeddings(embedding.getEmbedding());
					vectorDocument.setPage(page);
					vectorDocument.setSiteId(trainDocumentRequest.getSiteId());
					vectorDocument.setBotId(trainDocumentRequest.getBotId());
					vectorDocument.setDocumentId(trainDocumentRequest.getResourceId());
					vectorDocument.setDocumentName(trainDocumentRequest.getFileName());
					vectorDocument.setSourceType(VectorDocuments.TRAIN_TYPE_DOCUMENT);
					vectorDocument = vectorDocumentsRepository.save(vectorDocument);
					chunckMap.put(vectorDocument.getId(), textSegment.text());
					totalEmbeddingTokens = totalEmbeddingTokens + embedding.getTokens();
				}

			}
//			List<AiEngineFileDetails> fileDetailList = new ArrayList<>();
//
//			for (Map.Entry<String, String> itr : chunckMap.entrySet()) {
//				AiEngineFileDetails aiEngineFileDetails = new AiEngineFileDetails();
//				aiEngineFileDetails.setSiteId(trainDocumentRequest.getSiteId());
//				aiEngineFileDetails.setDocumentType(trainDocumentRequest.getDocumentCategory());
//				aiEngineFileDetails.setDocumentId(trainDocumentRequest.getDocumentId());
//				aiEngineFileDetails.setSource(trainDocumentRequest.getContent());
//				aiEngineFileDetails.setDbId(itr.getKey());
//				aiEngineFileDetails.setEngineType(AiEngineFileDetails.ENGINE_TYPE_AZURE);
//				fileDetailList.add(aiEngineFileDetails);
//			}
			aiEngineTrainingStatus.setEmbeddingTokens(totalEmbeddingTokens);
//			aiEngineFileDetailsRepository.saveAll(fileDetailList);
			aiEngineTrainingStatus.setStatus("Completed");
			response = " Training Completed for file : " + trainDocumentRequest.getFileName();

		} catch (Exception e) {
			response = " Some error occurred in file : " + trainDocumentRequest.getFileName();
			aiEngineTrainingStatus.setErrorMessage(e.getMessage());
			log.info("Some Error occurred while training");
			aiEngineTrainingStatus.setStatus("Some error occurred");
			e.printStackTrace();
		}

		trainingStatusRepository.save(aiEngineTrainingStatus);
		return response;

	}

	public PhraseResponse generateUtterance(List<String> utterance, int numberOfUtterance)
			throws JsonProcessingException {
		List<Message> messages = new ArrayList<>();
		messages.add(new Message("system", "Act as paraphrase bot"));
		messages.add(new Message("system", "a phrase/question/sentence or there list  will be given to you by user"));
		messages.add(new Message("system",
				"your task is to generate different paraphrase of the same or based on the pattern generate paraphrases, always respond back in json format"));
		messages.add(new Message("system",
				"json response should be json array of string with key paraphrases, that is paraphrases"));
		messages.add(new Message("system", "you have to generate " + numberOfUtterance + "utterances"));
		messages.add(new Message("user", utterance.toString()));

		ChatResponse chatResponse = openAIService.createChatCompletionJson(messages, 4000, 0.1);
		String jsonResponse = chatResponse.getChoices().get(0).getMessage().getContent();
		ObjectMapper objectMapper = new ObjectMapper();

		PhraseResponse finalResponse = objectMapper.readValue(jsonResponse, PhraseResponse.class);
		finalResponse.setPromptTokens(chatResponse.getUsage().getPromptTokens());
		finalResponse.setCompletionTokens(chatResponse.getUsage().getCompletionTokens());
		finalResponse.setTotalTokens(chatResponse.getUsage().getTotalTokens());
		return finalResponse;

	}

	public void deleteURL(String url) {
		vectorDocumentsRepository.deleteByDocumentId(url);

	}

	public void deleteFile(String siteId, String documentId) {
		vectorDocumentsRepository.deleteBySiteIdAndDocumentId(siteId, documentId);
	}

	public void migrateTaxanomy() {
		List<TaxanomyDetails> taxanomies = taxanomyDetailsRepository.findAll();
		for (TaxanomyDetails taxanomy : taxanomies) {
			StringBuilder sb = new StringBuilder();
			sb.append("Commodity: " + taxanomy.getCommodity());
			sb.append("SubCommodity: " + taxanomy.getSubCommodity());
			sb.append("shortDescription: " + taxanomy.getShortDescription());
			sb.append("detailedDescription: " + taxanomy.getDetailedDescription());
			EmbeddingData embedding = openAIService.createEmbeddingInDouble(sb.toString());
			var vectorDocument = new VectorDocuments();
			vectorDocument.setDocumentContent(taxanomy.toString());
			vectorDocument.setEmbeddings(embedding.getEmbedding());
			vectorDocument.setPage(0);
			vectorDocument.setSiteId("taxanomyDetails");
			vectorDocument.setDocumentId(taxanomy.getId());
			vectorDocument.setDocumentName("");
			vectorDocument = vectorDocumentsRepository.save(vectorDocument);

		}
		log.info("Migration completed");
	}

	public String chatForviaBot(GPTChatRequest chatRequest, String languageCode) throws IOException, InterruptedException {

		EmbeddingData queryEmbeddings = openAIService.createEmbeddingInDouble(chatRequest.getMessage());
		System.out.println(TenantContext.getTenantId());

		MongoDatabase database = mongoClient.getDatabase(dbName);
		MongoCollection<Document> collection = database.getCollection("VectorDocuments");
		int numCandidates = 100;
		int limit = 50;

		Document filter = new Document("$and", Arrays.asList(
				new Document("siteId", new Document("$in", Collections.singletonList(chatRequest.getSiteId())))));

		Bson vectorSearchStage = new Document("$vectorSearch",
				new Document().append("index", "vector_index").append("path", "embeddings").append("filter", filter) // filter
						.append("queryVector", queryEmbeddings.getEmbedding()).append("numCandidates", numCandidates)
						.append("limit", limit));

		List<Bson> aggregationPipeline = Collections.singletonList(vectorSearchStage);

		AggregateIterable<Document> result = collection.aggregate(aggregationPipeline);
		List<VectorDocuments> documents = new ArrayList<>();
		for (var doc : result) {
			JSONObject jsonObject = JSONObject.parseObject(doc.toJson());

			VectorDocuments vectorDocuments = new VectorDocuments();
			vectorDocuments.setDocumentId(jsonObject.getString("documentId"));
			vectorDocuments.setDocumentContent(jsonObject.getString("documentContent"));
			vectorDocuments.setPage(jsonObject.getInteger("page"));
			vectorDocuments.setDocumentName(jsonObject.getString("documentName"));

			String oId = jsonObject.getString("_id");
			var id = new org.json.JSONObject(oId).getString("$oid");

			vectorDocuments.setId(id);
			documents.add(vectorDocuments);
		}

		List<SourceObject> sourceobjects = commonService.getSourceListFromDocument(documents);

//		List<String> sourceStrings = new ArrayList<>();
//		for (SourceObject sourceObject : sourceobjects) {
//			sourceStrings.add(sourceObject.getSource());
//			break;
//		}
		GPTChatResponse chatResponse = new GPTChatResponse();
		chatResponse.setSources(sourceobjects);

		String promptString = "You need to act as a smart ariba guide bot, given to you is details of relevant commodity, subcommodity , description of good, etc . considering them You need to get back with the ALways  full 6 digit commodity code for which user is looking for. Always respond back in json format";
		promptString = promptString.replace("[Insert retrieved context here]", sourceobjects.toString());
		String userMessage = chatRequest.getMessage();

		List<Message> messages = new ArrayList<>();

		messages.add(new Message("system", promptString));
		messages.add(new Message("system", "response format should always be like segmentCode: value as string"));
		messages.add(new Message("system", "Always respond back with 6 digit full commodity code "));
		messages.add(new Message("system", "here is all the details of relevant data: " + sourceobjects.toString()));
		messages.add(new Message("user", "User's Question: " + userMessage));

		ChatResponse chatResponsee = openAIService.createChatCompletionJson(messages, chatRequest.getOutputLength(),
				chatRequest.getTemperature());
		String openAiResponse = chatResponsee.getChoices().get(0).getMessage().getContent();
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.readTree(openAiResponse);
		if (jsonNode.has("segmentCode")) {
			openAiResponse = jsonNode.get("segmentCode").asText();
		} else {
			openAiResponse = "";
		}
		Optional<TaxanomyDetails> taxanomyDetails = null;
		if (openAiResponse != null)
			taxanomyDetails = taxanomyDetailsRepository.findBySegmentCode(openAiResponse);
		List<VendorData> vendorDatas = new ArrayList<>();
		List<PurchaseOrder> purchaseOrderDatas= new ArrayList<PurchaseOrder>();
		if (taxanomyDetails != null && taxanomyDetails.isPresent()) {
			String categoryCode = openAiResponse;
			openAiResponse = taxanomyDetails.toString();

			// first check for catalog items
			List<CatalogVendorDetails> catalogItems = catalogVendorDetailsRepository.findByMergeMappingNewSegment(categoryCode);
			if(catalogItems.size()!=0) {

				String promptForFinalResponse = """
		        		You need to act as a guiding bot. You have:
		        		1. A user's query.
		        		2. Commodity taxonomy details.
		        		3. A list of vendors (including which one of them are punchout ones which are internal and CIF) show all of them.
		        		4. All buyer in charge as well
		        		5. ALways write with 6 digit full commodity code 
		        		6. First suggested vendor will become mandated vendor automatically. rest all preferred
		        		7. after vendor ID always mention whether the vendor is punchout, internal or CIF. And always write all name of all the vendors 

		        		Use only this url actions with heading Go to Ariba-
		        		a. Take me to Ariba - https://s1.ariba.com/Buyer/Main/ad/loginPage/SSOActions?awsso_cc=cmVhbG06YzNCdmRHeHBibVZrYzJGd2NDMHhMWFE9O2d1aWRlZGJ1eXJlZGlyZWN0OmRISjFaUT09O2F3c3NvX3J1OmFIUjBjSE02THk5ek1TNWhjbWxpWVM1amIyMHZRblY1WlhJdlRXRnBiaTloWkM5a1pXWmhkV3gwTDBScGNtVmpkRUZqZEdsdmJqOW5kV2xrWldSaWRYbHlaV1JwY21WamREMTBjblZsSm5KbFlXeHRQWE53YjNSc2FXNWxaSE5oY0hBdE1TMTA7YXdzc29fbHU6YUhSMGNITTZMeTl6TVM1aGNtbGlZUzVqYjIwdlFuVjVaWEl2VFdGcGJpOWhaQzlqYkdsbGJuUk1iMmR2ZFhRdlUxTlBRV04wYVc5dWN3PT07YXdzc29fYXA6UW5WNVpYST07YXdzc29fYXJpZDpNVGN6T1RNMk5UUXhPVGN6TUE9PTthd3Nzb19rdTphSFIwY0hNNkx5OXpNUzVoY21saVlTNWpiMjB2UW5WNVpYSXZUV0ZwYmk5aFpDOWpiR2xsYm5STFpXVndRV3hwZG1VdlUxTlBRV04wYVc5dWN3PT07YXdzc29fZmw6TVE9PQ%3D%3D%3AVfgl%2FZwDl%2FzxZ6k4%2BNGQ1RRrUuI%3D&awsso_ap=Buyer&realm=spotlinedsapp-1-t&awsr=true
		        		only this url should be always included. no other url button name can be like buying channel 
						
								
		        		Your goal:
		        		• Provide guidance on the commodity code based on the user's query.
		        		• Suggest relevant vendors (especially internal ones first) based on region or relevance.
		        		• Include ERP vendor IDs to help the user identify recommended vendors.
		        		• Present the answer in a formal, helpful tone so it sounds like an AI assistant.
		        		• Use interestig emojis as well as and where required to make it look good
		        		• At the end mention user that for punchout vendors you need to connect the vendor on there website and so on. 
		        		• And for CIF or Internal vendors , go to ariba and provide some guidance. Also mention that you can directly create from here by clicking on below given button for create PR
						• Never use words like happy assessing happy buying, etc. You need to be formal as you are being used by business users
						• after vendor ID always mention whether the vendor is punchout, internal or CIF. And always write all name of all the vendors 
		        		**Important**: You must return your final answer **as valid JSON for an Adaptive Card**.
		        		Do not include any markdown, code fencing, or additional text outside of the JSON.

		        		Below is an example structure you must follow (you can modify the body/actions as needed, but must keep it valid JSON):

		        		{
  "type": "AdaptiveCard",
  "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
  "version": "1.2",
  "body": [
    {
      "type": "TextBlock",
      "text": "Laptop Purchase Guide 💻 (**Catalog Item**)",
      "size": "Large",
      "weight": "Bolder",
      "color": "Accent",
      "wrap": true
    },
    {
      "type": "TextBlock",
      "text": "Hello! Based on your query, below is the recommended commodity code along with top vendor options. Please review the details and follow the instructions provided.",
      "wrap": true
    },
    {
      "type": "TextBlock",
      "text": "Commodity Code: **123456** (Sample Commodity Code)",
      "size": "Medium",
      "weight": "Bolder",
      "separator": true,
      "wrap": true
    },
    {
      "type": "TextBlock",
      "text": "Recommended Vendors",
      "size": "Medium",
      "weight": "Bolder",
      "separator": true,
      "wrap": true
    },
    {
      "type": "FactSet",
      "facts": [
        {
          "title": "🎯 Mandated Vendor",
          "value": "**HP PPS SVERIGE AB** (ERP ID: 211843)(Punchout)"
        },
        {
          "title": "Buyer in Charge",
          "value": "RODRIGUES Jose"
        },
        {
          "title": "💼 Preferred Vendor",
          "value": "**HP INC.** (ERP ID: 211875)(Internal)"
        },
        {
          "title": "Buyer in Charge",
          "value": "Wolf-Christian FEDERHAFF"
        },
        {
          "title": "💼 Preferred Vendor",
          "value": "**DELL TECHNOLOGIES INC.** (ERP ID: 173588)(CIF)"
        },
        {
          "title": "Buyer in Charge",
          "value": "HOMMERS Britta"
        }
      ]
    },
    {
      "type": "TextBlock",
      "text": "Instructions:",
      "size": "Medium",
      "weight": "Bolder",
      "separator": true,
      "wrap": true
    },
    {
      "type": "TextBlock",
      "text": "• To purchase from punchout vendors, start in Ariba and access the supplier’s website. Browse products, add items to the cart, and complete checkout. The selected items will automatically return to Ariba for requisition and PO processing. \n\n• For internal/CIF vendors, go to Ariba, search for the required item, add it to your shopping cart, and proceed with the requisition and PO process.",
      "wrap": true
    }
  ],
  "actions": [
    {
      "type": "Action.OpenUrl",
      "title": "Take me to Ariba",
      "url": "https://s1.ariba.com/Buyer/Main/ad/loginPage/SSOActions?awsso_cc=cmVhbG06YzNCdmRHeHBibVZrYzJGd2NDMHhMWFE9O2d1aWRlZGJ1eXJlZGlyZWN0OmRISjFaUT09O2F3c3NvX3J1OmFIUjBjSE02THk5ek1TNWhjbWxpWVM1amIyMHZRblY1WlhJdlRXRnBiaTloWkM5a1pXWmhkV3gwTDBScGNtVmpkRUZqZEdsdmJqOW5kV2xrWldSaWRYbHlaV1JwY21WamREMTBjblZsSm5KbFlXeHRQWE53YjNSc2FXNWxaSE5oY0hBdE1TMTA7YXdzc29fbHU6YUhSMGNITTZMeTl6TVM1aGNtbGlZUzVqYjIwdlFuVjVaWEl2VFdGcGJpOWhaQzlqYkdsbGJuUk1iMmR2ZFhRdlUxTlBRV04wYVc5dWN3PT07YXdzc29fYXA6UW5WNVpYST07YXdzc29fYXJpZDpNVGN6T1RNMk5UUXhPVGN6TUE9PTthd3Nzb19rdTphSFIwY0hNNkx5OXpNUzVoY21saVlTNWpiMjB2UW5WNVpYSXZUV0ZwYmk5aFpDOWpiR2xsYm5STFpXVndRV3hwZG1VdlUxTlBRV04wYVc5dWN3PT07YXdzc29fZmw6TVE9PQ%3D%3D%3AVfgl%2FZwDl%2FzxZ6k4%2BNGQ1RRrUuI%3D&awsso_ap=Buyer&realm=spotlinedsapp-1-t&awsr=true"
    }
  ]
}


		
		It is not necessary to include heading in every response 
		        		Only output valid JSON. No extra text outside the JSON structure.
		        		""";

				messages.clear();

//messages.add(new Message("system", "Here are past messages (for reference): " + chatHistory.toString()));
				messages.add(new Message("system", promptForFinalResponse));

				messages.add(new Message("system", "Here is the preferred taxonomy details: " + openAiResponse));
				messages.add(new Message("system", "Here are suggested vendor details, Include all of them until and unless user has specified the region or country: " + catalogItems.toString()));
				messages.add(new Message("system","At the top of adaptive card in heading, explicitly mention always that it a catalog item in bold"));
				messages.add(new Message("system", "Always and always respond back in: "+ languageCode));
				messages.add(new Message("system", chatRequest.getMessage()));

				ChatResponse chatResponsee2 = openAIService.createChatCompletionJson(messages, chatRequest.getOutputLength(),
						chatRequest.getTemperature());

				openAiResponse = chatResponsee2.getChoices().get(0).getMessage().getContent();
//
//chatHistory.add("User Message: " + chatRequest.getMessage());
//chatHistory.add("Bot response: " + openAiResponse);


				System.out.println(openAiResponse);

				return openAiResponse;

			}






			vendorDatas = vendorDataRepository.findByCategory(categoryCode);
			if (vendorDatas.size() > 50) {
				vendorDatas = vendorDatas.subList(0, 50);
			}
			purchaseOrderDatas = purchaseOrderRepository.findByCommodityId(categoryCode);
			System.out.println(purchaseOrderDatas.toString());
			if (purchaseOrderDatas.size() > 50) {
				purchaseOrderDatas = purchaseOrderDatas.subList(0, 5);
			}
		}
		String promptForFinalResponse = """
				        		You need to act as a guiding bot. You have:
				        		1. A user's query.
				        		2. Commodity taxonomy details.
				        		3. A list of vendors (including mandated vendors).
				        		4. Past purchaseOrder data
				        		5 ALways write with 6 digit full commodity code 

				        		Use only this url actions with heading Go to Ariba-
				        		a. Take me to Ariba - https://s1.ariba.com/Buyer/Main/ad/loginPage/SSOActions?awsso_cc=cmVhbG06YzNCdmRHeHBibVZrYzJGd2NDMHhMWFE9O2d1aWRlZGJ1eXJlZGlyZWN0OmRISjFaUT09O2F3c3NvX3J1OmFIUjBjSE02THk5ek1TNWhjbWxpWVM1amIyMHZRblY1WlhJdlRXRnBiaTloWkM5a1pXWmhkV3gwTDBScGNtVmpkRUZqZEdsdmJqOW5kV2xrWldSaWRYbHlaV1JwY21WamREMTBjblZsSm5KbFlXeHRQWE53YjNSc2FXNWxaSE5oY0hBdE1TMTA7YXdzc29fbHU6YUhSMGNITTZMeTl6TVM1aGNtbGlZUzVqYjIwdlFuVjVaWEl2VFdGcGJpOWhaQzlqYkdsbGJuUk1iMmR2ZFhRdlUxTlBRV04wYVc5dWN3PT07YXdzc29fYXA6UW5WNVpYST07YXdzc29fYXJpZDpNVGN6T1RNMk5UUXhPVGN6TUE9PTthd3Nzb19rdTphSFIwY0hNNkx5OXpNUzVoY21saVlTNWpiMjB2UW5WNVpYSXZUV0ZwYmk5aFpDOWpiR2xsYm5STFpXVndRV3hwZG1VdlUxTlBRV04wYVc5dWN3PT07YXdzc29fZmw6TVE9PQ%3D%3D%3AVfgl%2FZwDl%2FzxZ6k4%2BNGQ1RRrUuI%3D&awsso_ap=Buyer&realm=spotlinedsapp-1-t&awsr=true
				        		only this url should be always included. no other url button name can be like buying channel 
								
								Take me to Ariba and Create a PR for me button should only come when user has asked question related to any commodity
								
								in create a pr for me button action value should be create_pr if the user is looking for a good and it is some kind of service then it should be create_pr_service			
				        		Your goal:
				        		• Provide guidance on the commodity code based on the user's query.
				        		• Suggest relevant vendors (especially mandated ones first) based on region or relevance.
				        		• Include ERP vendor IDs to help the user identify recommended vendors.
				        		• Present the answer in a formal, helpful tone so it sounds like an AI assistant.
				        		• Use interestig emojis as well as and where required to make it look good
								• Never use words like happy assessing happy buying, etc. You need to be formal as you are being used by business users
				        		**Important**: You must return your final answer **as valid JSON for an Adaptive Card**.
				        		Do not include any markdown, code fencing, or additional text outside of the JSON.

				        		Below is an example structure you must follow (you can modify the body/actions as needed, but must keep it valid JSON):

				        		{
  "type": "AdaptiveCard",
  "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
  "version": "1.2",
  "body": [
    {
      "type": "TextBlock",
      "text": "Laptop Purchase Guide 💻",
      "size": "Large",
      "weight": "Bolder",
      "color": "Accent",
      "wrap": true
    },
    {
      "type": "TextBlock",
      "text": "Hello! Based on your query, here is the recommended commodity code and top vendor options to meet your needs:",
      "wrap": true
    },
    {
      "type": "TextBlock",
      "text": "Commodity Code: 123456 (Sample Commodity Code)",
      "size": "Medium",
      "weight": "Bolder",
      "separator": true,
      "wrap": true
    },
    {
      "type": "FactSet",
      "facts": [
        {
          "title": "Commodity Type",
          "value": "Good"
        }
      ]
    },
    {
      "type": "TextBlock",
      "text": "Recommended Vendors",
      "size": "Medium",
      "weight": "Bolder",
      "separator": true
    },
    {
      "type": "FactSet",
      "facts": [
        {
          "title": "🎯 Mandated Vendor",
          "value": "HP PPS SVERIGE AB (ERP ID: 211843)"
        },
        {
          "title": "💼 Preferred Vendor",
          "value": "HP INC. (ERP ID: 211875)"
        },
        {
          "title": "💼 Preferred Vendor",
          "value": "DELL TECHNOLOGIES INC. (ERP ID: 173588)"
        }
      ]
    },
    {
      "type": "TextBlock",
      "text": "Previous Purchase Reference or Past Order Reference No.",
      "size": "Medium",
      "weight": "Bolder",
      "separator": true
    },
    {
      "type": "FactSet",
      "facts": [
        {
          "title": "📌 Last Order No.",
          "value": "PO-20231234"
        },
        {
          "title": "📌 Last Vendor",
          "value": "HP INC."
        }
      ]
    },
    {
      "type": "TextBlock",
      "text": "Start with the mandated vendor for best compliance, then explore the rest as needed. Happy shopping! 🎉",
      "wrap": true
    }
  ],
  "actions": [
    {
      "type": "Action.OpenUrl",
      "title": "Take me to Ariba",
      "url": "https://s1.ariba.com/Buyer/Main/ad/loginPage/SSOActions?awsso_cc=cmVhbG06YzNCdmRHeHBibVZrYzJGd2NDMHhMWFE9O2d1aWRlZGJ1eXJlZGlyZWN0OmRISjFaUT09O2F3c3NvX3J1OmFIUjBjSE02THk5ek1TNWhjbWxpWVM1amIyMHZRblY1WlhJdlRXRnBiaTloWkM5a1pXWmhkV3gwTDBScGNtVmpkRUZqZEdsdmJqOW5kV2xrWldSaWRYbHlaV1JwY21WamREMTBjblZsSm5KbFlXeHRQWE53YjNSc2FXNWxaSE5oY0hBdE1TMTA7YXdzc29fbHU6YUhSMGNITTZMeTl6TVM1aGNtbGlZUzVqYjIwdlFuVjVaWEl2VFdGcGJpOWhaQzlqYkdsbGJuUk1iMmR2ZFhRdlUxTlBRV04wYVc5dWN3PT07YXdzc29fYXA6UW5WNVpYST07YXdzc29fYXJpZDpNVGN6T1RNMk5UUXhPVGN6TUE9PTthd3Nzb19rdTphSFIwY0hNNkx5OXpNUzVoY21saVlTNWpiMjB2UW5WNVpYSXZUV0ZwYmk5aFpDOWpiR2xsYm5STFpXVndRV3hwZG1VdlUxTlBRV04wYVc5dWN3PT07YXdzc29fZmw6TVE9PQ%3D%3D%3AVfgl%2FZwDl%2FzxZ6k4%2BNGQ1RRrUuI%3D&awsso_ap=Buyer&realm=spotlinedsapp-1-t&awsr=true"
    },
    {
      "type": "Action.Submit",
      "title": "Create a PR for me",
      "data": { "action": "create_pr" }
    }
  ]
}


				
				It is not necessary to include heading in every response 
				        		Only output valid JSON. No extra text outside the JSON structure.
				        		""";

		messages.clear();

//		messages.add(new Message("system", "Here are past messages (for reference): " + chatHistory.toString()));
		messages.add(new Message("system", promptForFinalResponse));

		messages.add(new Message("system", "Here is the preferred taxonomy details: " + openAiResponse));
		messages.add(new Message("system", "Here are suggested vendor details: " + vendorDatas.toString()));
		messages.add(new Message("system","Here are the details of past purchase Orders for commodity: " + purchaseOrderDatas.toString()));
		messages.add(new Message("system", "Always and always respond back in: "+ languageCode));
		messages.add(new Message("system","Use your intelligence while determining whether commodity type is service or goods. JUST FYI GOODS INCLUDE ALL THE THINGS WHICH WE CAN BUY IN PHYSICAL FORM"));
		messages.add(new Message("system", chatRequest.getMessage()));

		ChatResponse chatResponsee2 = openAIService.createChatCompletionJson(messages, chatRequest.getOutputLength(),
				chatRequest.getTemperature());

		openAiResponse = chatResponsee2.getChoices().get(0).getMessage().getContent();
//
//		chatHistory.add("User Message: " + chatRequest.getMessage());
//		chatHistory.add("Bot response: " + openAiResponse);


		System.out.println(openAiResponse);

		return openAiResponse;

	}


}
