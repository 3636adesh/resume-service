package com.smartdocs.gpt.gemini.model;

import lombok.Data;

@Data
public class CountTokensResponse {
    private int totalTokens;
}
