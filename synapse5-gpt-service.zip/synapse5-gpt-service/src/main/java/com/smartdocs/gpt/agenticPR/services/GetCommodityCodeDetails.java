package com.smartdocs.gpt.agenticPR.services;

import com.alibaba.fastjson.JSONObject;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.smartdocs.gpt.agenticPR.DTO.PreviousOrdersDTO;
import com.smartdocs.gpt.agenticPR.models.*;
import com.smartdocs.gpt.agenticPR.repositories.AribaCatalogEmbeddingRepository;
import com.smartdocs.gpt.agenticPR.models.AribaCatalogEmbedding;
import com.smartdocs.gpt.openai.model.EmbeddingData;
import com.smartdocs.gpt.openai.model.EmbedingsResponse;
import com.smartdocs.gpt.openai.service.OpenAIService;
import com.smartdocs.gpt.service.CommonService;
import com.smartdocs.gpt.service.OpenAIConfigProperties;
import lombok.RequiredArgsConstructor;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.*;

@Service
@RequiredArgsConstructor
public class GetCommodityCodeDetails {

    private final OpenAIService openAIService;
    private final MongoClient mongoClient;
    private final CommonService commonService;
    private final AribaCatalogEmbeddingRepository aribaCatalogEmbeddingRepository;
    private final OpenAIConfigProperties openAIConfigProperties;
    private final RestTemplate restTemplate;

    @Value("${vector.db.name}")
    private String dbName;

    public List<CommodityCodeResponse> getCommodityCodeFromEmbedding(List<String> itemsId) throws IOException, InterruptedException {
        List<CommodityCodeResponse> responseList = new ArrayList<>();

        List<AribaCatalogEmbedding> catalogEmbeddings = aribaCatalogEmbeddingRepository.findAllById(itemsId);

        for (AribaCatalogEmbedding item : catalogEmbeddings) {
            String itemId = item.getId();
            String combinedMessage = item.getShortName();

            EmbeddingData embeddingData = openAIService.createEmbeddingInDouble(combinedMessage);
            List<Double> queryEmbeddings = embeddingData.getEmbedding();

            CommodityCodeDocument topDoc = runVectorSearch(queryEmbeddings);

            if (topDoc != null) {
                CommodityCodeResponse response = new CommodityCodeResponse(
                        itemId,
                        topDoc.getName(),
                        topDoc.getCommodityCode()
                );
                responseList.add(response);
            }
        }

        return responseList;
    }

    public CommodityCodeDocument runVectorSearch(List<Double> queryEmbeddings) {
        MongoDatabase database = mongoClient.getDatabase(dbName);
        MongoCollection<Document> collection = database.getCollection("commodityCodeEmbeddings");

        Bson vectorSearchStage = new Document("$vectorSearch",
                new Document("index", "vector_index")
                        .append("path", "embeddings")
                        .append("queryVector", queryEmbeddings)
                        .append("numCandidates", 200)
                        .append("limit", 1)
        );

        for (var doc : collection.aggregate(Collections.singletonList(vectorSearchStage))) {
            JSONObject jsonObject = JSONObject.parseObject(doc.toJson());

            CommodityCodeDocument result = new CommodityCodeDocument();
            result.setId(jsonObject.getString("_id"));
            result.setName(jsonObject.getString("name"));
            result.setCommodityCode(jsonObject.getString("effectiveCommodityCodeUniqueName"));

            return result;
        }

        return null;
    }

//    public List<CommodityCodeDocument> runVectorSearchOnMultiple(List<Double> queryEmbeddings) {
//        MongoDatabase database = mongoClient.getDatabase(dbName);
//        MongoCollection<Document> collection = database.getCollection("commodityCodeEmbeddings");
//
//        Bson vectorSearchStage = new Document("$vectorSearch",
//                new Document("index", "vector_index")
//                        .append("path", "embeddings")
//                        .append("queryVector", queryEmbeddings)
//                        .append("numCandidates", 220)
//                        .append("limit", 1)
//        );
//
//        List<CommodityCodeDocument> results = new ArrayList<>();
//
//        for (var doc : collection.aggregate(Collections.singletonList(vectorSearchStage))) {
//            JSONObject jsonObject = JSONObject.parseObject(doc.toJson());
//
//            CommodityCodeDocument result = new CommodityCodeDocument();
//            result.setId(jsonObject.getString("_id"));
//            result.setName(jsonObject.getString("name"));
//            result.setCommodityCode(jsonObject.getString("effectiveCommodityCodeUniqueName"));
//
//            results.add(result);
//        }
//
//        return results;
//    }

    public List<CommodityCodeDocument> runVectorSearchOnMultiple(List<Double> queryEmbeddings) {
        MongoDatabase database = mongoClient.getDatabase(dbName);
        MongoCollection<Document> collection = database.getCollection("commodityCodeEmbeddings");

        double similarityThreshold = .30;
        int limit = 2;
        Bson vectorSearchStage = new Document("$vectorSearch",
                new Document("index", "vector_index")
                        .append("path", "embeddings")
                        .append("queryVector", queryEmbeddings)
                        .append("numCandidates", 220)
                        .append("limit", limit)
                        .append("filter", new Document("priority", "true"))
        );
        Bson addFieldsStage = new Document("$addFields",
                new Document("similarityScore", new Document("$meta", "vectorSearchScore"))
        );
        Bson matchStage = new Document("$match",
                new Document("similarityScore", new Document("$gte", similarityThreshold))
        );
        Bson sortStage = new Document("$sort",
                new Document("similarityScore", -1)
        );
        Bson limitStage = new Document("$limit", limit);
        List<Bson> pipeline = Arrays.asList(
                vectorSearchStage,
                addFieldsStage,
                matchStage,
                sortStage,
                limitStage
        );

        List<CommodityCodeDocument> results = new ArrayList<>();

        for (var doc : collection.aggregate(pipeline)) {
            JSONObject jsonObject = JSONObject.parseObject(doc.toJson());

            CommodityCodeDocument result = new CommodityCodeDocument();
            result.setId(jsonObject.getString("_id"));
            result.setName(jsonObject.getString("name"));
            result.setCommodityCode(jsonObject.getString("effectiveCommodityCodeUniqueName"));

            results.add(result);
        }

        return results;
    }





    public List<PreviousOrdersDTO> findCommoditySupplierPairs(String commodityCode, String userId) {
        MongoDatabase database = mongoClient.getDatabase(dbName);
        MongoCollection<Document> commodityCollection = database.getCollection("commodityCodeEmbeddings");

        Document commodityDoc = commodityCollection.find(
                new Document("uniqueName", new Document("$regex", commodityCode).append("$options", "i"))
        ).first();

        if (commodityDoc == null) {
            System.out.println("No commodity found for commodityCode (regex): " + commodityCode);
            return Collections.emptyList();
        }

        String commodityName = commodityDoc.getString("name");
        MongoCollection<Document> prCollection = database.getCollection("Document_Ariba_PR");

        Document query = new Document()
                .append("creator", userId)
                .append("liattributes", new Document("$elemMatch",
                        new Document("CommonCommodityCode", commodityName)));

        List<PreviousOrdersDTO> dtoList = new ArrayList<>();

        for (Document prDoc : prCollection.find(query)) {
            String prDocId = prDoc.getString("_id");
            List<Document> liattributes = (List<Document>) prDoc.get("liattributes");

            if (liattributes != null) {
                for (Document li : liattributes) {
                    String code = li.getString("CommonCommodityCode");
                    String shortName = li.getString("shortName");
                    String supplier = li.getString("SupplierName");

                    if (commodityName.equals(code)) {
                        dtoList.add(new PreviousOrdersDTO(shortName, supplier , prDocId));
                    }
                }
            }
        }

        return dtoList;
    }

    public List<Double> generateSearchEmbedding(String query) {
        try {
            Map<String, Object> request = new HashMap<>();
            request.put("input", query);
            request.put("model", openAIConfigProperties.getEmbeddingModel());

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(openAIConfigProperties.getApiKey());

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(request, headers);

            String url = "https://api.openai.com/v1/embeddings";
            ResponseEntity<EmbedingsResponse> response = restTemplate.exchange(
                    openAIConfigProperties.getApiUrl() + "/embeddings",
                    HttpMethod.POST,
                    entity,
                    EmbedingsResponse.class
            );

            EmbedingsResponse body = response.getBody();
            if (body != null && body.getData() != null && !body.getData().isEmpty()) {
                List<Float> rawEmbedding = body.getData().get(0).getEmbedding();
                List<Double> embedding = new ArrayList<>();
                for (Float f : rawEmbedding) {
                    embedding.add(f.doubleValue());
                }
                return embedding;
            }

            return Collections.emptyList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

}

