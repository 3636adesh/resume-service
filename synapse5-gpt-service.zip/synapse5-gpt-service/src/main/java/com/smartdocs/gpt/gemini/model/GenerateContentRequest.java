// com.smartdocs.gpt.gemini.model.GenerateContentRequest.java
package com.smartdocs.gpt.gemini.model;

import java.util.List;

import lombok.Data;

@Data
public class GenerateContentRequest {
    private List<Content> contents;

    public void setGenerationConfig(GenerationConfig config) {

    }
}
