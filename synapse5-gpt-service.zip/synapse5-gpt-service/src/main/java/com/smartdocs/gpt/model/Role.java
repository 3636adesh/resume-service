package com.smartdocs.gpt.model;

public class Role {
	public static final String USER = "user";
	public static final String SYSTEM = "system";
	public static final String ASSISTANT = "assistant";

}