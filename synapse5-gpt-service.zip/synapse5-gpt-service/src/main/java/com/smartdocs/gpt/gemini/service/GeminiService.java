package com.smartdocs.gpt.gemini.service;

import java.util.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartdocs.gpt.gemini.model.*;
import com.smartdocs.gpt.utils.VectorNormalizer;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.client.RestTemplate;

import com.smartdocs.gpt.gemini.config.GeminiConfigProperties;
import com.smartdocs.gpt.openai.model.ChatResponse;
import com.smartdocs.gpt.openai.model.EmbedingsResponse;
import com.smartdocs.gpt.openai.model.Message;

import lombok.extern.slf4j.Slf4j;

import static com.smartdocs.gpt.utils.VectorNormalizer.normalizeVector;

@Service("geminiService")
@Slf4j
public class GeminiService {

    private final RestTemplate restTemplate;
    private final GeminiConfigProperties geminiConfigProperties;
    private final ObjectMapper objectMapper;

    public GeminiService(@Qualifier("geminiRestTemplate") RestTemplate restTemplate, GeminiConfigProperties geminiConfigProperties) {
        this.restTemplate = restTemplate;
        this.geminiConfigProperties = geminiConfigProperties;
        this.objectMapper = new ObjectMapper();
    }

    /**
     * Generic method to create chat completion with custom JSON schema
     * @param messages List of messages for the conversation
     * @param maxTokens Maximum tokens for the response
     * @param temperature Temperature for response generation
     * @param responseSchema Custom JSON schema for the response structure
     * @return ChatResponse with the generated content
     */
    public ChatResponse createChatCompletionWithCustomSchema(List<Message> messages, int maxTokens,
                                                             double temperature, Map<String, Object> responseSchema) {
        // Create a single Content object with role "user"
        Content content = new Content();
        content.setRole("user");
        List<ContentPart> parts = new ArrayList<>();

        // Combine all your messages (system prompt + context + user query)
        StringBuilder combinedPrompt = new StringBuilder();
        for (Message msg : messages) {
            if ("system".equals(msg.getRole())) {
                combinedPrompt.append("System: ").append(msg.getContent()).append("\n\n");
            } else if ("user".equals(msg.getRole())) {
                combinedPrompt.append("User: ").append(msg.getContent()).append("\n\n");
            } else {
                combinedPrompt.append(msg.getContent()).append("\n\n");
            }
        }

        parts.add(new ContentPart(combinedPrompt.toString()));
        content.setParts(parts);

        // Generation configuration with custom JSON schema
        GenerationConfig config = GenerationConfig.builder()
                .maxOutputTokens(maxTokens)
                .temperature((float) temperature)
                .responseMimeType("application/json")
                .responseSchema(responseSchema)
                .build();

        GenerateContentRequest request = new GenerateContentRequest();
        request.setContents(List.of(content));
        request.setGenerationConfig(config);

        // Call Gemini API
        String url = geminiConfigProperties.getBaseUrl() + "/models/"
                + geminiConfigProperties.getModelName() + ":generateContent";

        GenerateContentResponse geminiResponse = restTemplate.postForObject(
                url, request, GenerateContentResponse.class);

        // Map Gemini response to ChatResponse
        ChatResponse chatResponse = new ChatResponse();
        if (geminiResponse != null && geminiResponse.getCandidates() != null
                && !geminiResponse.getCandidates().isEmpty()) {

            Content geminiContent = geminiResponse.getCandidates().get(0).getContent();
            StringBuilder generatedText = new StringBuilder();

            if (geminiContent != null && geminiContent.getParts() != null) {
                for (ContentPart part : geminiContent.getParts()) {
                    generatedText.append(part.getText());
                }
            }

            Message message = new Message("assistant", generatedText.toString());
            ChatResponse.Choice choice = new ChatResponse.Choice();
            choice.setIndex(0);
            choice.setMessage(message);
            chatResponse.setChoices(List.of(choice));

            GenerateContentResponse.UsageMetadata geminiUsage = geminiResponse.getUsageMetadata();
            if (geminiUsage != null) {
                ChatResponse.Usage usage = new ChatResponse.Usage();
                usage.setPromptTokens(geminiUsage.getPromptTokenCount());
                usage.setCompletionTokens(geminiUsage.getCandidatesTokenCount());
                usage.setTotalTokens(geminiUsage.getTotalTokenCount());
                chatResponse.setUsage(usage);
            }
        }

        return chatResponse;
    }

    public ChatResponse createChatCompletionWithSchema(List<Message> messages, int maxTokens, double temperature) {
        Map<String, Object> chatSchema = GeminiSchemaFactory.createChatResponseSchema();
        return createChatCompletionWithCustomSchema(messages, maxTokens, temperature, chatSchema);
    }

    public ChatResponse createSuggestedQuestionsCompletion(List<Message> messages, int maxTokens, double temperature) {
        Map<String, Object> questionsSchema = GeminiSchemaFactory.createSuggestedQuestionsSchema();
        return createChatCompletionWithCustomSchema(messages, maxTokens, temperature, questionsSchema);
    }

    public ChatResponse createExtendedSuggestedQuestionsCompletion(List<Message> messages, int maxTokens, double temperature) {
        Map<String, Object> extendedSchema = GeminiSchemaFactory.createExtendedSuggestedQuestionsSchema();
        return createChatCompletionWithCustomSchema(messages, maxTokens, temperature, extendedSchema);
    }

    public ChatResponse createChatCompletion(List<Message> messages, int maxTokens, double temperature) {
        // Create a single Content object with role "user"
        Content content = new Content();
        content.setRole("user");
        List<ContentPart> parts = new ArrayList<>();
        for (Message msg : messages) {
            parts.add(new ContentPart(msg.getContent()));
        }
        content.setParts(parts);

        // Prepare the request
        GenerateContentRequest request = new GenerateContentRequest();
        request.setContents(List.of(content)); // only one content with role "user"

        // Generation configuration
        GenerationConfig config = GenerationConfig.builder()
                .maxOutputTokens(maxTokens)
                .temperature((float) temperature)
                .build();
        request.setGenerationConfig(config);

        // Call Gemini API
        String url = geminiConfigProperties.getBaseUrl() + "/models/"
                + geminiConfigProperties.getModelName() + ":generateContent";

        GenerateContentResponse geminiResponse = restTemplate.postForObject(
                url, request, GenerateContentResponse.class);

        // Map Gemini response to ChatResponse
        ChatResponse chatResponse = new ChatResponse();
        if (geminiResponse != null && geminiResponse.getCandidates() != null
                && !geminiResponse.getCandidates().isEmpty()) {
            Content geminiContent = geminiResponse.getCandidates().get(0).getContent();
            StringBuilder generatedText = new StringBuilder();
            if (geminiContent != null && geminiContent.getParts() != null) {
                for (ContentPart part : geminiContent.getParts()) {
                    generatedText.append(part.getText());
                }
            }
            Message message = new Message("assistant", generatedText.toString());
            ChatResponse.Choice choice = new ChatResponse.Choice();
            choice.setIndex(0);
            choice.setMessage(message);
            chatResponse.setChoices(List.of(choice));

            GenerateContentResponse.UsageMetadata geminiUsage = geminiResponse.getUsageMetadata();
            if (geminiUsage != null) {
                ChatResponse.Usage usage = new ChatResponse.Usage();

                usage.setPromptTokens(geminiUsage.getPromptTokenCount());
                usage.setCompletionTokens(geminiUsage.getCandidatesTokenCount());
                usage.setTotalTokens(geminiUsage.getTotalTokenCount());

                chatResponse.setUsage(usage);
            }
        }

        return chatResponse;
    }

    public ChatResponse createChatCompletionJson(List<Message> messages, int maxTokens, double temperature) {
        // Similar to createChatCompletion, expecting JSON-like response
        return createChatCompletion(messages, maxTokens, temperature);
    }

    public EmbedingsResponse createEmbeddings(String text) {
        // Prepare embedding request
        ContentPart part = new ContentPart(text);
        Content content = new Content();
        content.setParts(List.of(part));
        EmbedContentRequest request = new EmbedContentRequest();
        request.setContent(content);
        request.setOutputDimensionality(1536);

        // Call Gemini API for embeddings
        String url = geminiConfigProperties.getBaseUrl() + "/models/"
                + geminiConfigProperties.getEmbeddingModel() + ":embedContent";
        EmbedContentResponse geminiResponse = restTemplate.postForObject(url, request, EmbedContentResponse.class);
        // Map to OpenAI-style embedding response
        EmbedingsResponse response = new EmbedingsResponse();
        response.setObject("list");
        if (geminiResponse != null && geminiResponse.getEmbedding() != null) {
            EmbedingsResponse.Datum datum = new EmbedingsResponse.Datum();
            datum.setEmbedding(geminiResponse.getEmbedding().getValues());
            response.setData(List.of(datum));
        }
        return response;
    }

    public List<Double> createEmbeddingInDouble(String text) {
        EmbedingsResponse embedResponse = createEmbeddings(text);
        if (embedResponse != null && embedResponse.getData() != null && !embedResponse.getData().isEmpty()) {
            List<Float> floats = embedResponse.getData().get(0).getEmbedding();
            List<Double> doubles = new ArrayList<>();
            for (Float f : floats) {
                doubles.add(f.doubleValue());
            }
            List<Double> normalizedEmbedding = VectorNormalizer.normalizeVector(doubles);
            return normalizedEmbedding;
        }
        return Collections.emptyList();
    }

    public int countTokensForBatch(List<String> texts) {
        try {
            CountTokensRequest request = buildCountTokensRequest (texts);

            String url = geminiConfigProperties.getBaseUrl() + "/models/"
                    + "gemini-embedding-001" + ":countTokens";

            CountTokensResponse geminiResponse = restTemplate.postForObject(url, request, CountTokensResponse.class);

            if (geminiResponse != null) {
                return geminiResponse.getTotalTokens();
            }
            return 0;

        } catch (Exception e) {
            log.error("Error counting tokens for batch", e);
            return texts.size();
        }
    }

    private CountTokensRequest buildCountTokensRequest(List<String> texts) {
        CountTokensRequest request = new CountTokensRequest();
        List<Content> contents = new ArrayList<>();

        // Convert each text to a Content object
        for (String text : texts) {
            ContentPart part = new ContentPart(text);
            Content content = new Content();
            content.setParts(List.of(part));
            contents.add(content);
        }

        request.setContents(contents);
        return request;
    }
}




//    public ChatResponse createChatCompletion(List<Message> messages, int maxTokens, double temperature) {
//        // Convert each Message to Gemini Content
//        List<Content> contents = new ArrayList<>();
//        for (Message msg : messages) {
//            ContentPart part = new ContentPart(msg.getContent());
//            Content content = new Content();
//            content.setParts(List.of(part));
//            contents.add(content);
//        }
//        GenerateContentRequest request = new GenerateContentRequest();
//        request.setContents(contents);
//        // Set generation configuration (max tokens, temperature)
//        GenerationConfig config = GenerationConfig.builder()
//                .maxOutputTokens(maxTokens)
//                .temperature((float) temperature)
//                .build();
//        request.setGenerationConfig(config);
//        // Call Gemini API
//        String url = geminiConfigProperties.getBaseUrl() + "/models/"
//                + geminiConfigProperties.getChatModel() + ":generateContent";
//        GenerateContentResponse geminiResponse = restTemplate.postForObject(url, request, GenerateContentResponse.class);
//        // Map to ChatResponse
//        ChatResponse chatResponse = new ChatResponse();
//        if (geminiResponse != null && geminiResponse.getCandidates() != null
//                && !geminiResponse.getCandidates().isEmpty()) {
//            Content geminiContent = geminiResponse.getCandidates().get(0).getContent();
//            StringBuilder generatedText = new StringBuilder();
//            if (geminiContent != null && geminiContent.getParts() != null) {
//                for (ContentPart part : geminiContent.getParts()) {
//                    generatedText.append(part.getText());
//                }
//            }
//            Message message = new Message();
//            message.setRole("assistant");
//            message.setContent(generatedText.toString());
//            ChatResponse.Choice choice = new ChatResponse.Choice();
//            choice.setMessage(message);
//            chatResponse.setChoices(List.of(choice));
//        }
//        return chatResponse;
//    }


