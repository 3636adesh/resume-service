package com.smartdocs.gpt.agenticPR.models;

import com.smartdocs.gpt.agenticPR.DTO.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShowUserDefaults {

    private String deliverTo;
    private List<CompanyCodeDTO> companyCodes;
    private List<PurchasingOrgDTO> purchasingOrganization;
    private AccountingDTO accounting;
    private ShippingDTO shipping;
    private String commodityCode;
    private String commodityCodeName;


//    private List<CatalogItem> lineItems;
//    private String comments = "";
//    private String needByDate = "";
//    private String title;


}
