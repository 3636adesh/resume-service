package com.smartdocs.gpt.agenticPR.models;

import com.smartdocs.gpt.agenticPR.DTO.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "aribaUser")
public class AribaUser {

    @Id
    private String id;

    private String uniqueName;
    private String userName;
    private String displayName;
    private String userType;
    private String locale;
    private String timezone;
    private boolean active;
    private String deliverTo;
    private String currency;

    private List<CompanyCodeDTO> companyCodes;
    private List<PurchasingOrgDTO> purchasingOrganization;
    private List<CatalogItem> lineItems;
    private List<GLAccountDTO> generalLedgerAccount;
    private List<CostCenterDTO> costCenter;
    private List<PlantDTO> plant;
    private List<PurchasingGroupDTO> purchasingGroup;

}
