package com.smartdocs.gpt.agenticPR.repositories;

import com.smartdocs.gpt.agenticPR.models.AribaUser;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface AribaUserRepository extends MongoRepository<AribaUser, String> {
    Optional<AribaUser> findByUniqueName(String uniqueName);
}
